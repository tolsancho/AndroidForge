package ru.tsautoreport.diagnostic

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.ComponentName
import android.content.ClipboardManager
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.content.pm.LauncherApps
import android.content.pm.ShortcutInfo
import android.os.Bundle
import android.app.AlarmManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import android.view.accessibility.AccessibilityManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    private val launcherApps by lazy { getSystemService(Context.LAUNCHER_APPS_SERVICE) as LauncherApps }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DiagnosticStore.add(this, "${stamp()} | APP_BUILD_ID | id=TS-BIND-0210 | version=0.21.0-wheel-ui | versionCode=25")
        recordBootAndPersistenceCheck()
        val savedHome = HomeShortcutStore.state(this)
        DiagnosticStore.add(this, "${stamp()} | HOME_SHORTCUT_CONFIG_LOADED | label=${savedHome.label} | cloneConfirmed=${savedHome.cloneConfirmed} | pending=${savedHome.pending} | lastResult=${savedHome.lastResult}")
        ProfileBindingStore.verifyLoaded(this)
        setContent { Screen() }
    }

    override fun onResume() {
        super.onResume()
        DiagnosticStore.add(this, "${stamp()} | APP_RESUMED | bootCount=${currentBootCount()}")
    }

    /** The first app launch after a device reboot compares Android's BOOT_COUNT with the prior launch. */
    private fun recordBootAndPersistenceCheck() {
        val bootCount = currentBootCount()
        val prefs = getSharedPreferences("boot_audit_store", Context.MODE_PRIVATE)
        val previous = prefs.getInt("last_boot_count", -1)
        when {
            bootCount < 0 -> DiagnosticStore.add(this, "${stamp()} | BOOT_COUNT_UNAVAILABLE | reboot_test_cannot_be_verified")
            previous < 0 -> DiagnosticStore.add(this, "${stamp()} | BOOT_BASELINE_SET | bootCount=$bootCount | next_launch_after_reboot_will_be_checked=true")
            previous != bootCount -> {
                DiagnosticStore.add(this, "${stamp()} | DEVICE_REBOOT_DETECTED | previousBootCount=$previous | currentBootCount=$bootCount")
                val result = ProfileBindingStore.verifyLoaded(this)
                DiagnosticStore.add(this, "${stamp()} | BIND_LOAD_AFTER_REBOOT_${if (result.first) "VERIFIED" else "FAILED"} | count=${result.second} | bootCount=$bootCount")
            }
            else -> DiagnosticStore.add(this, "${stamp()} | SAME_BOOT_SESSION | bootCount=$bootCount | previousBootCount=$previous")
        }
        if (bootCount >= 0) prefs.edit().putInt("last_boot_count", bootCount).commit()
    }

    private fun currentBootCount(): Int = try {
        Settings.Global.getInt(contentResolver, Settings.Global.BOOT_COUNT, -1)
    } catch (_: Exception) { -1 }

    @Composable private fun Screen() {
        var enabled by remember { mutableStateOf(isServiceEnabled()) }
        var logs by remember { mutableStateOf(DiagnosticStore.read(this@MainActivity)) }
        var hour by remember { mutableIntStateOf(12) }
        var minute by remember { mutableIntStateOf(30) }
        var cloneLabel by remember { mutableStateOf(HomeShortcutStore.state(this@MainActivity).label.ifBlank { "Я Билайн Нов" }) }
        var cloneConfirmed by remember { mutableStateOf(HomeShortcutStore.state(this@MainActivity).cloneConfirmed) }
        var scheduleStatus by remember { mutableStateOf(if (ScheduledTestStore.active(this@MainActivity)) "Запланировано: ${Date(ScheduledTestStore.scheduledAt(this@MainActivity))}" else "Расписание не задано") }
        val keyboard = androidx.compose.ui.platform.LocalSoftwareKeyboardController.current
        val focusManager = androidx.compose.ui.platform.LocalFocusManager.current

        fun dismissInput() {
            focusManager.clearFocus(force = true)
            keyboard?.hide()
            DiagnosticStore.add(this@MainActivity, "${stamp()} | UI_INPUT_DISMISS_REQUEST | keyboardHideRequested=true")
        }
        fun refreshLog() {
            enabled = isServiceEnabled()
            logs = DiagnosticStore.read(this@MainActivity)
        }
        fun copyReport() {
            dismissInput()
            DiagnosticStore.add(this@MainActivity, "${stamp()} | ACTION_COPY_FULL_REPORT | requested=true")
            val saved = HomeShortcutStore.state(this@MainActivity)
            val report = buildString {
                appendLine("TS AutoReport — полный диагностический отчёт")
                appendLine("BUILD ID: TS-BIND-0210")
                appendLine("Версия: 0.21.0-wheel-ui · versionCode=25")
                appendLine("Устройство: ${Build.MANUFACTURER} ${Build.MODEL}")
                appendLine("Android API: ${Build.VERSION.SDK_INT} · release=${Build.VERSION.RELEASE}")
                appendLine("Accessibility включена: ${isServiceEnabled()}")
                appendLine("Выбранный WhatsApp: ${if (saved.cloneConfirmed) "Dual Messenger clone (operator confirmed)" else "не подтверждён"}")
                appendLine("Ярлык главного экрана: ${saved.label} · cloneConfirmed=${saved.cloneConfirmed} · pending=${saved.pending} · result=${saved.lastResult}")
                appendLine("Расписание активно: ${ScheduledTestStore.active(this@MainActivity)} · timestamp=${ScheduledTestStore.scheduledAt(this@MainActivity)}")
                appendLine("Время интерфейса: %02d:%02d".format(hour, minute))
                appendLine("\nВнутренний журнал (старые → новые):")
                DiagnosticStore.readAllChronological(this@MainActivity).forEach { appendLine(it) }
                appendLine("\nПримечание: основной WhatsApp не используется; сообщения не отправляются.")
            }
            val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("TS AutoReport diagnostics", report))
            Toast.makeText(this@MainActivity, "Полный отчёт скопирован", Toast.LENGTH_LONG).show()
            logs = DiagnosticStore.read(this@MainActivity)
        }
        fun openCloneForSelection() {
            dismissInput()
            DiagnosticStore.add(this@MainActivity, "${stamp()} | ACTION_SELECT_WHATSAPP_CLONE | pressed=true")
            try {
                val user = launcherApps.profiles.firstOrNull { it.toString() == "UserHandle{95}" }
                    ?: throw IllegalStateException("Профиль Dual Messenger UserHandle{95} не найден")
                val launch = packageManager.getLaunchIntentForPackage("com.whatsapp")
                    ?: throw IllegalStateException("Точка запуска WhatsApp не найдена")
                val component = launch.component ?: throw IllegalStateException("Компонент запуска WhatsApp не найден")
                launcherApps.startMainActivity(component, user, null, Bundle())
                DiagnosticStore.add(this@MainActivity, "${stamp()} | WHATSAPP_CLONE_LAUNCH_REQUESTED | user=$user | cloneOnly=true")
                Toast.makeText(this@MainActivity, "Открылся выбранный профиль. Убедись, что это клон с синей меткой, затем вернись сюда.", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                DiagnosticStore.add(this@MainActivity, "${stamp()} | WHATSAPP_CLONE_LAUNCH_FAILED | ${e.javaClass.simpleName}:${e.message}")
                Toast.makeText(this@MainActivity, "Не удалось открыть клон: ${e.message}", Toast.LENGTH_LONG).show()
            }
            refreshLog()
        }
        fun saveCloneSettings(): Boolean {
            dismissInput()
            val confirmed = HomeShortcutStore.setCloneConfirmed(this@MainActivity, cloneConfirmed)
            val labeled = HomeShortcutStore.setLabel(this@MainActivity, cloneLabel)
            DiagnosticStore.add(this@MainActivity, "${stamp()} | ACTION_SAVE_CLONE_SELECTION | confirmed=$cloneConfirmed | label=${cloneLabel.trim()} | saved=${confirmed && labeled}")
            return confirmed && labeled
        }

        MaterialTheme {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text("TS AutoReport", style = MaterialTheme.typography.headlineLarge)
                Text("Расписание тестового черновика", style = MaterialTheme.typography.titleMedium)
                Text("BUILD ID: TS-BIND-0210 · versionCode 25", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                HorizontalDivider()

                Text("1. WhatsApp для теста", style = MaterialTheme.typography.titleLarge)
                Text("Используется только клон Samsung Dual Messenger. Основной WhatsApp отключён для тестов.", style = MaterialTheme.typography.bodyMedium)
                Button(onClick = { openCloneForSelection() }, modifier = Modifier.fillMaxWidth()) { Text("Выбрать / проверить клон WhatsApp") }
                OutlinedTextField(
                    value = cloneLabel,
                    onValueChange = { cloneLabel = it.take(80) },
                    label = { Text("Подпись иконки чата на главном экране") },
                    modifier = Modifier.fillMaxWidth(), singleLine = true
                )
                Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Checkbox(checked = cloneConfirmed, onCheckedChange = { dismissInput(); cloneConfirmed = it })
                    Text("Это ярлык именно клона с синей меткой Dual Messenger")
                }
                Button(onClick = {
                    val ok = saveCloneSettings()
                    Toast.makeText(this@MainActivity, if (ok) "Настройки клона сохранены" else "Не удалось сохранить настройки", Toast.LENGTH_SHORT).show()
                    refreshLog()
                }, modifier = Modifier.fillMaxWidth()) { Text("Сохранить выбор WhatsApp") }

                HorizontalDivider()
                Text("2. Время запуска", style = MaterialTheme.typography.titleLarge)
                Text("Выставь часы и минуты вращением барабанов. Клавиатура не используется.", style = MaterialTheme.typography.bodyMedium)
                AndroidView(
                    factory = { context ->
                        android.widget.LinearLayout(context).apply {
                            orientation = android.widget.LinearLayout.HORIZONTAL
                            gravity = android.view.Gravity.CENTER
                            val h = android.widget.NumberPicker(context).apply {
                                minValue = 0; maxValue = 23; value = hour; wrapSelectorWheel = true
                                setFormatter { value -> "%02d".format(value) }
                                contentDescription = "Часы"
                                disableNumberPickerKeyboard(this)
                                setOnValueChangedListener { _, _, new -> hour = new }
                            }
                            val sep = android.widget.TextView(context).apply {
                                text = ":"; textSize = 28f; gravity = android.view.Gravity.CENTER
                            }
                            val m = android.widget.NumberPicker(context).apply {
                                minValue = 0; maxValue = 59; value = minute; wrapSelectorWheel = true
                                setFormatter { value -> "%02d".format(value) }
                                contentDescription = "Минуты"
                                disableNumberPickerKeyboard(this)
                                setOnValueChangedListener { _, _, new -> minute = new }
                            }
                            addView(h, android.widget.LinearLayout.LayoutParams(0, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                            addView(sep, android.widget.LinearLayout.LayoutParams(36, android.view.ViewGroup.LayoutParams.WRAP_CONTENT))
                            addView(m, android.widget.LinearLayout.LayoutParams(0, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                        }
                    },
                    update = { view ->
                        val h = view.getChildAt(0) as android.widget.NumberPicker
                        val m = view.getChildAt(2) as android.widget.NumberPicker
                        if (h.value != hour) h.value = hour
                        if (m.value != minute) m.value = minute
                    },
                    modifier = Modifier.fillMaxWidth().height(150.dp)
                )
                Text("Выбрано: %02d:%02d".format(hour, minute), style = MaterialTheme.typography.headlineMedium)
                Button(onClick = {
                    dismissInput()
                    try {
                        if (!saveCloneSettings()) throw IllegalStateException("Не удалось сохранить подтверждение клона и подпись ярлыка")
                        if (!enabled) throw IllegalStateException("Сначала включи службу специальных возможностей TS AutoReport")
                        val alarm = getSystemService(Context.ALARM_SERVICE) as AlarmManager
                        if (Build.VERSION.SDK_INT >= 31 && !alarm.canScheduleExactAlarms()) {
                            DiagnosticStore.add(this@MainActivity, "${stamp()} | ACTION_REQUEST_EXACT_ALARM_PERMISSION | requested=true")
                            startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
                            scheduleStatus = "Разреши точные будильники и снова нажми «Применить время»."
                        } else {
                            val at = ScheduledTestStore.schedule(this@MainActivity, "%02d:%02d".format(hour, minute))
                            scheduleStatus = "Запланировано на ${SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date(at))}"
                            DiagnosticStore.add(this@MainActivity, "${stamp()} | UI_SCHEDULE_APPLIED | keyboardHidden=true | activityMoveToBackRequested=true")
                            Toast.makeText(this@MainActivity, "Время применено. Приложение свернётся для надёжного выполнения.", Toast.LENGTH_LONG).show()
                            refreshLog()
                            window.decorView.postDelayed({ moveTaskToBack(true) }, 350)
                        }
                    } catch (e: Exception) {
                        scheduleStatus = "Ошибка: ${e.message}"
                        DiagnosticStore.add(this@MainActivity, "${stamp()} | UI_SCHEDULE_APPLY_FAILED | ${e.javaClass.simpleName}:${e.message}")
                    }
                    refreshLog()
                }, enabled = cloneConfirmed && cloneLabel.trim().length >= 3, modifier = Modifier.fillMaxWidth()) { Text("Применить время и свернуть приложение") }
                OutlinedButton(onClick = {
                    dismissInput()
                    ScheduledTestStore.cancel(this@MainActivity)
                    scheduleStatus = "Расписание отменено"
                    refreshLog()
                }, modifier = Modifier.fillMaxWidth()) { Text("Отменить расписание") }
                Text(scheduleStatus, style = MaterialTheme.typography.bodyMedium)
                Text("В назначенное время откроется сохранённый чат клона и будет введён черновик «проверка». Сообщение не отправляется. Для PIN, пароля или графического ключа автоматизация остановится.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)

                HorizontalDivider()
                Text("3. Состояние и журнал", style = MaterialTheme.typography.titleLarge)
                Text(if (enabled) "Служба специальных возможностей включена" else "Служба специальных возможностей выключена", color = if (enabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                Button(onClick = {
                    dismissInput()
                    DiagnosticStore.add(this@MainActivity, "${stamp()} | ACTION_OPEN_ACCESSIBILITY_SETTINGS | pressed=true")
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                }, modifier = Modifier.fillMaxWidth()) { Text("Настройки специальных возможностей") }
                OutlinedButton(onClick = { dismissInput(); refreshLog() }, modifier = Modifier.fillMaxWidth()) { Text("Обновить журнал") }
                Button(onClick = { copyReport() }, modifier = Modifier.fillMaxWidth()) { Text("Скопировать весь текст с логом") }
                Text("Записей: ${logs.size}. Журнал сохраняется автоматически.", style = MaterialTheme.typography.bodySmall)
                logs.forEach { Text(it, style = MaterialTheme.typography.bodySmall) }
            }
        }
    }

    private fun disableNumberPickerKeyboard(picker: android.widget.NumberPicker) {
        val inputId = resources.getIdentifier("numberpicker_input", "id", "android")
        if (inputId != 0) {
            val input = picker.findViewById<android.widget.EditText>(inputId)
            input?.showSoftInputOnFocus = false
            input?.isFocusable = false
            input?.isFocusableInTouchMode = false
            input?.isCursorVisible = false
        }
    }

    private fun stamp() = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault()).format(Date())

    private fun isServiceEnabled(): Boolean {
        val manager = getSystemService(ACCESSIBILITY_SERVICE) as AccessibilityManager
        val expected = ComponentName(this, WhatsAppAccessibilityService::class.java)
        return manager.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            .any { it.resolveInfo.serviceInfo.let { info -> ComponentName(info.packageName, info.name) == expected } }
    }
}
