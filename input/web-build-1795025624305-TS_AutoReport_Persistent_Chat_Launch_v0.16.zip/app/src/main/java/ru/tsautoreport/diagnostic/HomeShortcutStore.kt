package ru.tsautoreport.diagnostic

import android.content.Context

/** Stores only the user-entered launcher icon label and a one-shot click request. */
object HomeShortcutStore {
    private const val PREFS = "home_shortcut_assist"
    data class State(val label: String, val pending: Boolean, val lastResult: String, val cloneConfirmed: Boolean, val lastLaunchAt: Long)

    fun state(context: Context): State {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return State(p.getString("label", "").orEmpty(), p.getBoolean("pending", false), p.getString("last_result", "Ещё не запускался").orEmpty(), p.getBoolean("clone_confirmed", false), p.getLong("last_launch_at", 0L))
    }

    fun setLabel(context: Context, label: String): Boolean {
        val clean = label.trim().replace('\n', ' ').replace('\t', ' ').take(80)
        val ok = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("label", clean).commit()
        DiagnosticStore.add(context, "${stamp()} | HOME_SHORTCUT_LABEL_SAVED | label=$clean | verified=$ok")
        return ok
    }

    fun setCloneConfirmed(context: Context, confirmed: Boolean): Boolean {
        val ok = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("clone_confirmed", confirmed).commit()
        DiagnosticStore.add(context, "${stamp()} | HOME_SHORTCUT_CLONE_CONFIRMATION_SAVED | confirmed=$confirmed | verified=$ok")
        return ok
    }

    fun request(context: Context): Boolean {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val label = p.getString("label", "").orEmpty()
        if (label.length < 3 || !p.getBoolean("clone_confirmed", false)) return false
        val now = System.currentTimeMillis()
        val ok = p.edit().putBoolean("pending", true).putLong("last_launch_at", now).putString("last_result", "Ожидается поиск и нажатие иконки на главном экране").commit()
        DiagnosticStore.add(context, "${stamp()} | HOME_SHORTCUT_LAUNCH_REQUESTED | label=$label | cloneOnly=true | pending=$ok")
        return ok
    }

    fun pendingLabel(context: Context): String? {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (!p.getBoolean("pending", false)) return null
        val started = p.getLong("last_launch_at", 0L)
        if (started <= 0L || System.currentTimeMillis() - started > 20_000L) {
            finish(context, "TIMEOUT_NO_UNIQUE_HOME_ICON_MATCH", 0, false)
            return null
        }
        return p.getString("label", "")?.takeIf { it.length >= 3 }
    }

    fun markConversationObserved(context: Context, windowId: Int) {
        val state = state(context)
        val age = System.currentTimeMillis() - state.lastLaunchAt
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val alreadyLogged = p.getLong("conversation_observed_for_launch", 0L) == state.lastLaunchAt
        if (state.lastLaunchAt > 0L && age in 0..25_000L && !alreadyLogged) {
            DiagnosticStore.add(context, "${stamp()} | HOME_SHORTCUT_TARGET_CONVERSATION_OBSERVED | label=${state.label} | window=$windowId | ageMs=$age | profile_origin_not_independently_verified=true")
            p.edit().putLong("conversation_observed_for_launch", state.lastLaunchAt).putString("last_result", "Окно переписки появилось после нажатия ярлыка (профиль требует визуальной проверки)").commit()
        }
    }

    fun finish(context: Context, result: String, matched: Int = 0, clicked: Boolean = false) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean("pending", false).putString("last_result", result).commit()
        DiagnosticStore.add(context, "${stamp()} | HOME_SHORTCUT_LAUNCH_RESULT | result=$result | matched=$matched | clicked=$clicked")
    }

    private fun stamp() = java.text.SimpleDateFormat("HH:mm:ss.SSS", java.util.Locale.getDefault()).format(java.util.Date())
}
