package ru.tsautoreport.diagnostic

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { Screen() }
    }

    @Composable private fun Screen() {
        var enabled by remember { mutableStateOf(isServiceEnabled()) }
        var logs by remember { mutableStateOf(DiagnosticStore.read(this)) }
        MaterialTheme {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("TS AutoReport", style = MaterialTheme.typography.headlineLarge)
                Text("Тест Accessibility для основного WhatsApp и клона", style = MaterialTheme.typography.titleMedium)
                Text("Эта версия только фиксирует технические события окон WhatsApp: время, тип события, package и класс окна. Текст сообщений, имена контактов и содержимое чатов не читаются и не сохраняются.")
                Text(if (enabled) "Служба Accessibility включена" else "Служба Accessibility выключена", color = if (enabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                Button(onClick = { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }) { Text("Открыть настройки специальных возможностей") }
                Button(onClick = { enabled = isServiceEnabled(); logs = DiagnosticStore.read(this@MainActivity) }) { Text("Обновить статус и журнал") }
                HorizontalDivider()
                Text("Порядок проверки", style = MaterialTheme.typography.titleLarge)
                Text("1. В настройках включи «TS AutoReport — диагностика WhatsApp». Android покажет предупреждение — это системное разрешение для службы специальных возможностей.")
                Text("2. Вернись сюда и нажми «Обновить статус и журнал». Должно появиться «Служба Accessibility включена».")
                Text("3. Нажми кнопку Home, открой основной WhatsApp, открой любой чат, подожди 5 секунд и вернись в TS AutoReport. Нажми обновить.")
                Text("4. Очисти журнал. Повтори те же действия с клоном WhatsApp.")
                Text("5. Пришли два скриншота журнала: после основного WhatsApp и после клона. Не отправляй сообщения во время теста.")
                HorizontalDivider()
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Журнал событий", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                    TextButton(onClick = { DiagnosticStore.clear(this@MainActivity); logs = emptyList() }) { Text("Очистить") }
                }
                if (logs.isEmpty()) Text("Пока событий нет. Включи службу и открой WhatsApp.")
                logs.forEach { line -> Text(line, style = MaterialTheme.typography.bodySmall) }
                Text("Важно: одинаковый package com.whatsapp сам по себе не доказывает, какой экземпляр вызвал событие. Этот тест покажет, что именно доступно службе на твоём Samsung.", style = MaterialTheme.typography.bodySmall)
            }
        }
    }

    private fun isServiceEnabled(): Boolean {
        val manager = getSystemService(ACCESSIBILITY_SERVICE) as AccessibilityManager
        val expected = ComponentName(this, WhatsAppAccessibilityService::class.java)
        return manager.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            .any { it.resolveInfo.serviceInfo.let { info -> ComponentName(info.packageName, info.name) == expected } }
    }
}
