package ru.tsautoreport.diagnostic

import android.content.Context

/** Stores only the operator-selected calibration context, not a claimed Android identity. */
object CalibrationStore {
    private const val PREFS = "instance_calibration"
    private const val KEY_LABEL = "target_label"
    private const val KEY_PROFILE = "target_profile"
    private const val KEY_STARTED = "started_at"

    data class Target(val label: String, val profile: String, val startedAt: Long)

    @Synchronized fun start(context: Context, label: String, profile: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_LABEL, label)
            .putString(KEY_PROFILE, profile)
            .putLong(KEY_STARTED, System.currentTimeMillis())
            .apply()
    }

    @Synchronized fun stop(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply()
    }

    fun current(context: Context): Target? {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val label = p.getString(KEY_LABEL, null) ?: return null
        val profile = p.getString(KEY_PROFILE, "unknown") ?: "unknown"
        return Target(label, profile, p.getLong(KEY_STARTED, 0L))
    }
}
