package ru.tsautoreport.diagnostic

import android.content.Context
import java.io.File

/** Independent diagnostic journal. Factory reset does not clear this file or its preferences. */
object DiagnosticStore {
    private const val PREFS = "accessibility_diagnostic"
    private const val KEY_LOG = "events"
    private const val KEY_MIGRATED = "events_file_migrated_v1"
    private const val FILE_NAME = "diagnostic_events.log"
    private const val RETENTION_MS = 7L * 24L * 60L * 60L * 1000L
    private const val SEP = "\t"

    private fun journal(context: Context) = File(context.filesDir, FILE_NAME)
    private fun encode(timestamp: Long, line: String) = "$timestamp$SEP$line"
    private fun decode(raw: String, legacyTimestamp: Long): Pair<Long, String>? {
        val split = raw.indexOf('\t')
        if (split > 0) {
            val timestamp = raw.substring(0, split).toLongOrNull() ?: return null
            return timestamp to raw.substring(split + 1)
        }
        // Legacy entries had only HH:mm:ss.SSS. Their original date was not stored;
        // use the old journal file's modification time as a conservative migration date.
        return legacyTimestamp to raw
    }

    @Synchronized private fun migrateIfNeeded(context: Context) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (prefs.getBoolean(KEY_MIGRATED, false)) return
        val old = prefs.getString(KEY_LOG, "").orEmpty()
        if (old.isNotBlank()) {
            val now = System.currentTimeMillis()
            journal(context).appendText(old.lines().filter { it.isNotBlank() }.joinToString("\n", postfix = "\n") { encode(now, it) }, Charsets.UTF_8)
        }
        prefs.edit().putBoolean(KEY_MIGRATED, true).remove(KEY_LOG).commit()
    }

    @Synchronized private fun prune(context: Context) {
        migrateIfNeeded(context)
        val file = journal(context)
        if (!file.exists()) return
        val now = System.currentTimeMillis()
        val legacyTimestamp = file.lastModified().takeIf { it > 0L } ?: now
        val kept = file.readLines(Charsets.UTF_8).mapNotNull { decode(it, legacyTimestamp) }
            .filter { it.first <= now && now - it.first <= RETENTION_MS }
        file.writeText(kept.joinToString("\n", postfix = if (kept.isEmpty()) "" else "\n") { encode(it.first, it.second) }, Charsets.UTF_8)
    }

    @Synchronized fun add(context: Context, line: String) {
        try {
            prune(context)
            val safe = line.replace('\n', ' ').replace('\r', ' ')
            journal(context).appendText(encode(System.currentTimeMillis(), safe) + "\n", Charsets.UTF_8)
        } catch (_: Exception) {
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val old = prefs.getString(KEY_LOG, "").orEmpty()
            prefs.edit().putString(KEY_LOG, (old + "\n" + encode(System.currentTimeMillis(), safe)).takeLast(500_000)).commit()
        }
    }

    @Synchronized fun read(context: Context): List<String> = try {
        prune(context)
        val file = journal(context)
        if (!file.exists()) emptyList() else file.readLines(Charsets.UTF_8).mapNotNull { decode(it, file.lastModified()) }
            .sortedByDescending { it.first }
            .map { "${java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", java.util.Locale.getDefault()).format(java.util.Date(it.first))} | ${it.second}" }
    } catch (_: Exception) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_LOG, "").orEmpty().split("\n")
            .mapNotNull { decode(it, System.currentTimeMillis()) }
            .filter { it.first <= System.currentTimeMillis() && System.currentTimeMillis() - it.first <= RETENTION_MS }
            .sortedByDescending { it.first }
            .map { "${java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", java.util.Locale.getDefault()).format(java.util.Date(it.first))} | ${it.second}" }
    }

    /** Returns every retained event in chronological order. */
    fun readAllChronological(context: Context): List<String> = read(context).asReversed()

    @Synchronized fun clear(context: Context) {
        try { journal(context).delete() } catch (_: Exception) {}
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY_LOG).putBoolean(KEY_MIGRATED, true).commit()
    }
}
