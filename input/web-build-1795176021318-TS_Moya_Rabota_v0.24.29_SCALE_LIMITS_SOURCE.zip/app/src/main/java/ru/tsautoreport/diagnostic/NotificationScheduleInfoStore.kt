package ru.tsautoreport.diagnostic

import android.content.Context

/** Per-chat timestamp of the last accepted SEND-button action. */
object NotificationScheduleInfoStore {
    private const val PREF = "ts_notification_schedule_info"
    private fun key(chatId: String) = "last_send_$chatId"

    fun recordSendAction(context: Context, chatId: String, timestamp: Long = System.currentTimeMillis()) {
        if (chatId.isBlank()) return
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit().putLong(key(chatId), timestamp).apply()
    }

    fun lastSendAt(context: Context, chatId: String): Long =
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getLong(key(chatId), 0L)
}
