package ru.tsautoreport.diagnostic

import android.content.Context

object DiagnosticStore {
    private const val PREFS = "accessibility_diagnostic"
    private const val KEY_LOG = "events"

    @Synchronized fun add(context: Context, line: String) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val old = prefs.getString(KEY_LOG, "") ?: ""
        val lines = (old.split("\n").filter { it.isNotBlank() } + line).takeLast(300)
        prefs.edit().putString(KEY_LOG, lines.joinToString("\n")).apply()
    }

    fun read(context: Context): List<String> = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .getString(KEY_LOG, "").orEmpty().split("\n").filter { it.isNotBlank() }.takeLast(300).reversed()

    fun clear(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY_LOG).apply()
    }
}
