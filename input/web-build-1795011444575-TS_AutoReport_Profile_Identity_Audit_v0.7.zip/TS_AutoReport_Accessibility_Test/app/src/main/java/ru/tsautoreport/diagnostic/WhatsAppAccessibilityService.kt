package ru.tsautoreport.diagnostic

import android.accessibilityservice.AccessibilityService
import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityWindowInfo
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Records only technical metadata. It does not read chat text, names, notifications or input fields. */
class WhatsAppAccessibilityService : AccessibilityService() {
    private val lastLogged = mutableMapOf<String, Long>()

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg != "com.whatsapp") return

        val type = when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> "WINDOW_STATE_CHANGED"
            AccessibilityEvent.TYPE_WINDOWS_CHANGED -> "WINDOWS_CHANGED"
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED -> "WINDOW_CONTENT_CHANGED"
            AccessibilityEvent.TYPE_VIEW_FOCUSED -> "VIEW_FOCUSED"
            else -> "EVENT_${event.eventType}"
        }
        val cls = event.className?.toString() ?: "(class-not-provided)"
        val winId = event.windowId
        val displayId = if (Build.VERSION.SDK_INT >= 30) event.displayId else -1
        val now = System.currentTimeMillis()
        val fingerprint = "$type|$pkg|$cls|$winId|$displayId"
        val throttleMs = if (event.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) 900L else 250L
        val previous = lastLogged[fingerprint] ?: 0L
        if (now - previous < throttleMs) return
        lastLogged[fingerprint] = now
        if (lastLogged.size > 100) lastLogged.clear()

        val sourceInfo = try {
            event.source?.let { node ->
                val result = "source=${node.packageName}/${node.className}#${node.windowId}"
                node.recycle()
                result
            } ?: "source=null"
        } catch (_: Exception) { "source=unavailable" }
        val activeRoot = try {
            rootInActiveWindow?.let { root ->
                val result = "root=${root.packageName}/${root.className}#${root.windowId}"
                root.recycle()
                result
            } ?: "root=null"
        } catch (_: Exception) { "root=unavailable" }
        val windows = try { describeWindows() } catch (_: Exception) { "windows=unavailable" }
        val processReport = try { runningProcessReport() } catch (_: Exception) { "runningProcesses=unavailable" }
        val time = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault()).format(Date(now))
        DiagnosticStore.add(this, "$time | $type | pkg=$pkg | class=$cls | eventWindow=$winId | display=$displayId | $sourceInfo | $activeRoot | $windows | $processReport | originUserHandle=NOT_EXPOSED_BY_ACCESSIBILITY_EVENT")
    }

    private fun runningProcessReport(): String {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val running = am.runningAppProcesses.orEmpty()
        if (running.isEmpty()) return "runningProcesses=not_visible_or_empty"
        val whatsapp = running.filter { it.processName.contains("com.whatsapp") }
        return if (whatsapp.isEmpty()) "runningProcesses=WhatsApp_process_not_exposed (visible=${running.size})"
        else "runningProcesses=" + whatsapp.joinToString(";") { "${it.processName}:uid=${it.uid}:importance=${it.importance}" }
    }

    private fun describeWindows(): String {
        val entries = windows.orEmpty().take(8).map { w: AccessibilityWindowInfo ->
            val root = try { w.root } catch (_: Exception) { null }
            val rootPkg = root?.packageName?.toString() ?: "?"
            val rootClass = root?.className?.toString() ?: "?"
            val display = if (Build.VERSION.SDK_INT >= 30) w.displayId else -1
            val description = "${w.id}:${w.type}:active=${w.isActive}:focused=${w.isFocused}:display=$display:$rootPkg/$rootClass"
            root?.recycle()
            description
        }
        return "windows=[${entries.joinToString(";")}]"
    }

    override fun onInterrupt() = Unit
}
