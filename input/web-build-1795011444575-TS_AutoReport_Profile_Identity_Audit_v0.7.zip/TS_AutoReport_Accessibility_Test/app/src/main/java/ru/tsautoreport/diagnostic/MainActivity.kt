package ru.tsautoreport.diagnostic

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.LauncherApps
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import android.view.accessibility.AccessibilityManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    private val launcherApps by lazy { getSystemService(Context.LAUNCHER_APPS_SERVICE) as LauncherApps }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { Screen() }
    }

    @Composable private fun Screen() {
        var enabled by remember { mutableStateOf(isServiceEnabled()) }
        var logs by remember { mutableStateOf(DiagnosticStore.read(this@MainActivity)) }
        var entries by remember { mutableStateOf<List<ProfileAudit.Entry>>(emptyList()) }
        var status by remember { mutableStateOf("Нажми «Провести аудит». Повторять прежнюю калибровку не нужно.") }
        var auditDone by remember { mutableStateOf(false) }

        fun refresh() {
            enabled = isServiceEnabled()
            logs = DiagnosticStore.read(this@MainActivity)
        }
        fun audit() {
            try {
                entries = ProfileAudit.discover(this@MainActivity)
                auditDone = true
                val processReport = ProfileAudit.runningProcessReport(this@MainActivity, entries)
                val now = stamp()
                DiagnosticStore.add(this@MainActivity, "$now | PROFILE_API_AUDIT | count=${entries.size} | $processReport")
                entries.forEach { e ->
                    DiagnosticStore.add(this@MainActivity, "$now | PROFILE_ENTRY | user=${e.user} | serial=${e.serial} | uid=${e.uid} | pkg=${e.packageName} | process=${e.processName} | version=${e.versionName}/${e.versionCode} | component=${e.component} | sourceDir=${e.sourceDir}")
                }
                status = if (entries.isEmpty()) "LauncherApps не вернул доступных точек запуска WhatsApp."
                else "Получены метаданные ${entries.size} точек запуска. Сравниваем UserHandle, serial и UID приложения; источник Accessibility-события эти поля сами по себе не подтверждают."
                logs = DiagnosticStore.read(this@MainActivity)
            } catch (e: Exception) {
                auditDone = true
                status = "Ошибка публичного API: ${e.javaClass.simpleName}: ${e.message ?: "без подробностей"}"
                DiagnosticStore.add(this@MainActivity, "${stamp()} | PROFILE_API_AUDIT_ERROR | $status")
                logs = DiagnosticStore.read(this@MainActivity)
            }
        }
        fun launch(entry: ProfileAudit.Entry) {
            try {
                val component = android.content.ComponentName.unflattenFromString(entry.component)
                    ?: throw IllegalStateException("Некорректный компонент запуска")
                val user = launcherApps.profiles.firstOrNull { it.toString() == entry.user }
                    ?: throw IllegalStateException("Профиль больше не доступен; сначала обнови аудит")
                DiagnosticStore.add(this@MainActivity, "${stamp()} | PROFILE_LAUNCH_REQUEST | user=${entry.user} | serial=${entry.serial} | uid=${entry.uid} | component=${entry.component} | note=LauncherApps_startMainActivity_requested_not_event_origin_proof")
                launcherApps.startMainActivity(component, user, null, Bundle())
                Toast.makeText(this@MainActivity, "Запрошен запуск ${entry.user}. Это не является подтверждением источника Accessibility.", Toast.LENGTH_LONG).show()
                logs = DiagnosticStore.read(this@MainActivity)
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, "Запуск не выполнен: ${e.message}", Toast.LENGTH_LONG).show()
                DiagnosticStore.add(this@MainActivity, "${stamp()} | PROFILE_LAUNCH_ERROR | ${e.javaClass.simpleName}: ${e.message}")
                logs = DiagnosticStore.read(this@MainActivity)
            }
        }

        MaterialTheme {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("TS AutoReport", style = MaterialTheme.typography.headlineLarge)
                Text("Версия 0.7 — аудит идентичности профилей", style = MaterialTheme.typography.titleMedium)
                Text("Эта версия меняет метод: получает реальные метаданные Android для каждого экземпляра и проверяет видимость UID процессов. Никаких повторных ручных калибровок и фиктивных меток.")
                Text(if (enabled) "Accessibility включена" else "Accessibility выключена", color = if (enabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                Button(onClick = { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }) { Text("Открыть специальные возможности") }
                Button(onClick = { refresh() }) { Text("Обновить статус и журнал") }
                HorizontalDivider()
                Text("1. Аудит публичных Android API", style = MaterialTheme.typography.titleLarge)
                Button(onClick = { audit() }) { Text("Провести аудит профилей и UID") }
                Text(status, style = MaterialTheme.typography.bodySmall)
                if (auditDone && entries.isEmpty()) Text("Результат: профили не обнаружены или недоступны через LauncherApps.", color = MaterialTheme.colorScheme.error)
                entries.forEachIndexed { index, e ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Text("Экземпляр ${index + 1}", style = MaterialTheme.typography.titleMedium)
                            Text("UserHandle: ${e.user}")
                            Text("Serial профиля: ${e.serial}")
                            Text("UID приложения: ${e.uid}")
                            Text("Package/process: ${e.packageName} / ${e.processName}", style = MaterialTheme.typography.bodySmall)
                            Text("Версия: ${e.versionName} (${e.versionCode})", style = MaterialTheme.typography.bodySmall)
                            Text("Компонент: ${e.component}", style = MaterialTheme.typography.bodySmall)
                            Button(onClick = { launch(e) }) { Text("Запустить этот экземпляр") }
                        }
                    }
                }
                HorizontalDivider()
                Text("2. Что доказывает этот тест", style = MaterialTheme.typography.titleLarge)
                Text("• LauncherApps может перечислить профили и отдельно запросить запуск компонента в выбранном UserHandle.")
                Text("• UID и serial помогают сравнить записи профилей. Сами по себе они не связывают AccessibilityEvent с профилем.")
                Text("• В AccessibilityEvent доступны packageName, className, windowId и displayId, но публичный UserHandle источника события не предоставляется.")
                Text("• Если Android не показывает процессы WhatsApp стороннему приложению, аудит так и запишет. Это не ошибка теста и не повод угадывать профиль.")
                Text("ВАЖНО: пока нет независимого идентификатора профиля в самом событии Accessibility, автоматическую отправку в основной/клон включать нельзя. Разные windowId не считаются доказательством.", color = MaterialTheme.colorScheme.error)
                HorizontalDivider()
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Журнал", style = MaterialTheme.typography.titleLarge)
                    Row {
                        TextButton(onClick = { copyEntireLog() }) { Text("Копировать") }
                        TextButton(onClick = { DiagnosticStore.clear(this@MainActivity); logs = emptyList() }) { Text("Очистить") }
                    }
                }
                Text("Событий: ${logs.size}. Журнал не содержит текст переписки или имена чатов.", style = MaterialTheme.typography.bodySmall)
                logs.forEach { Text(it, style = MaterialTheme.typography.bodySmall) }
            }
        }
    }

    private fun copyEntireLog() {
        val all = DiagnosticStore.readAllChronological(this)
        val header = buildString {
            appendLine("TS AutoReport — аудит идентичности профилей")
            appendLine("Версия приложения: 0.7-profile-identity-audit")
            appendLine("Устройство: ${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}")
            appendLine("Android: ${android.os.Build.VERSION.RELEASE} (API ${android.os.Build.VERSION.SDK_INT})")
            appendLine("Событий: ${all.size}")
            appendLine("ВАЖНО: UserHandle не предоставляется AccessibilityEvent как публичное поле. UID метаданных не доказывает источник события.")
            appendLine("----------------------------------------")
        }
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("TS AutoReport audit", header + all.joinToString("\n")))
        Toast.makeText(this, "Журнал скопирован: ${all.size} событий", Toast.LENGTH_LONG).show()
    }

    private fun stamp() = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault()).format(Date())

    private fun isServiceEnabled(): Boolean {
        val manager = getSystemService(ACCESSIBILITY_SERVICE) as AccessibilityManager
        val expected = ComponentName(this, WhatsAppAccessibilityService::class.java)
        return manager.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            .any { it.resolveInfo.serviceInfo.let { info -> ComponentName(info.packageName, info.name) == expected } }
    }
}
