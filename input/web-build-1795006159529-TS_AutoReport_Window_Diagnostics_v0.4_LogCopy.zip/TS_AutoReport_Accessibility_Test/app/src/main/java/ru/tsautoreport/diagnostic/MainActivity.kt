package ru.tsautoreport.diagnostic

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.ComponentName
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { Screen() }
    }

    @Composable private fun Screen() {
        var enabled by remember { mutableStateOf(isServiceEnabled()) }
        var logs by remember { mutableStateOf(DiagnosticStore.read(this)) }
        MaterialTheme {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("TS AutoReport", style = MaterialTheme.typography.headlineLarge)
                Text("Версия 0.4 — диагностика окон и копирование журнала", style = MaterialTheme.typography.titleMedium)
                Text("Цель: проверить, какие метаданные окон Android предоставляет для основного WhatsApp и клона Samsung Dual Messenger.")
                Text("Конфиденциальность: приложение записывает только package, class, window ID, display ID и метаданные окон. Текст сообщений, имена контактов, contentDescription и содержимое элементов не читаются и не сохраняются.")
                Text(if (enabled) "Служба Accessibility включена" else "Служба Accessibility выключена", color = if (enabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                Button(onClick = { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }) { Text("Открыть специальные возможности") }
                Button(onClick = { enabled = isServiceEnabled(); logs = DiagnosticStore.read(this@MainActivity) }) { Text("Обновить статус и журнал") }
                HorizontalDivider()
                Text("Порядок теста", style = MaterialTheme.typography.titleLarge)
                Text("1. Убедись, что служба TS AutoReport включена.")
                Text("2. Нажми «Очистить журнал» ниже.")
                Text("3. Открой основной WhatsApp, перейди в любой чат, подожди 5 секунд и вернись сюда. Нажми «Обновить статус и журнал».")
                Text("4. Сделай скриншот журнала основного WhatsApp.")
                Text("5. Очисти журнал, повтори те же действия с клоном и сделай второй скриншот.")
                Text("Не отправляй сообщения во время проверки. Для чистоты теста используй один и тот же экран чата в обоих экземплярах.")
                HorizontalDivider()
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
                ) {
                    Text("Журнал событий", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                    TextButton(onClick = { copyEntireLog() }) { Text("Копировать лог") }
                    TextButton(onClick = { DiagnosticStore.clear(this@MainActivity); logs = emptyList() }) { Text("Очистить") }
                }
                Text("Сохранено событий: ${logs.size}. Копируется весь сохранённый журнал, от старых записей к новым.", style = MaterialTheme.typography.bodySmall)
                if (logs.isEmpty()) Text("Пока событий нет. Включи службу и открой WhatsApp.")
                logs.forEach { line -> Text(line, style = MaterialTheme.typography.bodySmall) }
                Text("Важно: window ID и метаданные окон могут отличаться между запусками, но сами по себе не гарантируют постоянную идентификацию профиля. По результатам решим, возможна ли безопасная привязка экземпляра.", style = MaterialTheme.typography.bodySmall)
            }
        }
    }

    private fun copyEntireLog() {
        val allEvents = DiagnosticStore.readAllChronological(this)
        val header = buildString {
            appendLine("TS AutoReport — журнал диагностики")
            appendLine("Версия приложения: 0.4-log-copy")
            appendLine("Устройство: ${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}")
            appendLine("Android: ${android.os.Build.VERSION.RELEASE} (API ${android.os.Build.VERSION.SDK_INT})")
            appendLine("Событий: ${allEvents.size}")
            appendLine("Порядок: от старых к новым")
            appendLine("----------------------------------------")
        }
        val fullLog = header + if (allEvents.isEmpty()) "Журнал пуст." else allEvents.joinToString("\n")
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("TS AutoReport log", fullLog))
        Toast.makeText(this, "Скопировано событий: ${allEvents.size}", Toast.LENGTH_LONG).show()
    }

    private fun isServiceEnabled(): Boolean {
        val manager = getSystemService(ACCESSIBILITY_SERVICE) as AccessibilityManager
        val expected = ComponentName(this, WhatsAppAccessibilityService::class.java)
        return manager.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            .any { it.resolveInfo.serviceInfo.let { info -> ComponentName(info.packageName, info.name) == expected } }
    }
}
