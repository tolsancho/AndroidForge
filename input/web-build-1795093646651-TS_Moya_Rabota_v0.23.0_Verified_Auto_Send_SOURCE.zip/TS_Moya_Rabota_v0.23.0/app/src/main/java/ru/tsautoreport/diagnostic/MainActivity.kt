package ru.tsautoreport.diagnostic

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.LauncherApps
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.accessibility.AccessibilityManager
import android.widget.LinearLayout
import android.widget.NumberPicker
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import kotlinx.coroutines.launch
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private class TimeMessageUi(hourValue: Int = 0, minuteValue: Int = 0, messageValue: String = "", editingValue: Boolean = true) {
    var hour by mutableIntStateOf(hourValue)
    var minute by mutableIntStateOf(minuteValue)
    var message by mutableStateOf(messageValue)
    var editing by mutableStateOf(editingValue)
    var timeEditing by mutableStateOf(false)
    var draftHour by mutableIntStateOf(hourValue)
    var draftMinute by mutableIntStateOf(minuteValue)
}

class MainActivity : ComponentActivity() {
    private var permissionRefresh: (() -> Unit)? = null
    private val launcherApps by lazy { getSystemService(Context.LAUNCHER_APPS_SERVICE) as LauncherApps }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DiagnosticStore.add(this, "${stamp()} | APP_BUILD_ID | id=TS-BIND-0230 | version=0.23.0-verified-auto-send | versionCode=30")
        recordBootAndPersistenceCheck()
        val savedHome = HomeShortcutStore.state(this)
        DiagnosticStore.add(this, "${stamp()} | HOME_SHORTCUT_CONFIG_LOADED | label=${savedHome.label} | cloneConfirmed=${savedHome.cloneConfirmed} | pending=${savedHome.pending} | lastResult=${savedHome.lastResult}")
        ProfileBindingStore.verifyLoaded(this)
        setContent { Screen() }
    }

    override fun onResume() {
        super.onResume()
        DiagnosticStore.add(this, "${stamp()} | APP_RESUMED | bootCount=${currentBootCount()}")
        permissionRefresh?.invoke()
    }

    private fun recordBootAndPersistenceCheck() {
        val count = currentBootCount()
        val prefs = getSharedPreferences("boot_audit_store", Context.MODE_PRIVATE)
        val previous = prefs.getInt("last_boot_count", -1)
        when {
            count < 0 -> DiagnosticStore.add(this, "${stamp()} | BOOT_COUNT_UNAVAILABLE | reboot_test_cannot_be_verified")
            previous < 0 -> DiagnosticStore.add(this, "${stamp()} | BOOT_BASELINE_SET | bootCount=$count | next_launch_after_reboot_will_be_checked=true")
            previous != count -> {
                DiagnosticStore.add(this, "${stamp()} | DEVICE_REBOOT_DETECTED | previousBootCount=$previous | currentBootCount=$count")
                val result = ProfileBindingStore.verifyLoaded(this)
                DiagnosticStore.add(this, "${stamp()} | BIND_LOAD_AFTER_REBOOT_${if (result.first) "VERIFIED" else "FAILED"} | count=${result.second} | bootCount=$count")
            }
            else -> DiagnosticStore.add(this, "${stamp()} | SAME_BOOT_SESSION | bootCount=$count | previousBootCount=$previous")
        }
        if (count >= 0) prefs.edit().putInt("last_boot_count", count).commit()
    }

    private fun currentBootCount() = try { Settings.Global.getInt(contentResolver, Settings.Global.BOOT_COUNT, -1) } catch (_: Exception) { -1 }

    @Composable private fun Screen() {
        val initial = remember { ScheduledTestStore.savedEntries(this@MainActivity) }
        val slots = remember { mutableStateListOf<TimeMessageUi>().apply { initial.forEach { e -> add(TimeMessageUi(e.time.substringBefore(":").toInt(), e.time.substringAfter(":").toInt(), e.message, false)) } } }
        var serviceOk by remember { mutableStateOf(isServiceEnabled()) }
        var batteryOk by remember { mutableStateOf(isBatteryExempt()) }
        var alarmOk by remember { mutableStateOf(canExactAlarms()) }
        var logs by remember { mutableStateOf(DiagnosticStore.read(this@MainActivity)) }
        var cloneLabel by remember { mutableStateOf(HomeShortcutStore.state(this@MainActivity).label.ifBlank { "Я Билайн Нов" }) }
        var cloneConfirmed by remember { mutableStateOf(HomeShortcutStore.state(this@MainActivity).cloneConfirmed) }
        var scheduleStatus by remember { mutableStateOf(if (ScheduledTestStore.active(this@MainActivity)) "Расписание активно" else "Расписание отключено") }
        var showFactoryReset by remember { mutableStateOf(false) }
        val drawerState = rememberDrawerState(DrawerValue.Closed)
        val drawerScope = rememberCoroutineScope()
        val keyboard = LocalSoftwareKeyboardController.current
        val focus = LocalFocusManager.current

        fun dismissInput(reason: String) {
            focus.clearFocus(force = true)
            keyboard?.hide()
            DiagnosticStore.add(this@MainActivity, "${stamp()} | UI_INPUT_DISMISS_REQUEST | source=$reason | keyboardHideRequested=true")
        }
        fun refresh() {
            serviceOk = isServiceEnabled(); batteryOk = isBatteryExempt(); alarmOk = canExactAlarms()
            logs = DiagnosticStore.read(this@MainActivity)
        }
        fun refreshLogOnly() { logs = DiagnosticStore.read(this@MainActivity) }
        fun openClone() {
            dismissInput("select_clone")
            DiagnosticStore.add(this@MainActivity, "${stamp()} | ACTION_SELECT_WHATSAPP_CLONE | pressed=true")
            try {
                val user = launcherApps.profiles.firstOrNull { it.toString() == "UserHandle{95}" } ?: throw IllegalStateException("Профиль Dual Messenger UserHandle{95} не найден")
                val launch = packageManager.getLaunchIntentForPackage("com.whatsapp") ?: throw IllegalStateException("Точка запуска WhatsApp не найдена")
                launcherApps.startMainActivity(launch.component ?: throw IllegalStateException("Компонент WhatsApp не найден"), user, null, Bundle())
                DiagnosticStore.add(this@MainActivity, "${stamp()} | WHATSAPP_CLONE_LAUNCH_REQUESTED | user=$user | cloneOnly=true")
                Toast.makeText(this@MainActivity, "Проверь синюю метку Dual Messenger и вернись в TS AutoReport", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                DiagnosticStore.add(this@MainActivity, "${stamp()} | WHATSAPP_CLONE_LAUNCH_FAILED | ${e.javaClass.simpleName}:${e.message}")
                Toast.makeText(this@MainActivity, "Не удалось открыть клон: ${e.message}", Toast.LENGTH_LONG).show()
            }
            refreshLogOnly()
        }
        fun saveClone(): Boolean {
            val a = HomeShortcutStore.setCloneConfirmed(this@MainActivity, cloneConfirmed)
            val b = HomeShortcutStore.setLabel(this@MainActivity, cloneLabel.trim())
            DiagnosticStore.add(this@MainActivity, "${stamp()} | ACTION_SAVE_CLONE_SELECTION | confirmed=$cloneConfirmed | label=${cloneLabel.trim()} | saved=${a && b}")
            return a && b
        }
        DisposableEffect(Unit) {
            permissionRefresh = { refresh() }
            onDispose { permissionRefresh = null }
        }

        fun copyReport() {
            dismissInput("copy_report")
            DiagnosticStore.add(this@MainActivity, "${stamp()} | ACTION_COPY_FULL_REPORT | requested=true")
            val saved = HomeShortcutStore.state(this@MainActivity)
            val report = buildString {
                appendLine("TS AutoReport — полный диагностический отчёт")
                appendLine("BUILD ID: TS-BIND-0230")
                appendLine("Версия: 0.23.0-verified-auto-send · versionCode=30")
                appendLine("Устройство: ${Build.MANUFACTURER} ${Build.MODEL}")
                appendLine("Android API: ${Build.VERSION.SDK_INT} · release=${Build.VERSION.RELEASE}")
                appendLine("Accessibility включена: ${isServiceEnabled()}")
                appendLine("Исключение оптимизации батареи: ${isBatteryExempt()}")
                appendLine("Точные будильники: ${canExactAlarms()}")
                appendLine("Выбранный WhatsApp: ${if (saved.cloneConfirmed) "Dual Messenger clone (operator confirmed)" else "не подтверждён"}")
                appendLine("Ярлык чата: ${saved.label} · cloneConfirmed=${saved.cloneConfirmed}")
                appendLine("Расписание активно: ${ScheduledTestStore.active(this@MainActivity)}")
                slots.forEachIndexed { i, s -> appendLine("Время ${i + 1}: %02d:%02d · сообщение=${s.message}".format(s.hour, s.minute)) }
                appendLine("\nВнутренний журнал (старые → новые):")
                DiagnosticStore.readAllChronological(this@MainActivity).forEach { appendLine(it) }
                appendLine("\nПроверка черновика: после ввода текст остаётся в поле 5 секунд, затем приложение пытается очистить только совпадающий текст и проверяет пустое поле.")
                appendLine("Примечание: основной WhatsApp не используется; сообщения автоматически не отправляются.")
            }
            (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("TS AutoReport diagnostics", report))
            Toast.makeText(this@MainActivity, "Полный отчёт скопирован", Toast.LENGTH_LONG).show()
            refreshLogOnly()
        }

        MaterialTheme {
            ModalNavigationDrawer(
                drawerState = drawerState,
                gesturesEnabled = false,
                drawerContent = {
                    ModalDrawerSheet {
                        Text("Настройки", modifier = Modifier.padding(20.dp), style = MaterialTheme.typography.titleLarge)
                        HorizontalDivider()
                        NavigationDrawerItem(
                            label = { Text("Сброс приложения до первого запуска") },
                            selected = false,
                            onClick = { drawerScope.launch { drawerState.close() }; showFactoryReset = true }
                        )
                        Text("Сброс отменяет расписания, выбранный WhatsApp, ярлыки и локальные настройки. Системные разрешения Android останутся включёнными.", modifier = Modifier.padding(16.dp), style = MaterialTheme.typography.bodySmall)
                    }
                }
            ) {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { drawerScope.launch { drawerState.open() } }) { Icon(Icons.Default.Menu, contentDescription = "Открыть настройки") }
                    Text("TS AutoReport", style = MaterialTheme.typography.headlineLarge)
                }
                Text("Настройка расписания", style = MaterialTheme.typography.titleMedium)
                Text("BUILD ID: TS-BIND-0230 · versionCode 30", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)

                Text("Доступы устройства", style = MaterialTheme.typography.titleLarge)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.Top) {
                    PermissionDot("Спец.\nвозможности", serviceOk) { dismissInput("accessibility_permission"); DiagnosticStore.add(this@MainActivity, "${stamp()} | ACTION_OPEN_ACCESSIBILITY_SETTINGS | pressed=true"); startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
                    PermissionDot("Батарея\nв фоне", batteryOk) { dismissInput("battery_permission"); DiagnosticStore.add(this@MainActivity, "${stamp()} | ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS | requested=true"); try { startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))) } catch (_: Exception) { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } }
                    PermissionDot("Точные\nбудильники", alarmOk) { dismissInput("exact_alarm_permission"); DiagnosticStore.add(this@MainActivity, "${stamp()} | ACTION_REQUEST_EXACT_ALARM_PERMISSION | requested=true"); if (Build.VERSION.SDK_INT >= 31) startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName"))) }
                }
                Text("Зелёный — доступ есть. Красный — нажми на кружок и включи разрешение в настройках Android.", style = MaterialTheme.typography.bodySmall)

                HorizontalDivider()
                Text("WhatsApp и чат", style = MaterialTheme.typography.titleLarge)
                Text("Тестирование выполняется только в подтверждённом клоне Samsung Dual Messenger. Основной WhatsApp не запускается.", style = MaterialTheme.typography.bodySmall)
                Button(onClick = { openClone() }, modifier = Modifier.fillMaxWidth()) { Text("Выбрать / проверить WhatsApp-клон") }
                OutlinedTextField(value = cloneLabel, onValueChange = { cloneLabel = it.take(80) }, label = { Text("Имя ярлыка нужного чата на главном экране") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = cloneConfirmed, onCheckedChange = { dismissInput("clone_confirmation"); cloneConfirmed = it })
                    Text("Подтверждаю: ярлык именно клона с синей меткой")
                }
                Button(onClick = { dismissInput("save_chat"); val ok = saveClone(); Toast.makeText(this@MainActivity, if (ok) "Чат сохранён" else "Не удалось сохранить", Toast.LENGTH_SHORT).show(); refreshLogOnly() }, modifier = Modifier.fillMaxWidth()) { Text("Сохранить чат") }

                HorizontalDivider()
                Text("Время и сообщения", style = MaterialTheme.typography.titleLarge)
                Text("Можно добавить до трёх отдельных запусков. В каждом выбирается время и свой текст (до 3000 символов). В назначенный момент текст будет только вставлен в поле ввода клона — отправки нет.", style = MaterialTheme.typography.bodySmall)
                slots.forEachIndexed { index, slot ->
                    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text("Запуск ${index + 1}", style = MaterialTheme.typography.titleMedium)
                                if (slots.size > 1 || slot.editing) TextButton(onClick = { dismissInput("remove_slot"); slots.removeAt(index) }) { Text("Удалить") }
                            }
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = MaterialTheme.colorScheme.secondaryContainer,
                                modifier = Modifier.fillMaxWidth().clickable {
                                    dismissInput("edit_time_${index + 1}")
                                    slot.draftHour = slot.hour
                                    slot.draftMinute = slot.minute
                                    slot.timeEditing = true
                                    DiagnosticStore.add(this@MainActivity, "${stamp()} | UI_TIME_EDIT_OPENED | slot=${index + 1} | current=%02d:%02d".format(slot.hour, slot.minute))
                                }
                            ) {
                                Row(Modifier.padding(horizontal = 14.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("%02d:%02d".format(slot.hour, slot.minute), style = MaterialTheme.typography.titleLarge)
                                    Text("Нажми, чтобы изменить", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSecondaryContainer)
                                }
                            }
                            if (slot.timeEditing) {
                                TimeWheel(slot.draftHour, slot.draftMinute, onChange = { h, m -> slot.draftHour = h; slot.draftMinute = m })
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                    TextButton(onClick = {
                                        dismissInput("cancel_time_${index + 1}")
                                        slot.timeEditing = false
                                        DiagnosticStore.add(this@MainActivity, "${stamp()} | UI_TIME_EDIT_CANCELLED | slot=${index + 1}")
                                    }) { Text("Отмена") }
                                    Button(onClick = {
                                        dismissInput("save_time_${index + 1}")
                                        slot.hour = slot.draftHour
                                        slot.minute = slot.draftMinute
                                        slot.timeEditing = false
                                        DiagnosticStore.add(this@MainActivity, "${stamp()} | UI_TIME_EDIT_SAVED | slot=${index + 1} | time=%02d:%02d".format(slot.hour, slot.minute))
                                    }) { Text("Готово") }
                                }
                            }
                            if (slot.editing) {
                                var draft by remember(index) { mutableStateOf(slot.message) }
                                OutlinedTextField(value = draft, onValueChange = { if (it.length <= 3000) draft = it }, label = { Text("Текст сообщения") }, modifier = Modifier.fillMaxWidth(), minLines = 3, maxLines = 6)
                                Text("${draft.length}/3000", style = MaterialTheme.typography.labelSmall)
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                    TextButton(onClick = { dismissInput("cancel_message"); if (slot.message.isBlank()) slots.removeAt(index) else slot.editing = false }) { Text("Отмена") }
                                    Button(onClick = { dismissInput("save_message"); if (draft.isBlank()) Toast.makeText(this@MainActivity, "Введи текст сообщения", Toast.LENGTH_SHORT).show() else { slot.message = draft; slot.editing = false; DiagnosticStore.add(this@MainActivity, "${stamp()} | UI_MESSAGE_SLOT_SAVED | slot=${index + 1} | time=%02d:%02d | textLength=${draft.length}".format(slot.hour, slot.minute)) } }) { Text("Сохранить") }
                                }
                            } else {
                                Text(slot.message, style = MaterialTheme.typography.bodyMedium, maxLines = 3)
                                TextButton(onClick = { dismissInput("edit_message"); slot.editing = true }) { Text("Изменить сообщение") }
                            }
                        }
                    }
                }
                if (slots.size < 3) OutlinedButton(onClick = { dismissInput("add_time"); slots.add(TimeMessageUi()) }, modifier = Modifier.fillMaxWidth()) { Text("+ Добавить время") }

                HorizontalDivider()
                Text("Управление работой", style = MaterialTheme.typography.titleLarge)
                Button(onClick = {
                    dismissInput("apply_schedule")
                    try {
                        if (!saveClone() || !cloneConfirmed || cloneLabel.trim().length < 3) throw IllegalStateException("Сначала выбери клон, подтверди синюю метку и сохрани ярлык чата")
                        if (!isServiceEnabled()) throw IllegalStateException("Не включена служба специальных возможностей")
                        if (Build.VERSION.SDK_INT >= 31 && !canExactAlarms()) {
                            DiagnosticStore.add(this@MainActivity, "${stamp()} | ACTION_REQUEST_EXACT_ALARM_PERMISSION | requested=true")
                            startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
                            throw IllegalStateException("Разреши точные будильники и снова нажми «Применить работу программы»")
                        }
                        if (slots.isEmpty()) throw IllegalStateException("Добавь хотя бы одно время")
                        if (slots.any { it.editing || it.message.isBlank() }) throw IllegalStateException("Сначала сохрани текст каждого сообщения")
                        val minuteKeys = slots.map { it.hour * 60 + it.minute }
                        if (minuteKeys.distinct().size != minuteKeys.size) throw IllegalStateException("У каждого запуска должно быть своё время")
                        val entries = slots.map { ScheduledTestStore.Entry("%02d:%02d".format(it.hour, it.minute), it.message) }
                        val times = ScheduledTestStore.scheduleEntries(this@MainActivity, entries)
                        scheduleStatus = "Активно: ${times.size} запуск(а/ов)"
                        DiagnosticStore.add(this@MainActivity, "${stamp()} | UI_SCHEDULE_APPLIED | slots=${times.size} | keyboardHidden=true | activityMoveToBackRequested=true")
                        Toast.makeText(this@MainActivity, "Расписание применено. Приложение свернётся.", Toast.LENGTH_LONG).show()
                        refresh(); window.decorView.postDelayed({ moveTaskToBack(true) }, 350)
                    } catch (e: Exception) {
                        scheduleStatus = "Ошибка: ${e.message}"
                        DiagnosticStore.add(this@MainActivity, "${stamp()} | UI_SCHEDULE_APPLY_FAILED | ${e.javaClass.simpleName}:${e.message}")
                        refreshLogOnly()
                    }
                }, modifier = Modifier.fillMaxWidth()) { Text("Применить работу программы") }
                OutlinedButton(onClick = { dismissInput("stop_schedule"); ScheduledTestStore.cancel(this@MainActivity); scheduleStatus = "Расписание отключено"; Toast.makeText(this@MainActivity, "Работа расписания отключена", Toast.LENGTH_SHORT).show(); refresh() }, modifier = Modifier.fillMaxWidth()) { Text("Отключить работу программы") }
                Text(scheduleStatus, style = MaterialTheme.typography.bodyMedium)

                HorizontalDivider()
                Text("Журнал", style = MaterialTheme.typography.titleLarge)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { dismissInput("refresh_log"); refresh() }, modifier = Modifier.weight(1f)) { Text("Обновить") }
                    Button(onClick = { copyReport() }, modifier = Modifier.weight(1f)) { Text("Копировать весь текст с логом") }
                }
                Text("Записей: ${logs.size}. Журнал сохраняется автоматически.", style = MaterialTheme.typography.bodySmall)
                logs.forEach { Text(it, style = MaterialTheme.typography.bodySmall) }
            }
            }
            if (showFactoryReset) {
                AlertDialog(
                    onDismissRequest = { showFactoryReset = false },
                    title = { Text("Сбросить приложение?") },
                    text = { Text("Будут удалены сохранённые чаты, расписания, сообщения, выбор WhatsApp и локальные настройки. Приложение откроется как после первой установки. Разрешения Android (спецвозможности, батарея и точные будильники) автоматически не отзываются.") },
                    confirmButton = {
                        TextButton(onClick = {
                            showFactoryReset = false
                            ScheduledTestStore.cancel(this@MainActivity)
                            stopService(Intent(this@MainActivity, ScheduleKeepAliveService::class.java))
                            val prefsDir = java.io.File(applicationInfo.dataDir, "shared_prefs")
                            prefsDir.listFiles()?.filter { it.name.endsWith(".xml") }?.forEach { f ->
                                val prefName = f.name.removeSuffix(".xml")
                                getSharedPreferences(prefName, Context.MODE_PRIVATE).edit().clear().commit()
                            }
                            Toast.makeText(this@MainActivity, "Данные сброшены. Приложение перезапускается.", Toast.LENGTH_LONG).show()
                            recreate()
                        }) { Text("Сбросить", color = MaterialTheme.colorScheme.error) }
                    },
                    dismissButton = { TextButton(onClick = { showFactoryReset = false }) { Text("Отмена") } }
                )
            }
        }
    }

    @Composable private fun PermissionDot(label: String, granted: Boolean, onClick: () -> Unit) {
        Column(Modifier.width(100.dp).clickable(onClick = onClick).padding(4.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Box(Modifier.size(34.dp).background(if (granted) Color(0xFF2EAD62) else Color(0xFFD94A45), CircleShape))
            Text(label, style = MaterialTheme.typography.labelMedium, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            Text(if (granted) "Есть" else "Нужно", style = MaterialTheme.typography.labelSmall, color = if (granted) Color(0xFF2EAD62) else MaterialTheme.colorScheme.error)
        }
    }

    @Composable private fun TimeWheel(hour: Int, minute: Int, onChange: (Int, Int) -> Unit) {
        AndroidView(factory = { context ->
            LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
                val h = NumberPicker(context).apply { minValue = 0; maxValue = 23; value = hour; wrapSelectorWheel = true; setFormatter { "%02d".format(it) }; contentDescription = "Часы"; lockPickerKeyboard(this);  }
                val sep = TextView(context).apply { text = ":"; textSize = 28f; gravity = Gravity.CENTER }
                val m = NumberPicker(context).apply { minValue = 0; maxValue = 59; value = minute; wrapSelectorWheel = true; setFormatter { "%02d".format(it) }; contentDescription = "Минуты"; lockPickerKeyboard(this) }
                h.setOnValueChangedListener { _, _, v -> onChange(v, m.value) }
                m.setOnValueChangedListener { _, _, v -> onChange(h.value, v) }
                addView(h, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)); addView(sep, LinearLayout.LayoutParams(32, ViewGroup.LayoutParams.WRAP_CONTENT)); addView(m, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            }
        }, update = { view ->
            val h = view.getChildAt(0) as NumberPicker; val m = view.getChildAt(2) as NumberPicker
            if (h.value != hour) h.value = hour
            if (m.value != minute) m.value = minute
        }, modifier = Modifier.fillMaxWidth().height(120.dp))
    }

    private fun lockPickerKeyboard(picker: NumberPicker) {
        val id = resources.getIdentifier("numberpicker_input", "id", "android")
        if (id != 0) picker.findViewById<android.widget.EditText>(id)?.apply { showSoftInputOnFocus = false; isFocusable = false; isFocusableInTouchMode = false; isCursorVisible = false }
    }

    private fun isServiceEnabled(): Boolean {
        val manager = getSystemService(ACCESSIBILITY_SERVICE) as AccessibilityManager
        val expected = ComponentName(this, WhatsAppAccessibilityService::class.java)
        return manager.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK).any { it.resolveInfo.serviceInfo.let { info -> ComponentName(info.packageName, info.name) == expected } }
    }
    private fun isBatteryExempt() = try { (getSystemService(POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName) } catch (_: Exception) { false }
    private fun canExactAlarms() = Build.VERSION.SDK_INT < 31 || (getSystemService(Context.ALARM_SERVICE) as android.app.AlarmManager).canScheduleExactAlarms()
    private fun stamp() = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault()).format(Date())
}
