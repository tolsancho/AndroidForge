TS Моя работа — v0.24.60
BUILD ID: TS-CHAT-HEADER-SPACING-POLISH-02460
versionCode: 91
Основа: v0.24.59_CHAT_CARD_HEADER_ALIGNMENT.

Точечные визуальные изменения по четырём референсам:
1. Зелёная плашка режима опущена на 10 dp относительно v0.24.59 (offset y: 16 → 26 dp), чтобы её верх совпадал с верхом строчных букв заголовка контакта. Заголовок не перемещался; ширина/размер плашки не менялись.
2. «Ред.» опущено на 8 dp (offset y: 0 → 8 dp), чтобы нижний край совпадал с нижним краем строки количества интервалов. Горизонтальная координата и размер не менялись.
3. В строке времени/действий заменено распределение SpaceBetween на SpaceEvenly; удалён нулевой Spacer в конце. Это даёт равные внешние и внутренние промежутки по горизонтали между тремя элементами. Высота строки не менялась.
4. Круг большой стрелки уменьшен с 46 dp до 38 dp. Размер самой стрелки оставлен 27 dp, логика раскрытия/сворачивания не менялась.

Изменён только MainActivity.kt среди исходников приложения, плюс метаданные версии.
SEND/READ/CHECK, привязка ярлыков, расписания, очередь, будильники и хранение данных не менялись.
Gradle/APK-сборка и тестирование на телефоне не выполнялись.


## v0.24.61 — Chat header pixel alignment

Visual-only adjustment: align the mode badge top with the chat title, align the “Ред.” bottom with the interval count baseline, and make the three horizontal gaps in the expanded interval action row equal. Shortcut lookup and all execution logic are unchanged. BUILD ID: TS-CHAT-HEADER-PIXEL-ALIGNMENT-02461.
