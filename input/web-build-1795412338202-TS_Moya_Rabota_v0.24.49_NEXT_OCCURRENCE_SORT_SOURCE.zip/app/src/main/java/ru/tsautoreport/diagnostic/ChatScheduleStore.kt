package ru.tsautoreport.diagnostic

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class WorkInterval(val id:String=UUID.randomUUID().toString(), val time:String="00:00", val message:String="", val mode:String="QUEUE", val dates:String="")
data class WorkChat(val id:String=UUID.randomUUID().toString(), val launcherLabel:String="", val profile:String="clone", val confirmed:Boolean=false, val intervals:List<WorkInterval> = emptyList(), val behavior:String="SEND", val enabled:Boolean=true)

object ChatScheduleStore {
    private const val PREF="ts_work_model"
    private const val KEY="chats"
    fun all(c:Context):List<WorkChat> = runCatching {
        val a=JSONArray(c.getSharedPreferences(PREF,0).getString(KEY,"[]"))
        (0 until a.length()).map { i -> val o=a.getJSONObject(i); val ia=o.optJSONArray("intervals")?:JSONArray();
            WorkChat(o.getString("id"),o.optString("label"),o.optString("profile","clone"),o.optBoolean("confirmed"), (0 until ia.length()).map { j -> val x=ia.getJSONObject(j); WorkInterval(x.getString("id"),x.optString("time","00:00"),x.optString("message"),"QUEUE",x.optString("dates","")) }, o.optString("behavior","SEND"), o.optBoolean("enabled",true)) }
    }.getOrDefault(emptyList())
    fun save(c:Context, chats:List<WorkChat>):Boolean {
        require(chats.size<=10) { "Максимум 10 чатов" }; require(chats.all{it.intervals.size<=24}) { "Максимум 24 интервала на чат" }
        val a=JSONArray(); chats.forEach { chat -> val o=JSONObject().put("id",chat.id).put("label",chat.launcherLabel).put("profile",chat.profile).put("confirmed",chat.confirmed).put("behavior",chat.behavior).put("enabled",chat.enabled); val ia=JSONArray(); chat.intervals.forEach { ia.put(JSONObject().put("id",it.id).put("time",it.time).put("message",it.message).put("mode",it.mode).put("dates",it.dates)) }; o.put("intervals",ia); a.put(o) }
        return c.getSharedPreferences(PREF,0).edit().putString(KEY,a.toString()).commit()
    }
    fun chat(c:Context,id:String)=all(c).firstOrNull{it.id==id}
    fun setPending(c:Context,id:String){ c.getSharedPreferences(PREF,0).edit().putString("pending_chat",id).commit() }
    fun pending(c:Context):WorkChat?=chat(c,c.getSharedPreferences(PREF,0).getString("pending_chat","").orEmpty())
    fun clearPending(c:Context){c.getSharedPreferences(PREF,0).edit().remove("pending_chat").commit()}
    fun updateInterval(c:Context,chatId:String,intervalId:String,transform:(WorkInterval)->WorkInterval):Boolean {
        val chats=all(c); val next=chats.map { ch -> if(ch.id!=chatId) ch else ch.copy(intervals=ch.intervals.map{if(it.id==intervalId) transform(it) else it}) }; return save(c,next)
    }
}
