package ru.tsautoreport.diagnostic

import android.content.Context
import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo

/** Persists a user-trained launcher selector; it stores UI metadata, never WhatsApp private data. */
object ShortcutCaptureStore {
    private const val PREFS = "trained_launcher_shortcuts"
    data class Selector(val chatId:String,val launcher:String,val text:String,val description:String,val viewId:String,val className:String,val bounds:String,val capturedAt:Long,val conversationObserved:Boolean,val clickedNodeUniqueId:String,val clickedNodeViewId:String,val clickedNodeClass:String,val clickedNodeBounds:String,val clickableAncestorViewId:String,val clickableAncestorClass:String,val clickableAncestorBounds:String)
    data class Summary(val launcher:String,val visibleName:String,val viewId:String,val className:String,val capturedAt:Long)

    fun begin(context:Context, chatId:String, launcher:String="") {
        context.getSharedPreferences(PREFS,0).edit().putString("pending_chat",chatId).putString("pending_launcher",launcher)
            .remove("pending_text").remove("pending_desc").remove("pending_view_id").remove("pending_class").remove("pending_bounds")
            .remove("pending_click_unique_id").remove("pending_click_view_id").remove("pending_click_class").remove("pending_click_bounds")
            .remove("pending_clickable_view_id").remove("pending_clickable_class").remove("pending_clickable_bounds")
            .putBoolean("pending_conversation",false).putBoolean("pending_click_observed",false).putLong("pending_at",System.currentTimeMillis()).commit()
        DiagnosticStore.add(context,"${stamp()} | SHORTCUT_CAPTURE_STARTED | chatId=$chatId | method=manual_launcher_tap")
    }

    fun isCapturing(context:Context)=context.getSharedPreferences(PREFS,0).getString("pending_chat",null)!=null
    fun hasVisibleCapture(context:Context):Boolean { val p=context.getSharedPreferences(PREFS,0); return p.getString("pending_text","").orEmpty().isNotBlank() || p.getString("pending_desc","").orEmpty().isNotBlank() }
    fun isVerifying(context:Context)=context.getSharedPreferences(PREFS,0).getString("verify_chat",null)!=null

    // Separate post-binding verification: keep the trained selector intact while testing it.
    fun beginVerification(context:Context, chatId:String) {
        context.getSharedPreferences(PREFS,0).edit().putString("verify_chat",chatId)
            .putBoolean("verify_whatsapp",false).putLong("verify_started",System.currentTimeMillis()).commit()
        DiagnosticStore.add(context,"${stamp()} | SHORTCUT_VERIFY_STARTED | chatId=$chatId | saved_selector_preserved=true")
    }
    fun markVerificationForeground(context:Context, evidence:String) {
        val p=context.getSharedPreferences(PREFS,0)
        val id=p.getString("verify_chat",null) ?: return
        p.edit().putBoolean("verify_whatsapp",true).putString("verify_evidence",evidence.take(180)).commit()
        DiagnosticStore.add(context,"${stamp()} | SHORTCUT_VERIFY_WHATSAPP_OPENED | chatId=$id | evidence=${evidence.take(180)}")
    }
    fun canConfirmVerification(context:Context,chatId:String):Boolean {
        val p=context.getSharedPreferences(PREFS,0)
        return p.getString("verify_chat",null)==chatId && p.getBoolean("verify_whatsapp",false)
    }
    fun finishVerification(context:Context,chatId:String,confirmed:Boolean) {
        val p=context.getSharedPreferences(PREFS,0)
        if(p.getString("verify_chat",null)==chatId) p.edit().remove("verify_chat").remove("verify_whatsapp").remove("verify_started").remove("verify_evidence").commit()
        DiagnosticStore.add(context,"${stamp()} | SHORTCUT_VERIFY_FINISHED | chatId=$chatId | user_confirmed=$confirmed | selector_preserved=true")
    }
    fun pendingChat(context:Context)=context.getSharedPreferences(PREFS,0).getString("pending_chat",null)

    fun capture(context:Context, launcher:String, node:AccessibilityNodeInfo, clicked:Boolean=false):Boolean {
        val p=context.getSharedPreferences(PREFS,0)
        if(p.getString("pending_chat",null)==null) return false
        val nodePackage=node.packageName?.toString().orEmpty()
        if(nodePackage.isNotBlank() && nodePackage!=launcher) {
            DiagnosticStore.add(context,"${stamp()} | SHORTCUT_CAPTURE_REJECTED | reason=SOURCE_PACKAGE_MISMATCH | expected=$launcher | actual=$nodePackage | clicked=$clicked")
            return false
        }

        val rect=Rect()
        runCatching{node.getBoundsInScreen(rect)}
        // The clicked AccessibilityNodeInfo is the primary evidence. Ancestors are
        // inspected only to recover the visible caption and the launcher tile container.
        var bestText=node.text?.toString().orEmpty().trim()
        var bestDesc=node.contentDescription?.toString().orEmpty().trim()
        var bestViewId=node.viewIdResourceName.orEmpty()
        var bestClass=node.className?.toString().orEmpty()
        var clickableViewId=""
        var clickableClass=""
        var clickableBounds=""
        var parent=try{node.parent}catch(_:Exception){null}
        var hops=0
        while(parent!=null && hops++<8){
            if(bestText.isBlank()) bestText=parent.text?.toString().orEmpty().trim()
            if(bestDesc.isBlank()) bestDesc=parent.contentDescription?.toString().orEmpty().trim()
            if(bestViewId.isBlank()) bestViewId=parent.viewIdResourceName.orEmpty()
            if(bestClass.isBlank()) bestClass=parent.className?.toString().orEmpty()
            if(clickableViewId.isBlank() && parent.isClickable) {
                clickableViewId=parent.viewIdResourceName.orEmpty()
                clickableClass=parent.className?.toString().orEmpty()
                val pr=Rect(); runCatching{parent.getBoundsInScreen(pr)}
                clickableBounds=listOf(pr.left,pr.top,pr.right,pr.bottom).joinToString(",")
            }
            val next=try{parent.parent}catch(_:Exception){null}
            try{parent.recycle()}catch(_:Exception){}
            parent=next
        }
        val text=bestText.ifBlank { p.getString("pending_text", "").orEmpty() }.take(120)
        val desc=bestDesc.ifBlank { p.getString("pending_desc", "").orEmpty() }.take(160)
        val viewId=bestViewId.take(180)
        val cls=bestClass.take(180)
        val bounds=listOf(rect.left,rect.top,rect.right,rect.bottom).joinToString(",")
        val edit=p.edit().putString("pending_launcher",launcher).putString("pending_text",text).putString("pending_desc",desc)
            .putString("pending_view_id",viewId).putString("pending_class",cls).putString("pending_bounds",bounds)
            .putLong("pending_at",System.currentTimeMillis())
        if(clicked) {
            val uniqueId=if(android.os.Build.VERSION.SDK_INT>=33) runCatching{node.uniqueId.orEmpty()}.getOrDefault("") else ""
            edit.putString("pending_click_unique_id",uniqueId.take(200))
                .putString("pending_click_view_id",node.viewIdResourceName.orEmpty().take(180))
                .putString("pending_click_class",node.className?.toString().orEmpty().take(180))
                .putString("pending_click_bounds",bounds)
                .putString("pending_clickable_view_id",clickableViewId.take(180))
                .putString("pending_clickable_class",clickableClass.take(180))
                .putString("pending_clickable_bounds",clickableBounds.take(80))
                .putBoolean("pending_click_observed",true)
        }
        val ok=edit.commit()
        DiagnosticStore.add(context,"${stamp()} | SHORTCUT_CAPTURE_NODE | launcher=$launcher | clicked=$clicked | nodeUniqueId=${if(clicked && android.os.Build.VERSION.SDK_INT>=33) runCatching{node.uniqueId.orEmpty()}.getOrDefault("") else ""} | nodeViewId=${node.viewIdResourceName.orEmpty()} | nodeClass=${node.className} | clickableViewId=$clickableViewId | text=$text | desc=$desc | viewId=$viewId | class=$cls | bounds=$bounds | saved=$ok")
        return ok
    }

    fun summary(context:Context,chatId:String):Summary? {
        val p=context.getSharedPreferences(PREFS,0)
        val launcher=p.getString("$chatId.launcher",null) ?: return null
        val text=p.getString("$chatId.text","").orEmpty()
        val desc=p.getString("$chatId.desc","").orEmpty()
        return Summary(launcher, text.ifBlank{desc}, p.getString("$chatId.viewId","").orEmpty(), p.getString("$chatId.class","").orEmpty(), p.getLong("$chatId.capturedAt",0L))
    }

    fun observeLauncher(context:Context, launcher:String) {
        if (launcher.isBlank()) return
        val p=context.getSharedPreferences(PREFS,0)
        if (p.getString("pending_chat",null)!=null) {
            p.edit().putString("pending_launcher",launcher).commit()
            DiagnosticStore.add(context,"${stamp()} | SHORTCUT_CAPTURE_LAUNCHER_OBSERVED | launcher=$launcher")
        }
    }

    fun markConversation(context:Context, launcher:String, evidence:String) {
        val p=context.getSharedPreferences(PREFS,0)
        if (p.getString("pending_chat",null)==null) return
        val chosenLauncher = p.getString("pending_launcher","").orEmpty().ifBlank { launcher.ifBlank { "launcher_not_reported" } }
        val safeEvidence = evidence.take(180).ifBlank { "WhatsApp_Conversation_window" }
        p.edit().putString("pending_launcher",chosenLauncher)
            .putString("pending_text",p.getString("pending_text","").orEmpty().ifBlank { safeEvidence })
            .putBoolean("pending_conversation",true).putLong("pending_at",System.currentTimeMillis()).commit()
        DiagnosticStore.add(context,"${stamp()} | SHORTCUT_CAPTURE_CONVERSATION_OBSERVED | launcher=$chosenLauncher | evidence=$safeEvidence")
    }

    fun markConversation(context:Context) {
        val p=context.getSharedPreferences(PREFS,0); if(p.getString("pending_chat",null)!=null) p.edit().putBoolean("pending_conversation",true).commit()
    }

    fun canConfirm(context:Context,chatId:String):Boolean {
        val p=context.getSharedPreferences(PREFS,0)
        val expected=ChatScheduleStore.chat(context,chatId)?.launcherLabel.orEmpty().trim()
        val captured=p.getString("pending_text","").orEmpty().ifBlank { p.getString("pending_desc","").orEmpty() }.trim()
        // Launcher labels may be ellipsized (for example, "Я Билайн Н…") and therefore
        // must NOT be compared with the full chat label typed in the app. Binding is based
        // on the actual user-clicked launcher node + subsequent WhatsApp foreground event.
        return p.getString("pending_chat",null)==chatId && p.getString("pending_launcher","").orEmpty().isNotBlank() &&
            expected.length>=3 && captured.isNotBlank() && p.getBoolean("pending_click_observed",false) && p.getBoolean("pending_conversation",false)
    }

    fun confirm(context:Context,chatId:String):Boolean {
        if(!canConfirm(context,chatId)) return false
        val p=context.getSharedPreferences(PREFS,0)
        val ok=p.edit().putString("$chatId.launcher",p.getString("pending_launcher","")).putString("$chatId.text",p.getString("pending_text","")).putString("$chatId.desc",p.getString("pending_desc","")).putString("$chatId.viewId",p.getString("pending_view_id","")).putString("$chatId.class",p.getString("pending_class","")).putString("$chatId.bounds",p.getString("pending_bounds","")).putLong("$chatId.capturedAt",p.getLong("pending_at",0L))
            .putString("$chatId.clickUniqueId",p.getString("pending_click_unique_id","")).putString("$chatId.clickViewId",p.getString("pending_click_view_id","")).putString("$chatId.clickClass",p.getString("pending_click_class","")).putString("$chatId.clickBounds",p.getString("pending_click_bounds","")).putString("$chatId.clickableViewId",p.getString("pending_clickable_view_id","")).putString("$chatId.clickableClass",p.getString("pending_clickable_class","")).putString("$chatId.clickableBounds",p.getString("pending_clickable_bounds",""))
            .remove("pending_chat").remove("pending_launcher").remove("pending_text").remove("pending_desc").remove("pending_view_id").remove("pending_class").remove("pending_bounds").remove("pending_click_unique_id").remove("pending_click_view_id").remove("pending_click_class").remove("pending_click_bounds").remove("pending_clickable_view_id").remove("pending_clickable_class").remove("pending_clickable_bounds").remove("pending_conversation").remove("pending_click_observed").remove("pending_at").commit()
        DiagnosticStore.add(context,"${stamp()} | SHORTCUT_CAPTURE_CONFIRMED | chatId=$chatId | saved=$ok | user_confirmed=true")
        return ok
    }

    fun selector(context:Context,chatId:String):Selector? {
        val p=context.getSharedPreferences(PREFS,0); val launcher=p.getString("$chatId.launcher",null)?:return null
        return Selector(chatId,launcher,p.getString("$chatId.text","").orEmpty(),p.getString("$chatId.desc","").orEmpty(),p.getString("$chatId.viewId","").orEmpty(),p.getString("$chatId.class","").orEmpty(),p.getString("$chatId.bounds","").orEmpty(),p.getLong("$chatId.capturedAt",0L),true,p.getString("$chatId.clickUniqueId","").orEmpty(),p.getString("$chatId.clickViewId","").orEmpty(),p.getString("$chatId.clickClass","").orEmpty(),p.getString("$chatId.clickBounds","").orEmpty(),p.getString("$chatId.clickableViewId","").orEmpty(),p.getString("$chatId.clickableClass","").orEmpty(),p.getString("$chatId.clickableBounds","").orEmpty())
    }
    fun cancel(context:Context){context.getSharedPreferences(PREFS,0).edit().remove("pending_chat").remove("pending_launcher").remove("pending_text").remove("pending_desc").remove("pending_view_id").remove("pending_class").remove("pending_bounds").remove("pending_click_unique_id").remove("pending_click_view_id").remove("pending_click_class").remove("pending_click_bounds").remove("pending_clickable_view_id").remove("pending_clickable_class").remove("pending_clickable_bounds").remove("pending_conversation").remove("pending_click_observed").remove("pending_at").commit()}
    fun delete(context:Context,chatId:String){val e=context.getSharedPreferences(PREFS,0).edit(); listOf("launcher","text","desc","viewId","class","bounds","capturedAt","clickUniqueId","clickViewId","clickClass","clickBounds","clickableViewId","clickableClass","clickableBounds").forEach{e.remove("$chatId.$it")};e.commit()}
    private fun stamp()=java.text.SimpleDateFormat("HH:mm:ss.SSS",java.util.Locale.getDefault()).format(java.util.Date())
}
