package ru.tsautoreport.diagnostic

import android.content.ComponentName
import android.content.pm.LauncherApps
import android.os.Bundle
import android.os.UserHandle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class Candidate(
    val title: String,
    val packageName: String,
    val component: ComponentName,
    val user: UserHandle,
    val profileLabel: String
)

class MainActivity : ComponentActivity() {
    private val launcherApps by lazy { getSystemService(LauncherApps::class.java) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) {
                    val found = remember { mutableStateListOf<Candidate>() }
                    var diagnostic by remember {
                        mutableStateOf("Нажми «Найти WhatsApp». Приложение ничего не отправляет и не читает переписку.")
                    }
                    Column(
                        Modifier.fillMaxSize().padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text("TS AutoReport", style = MaterialTheme.typography.headlineMedium)
                        Text("Диагностика основного WhatsApp и клона")
                        Text(diagnostic)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = {
                                found.clear()
                                diagnostic = scan(found)
                            }) { Text("Найти WhatsApp") }
                        }
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(found) { item ->
                                Card(Modifier.fillMaxWidth()) {
                                    Column(
                                        Modifier.fillMaxWidth().padding(12.dp),
                                        verticalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(item.title, style = MaterialTheme.typography.titleMedium)
                                        Text("Пакет: ${item.packageName}")
                                        Text(item.profileLabel)
                                        Button(onClick = { diagnostic = launch(item) }) {
                                            Text("Запустить этот экземпляр")
                                        }
                                    }
                                }
                            }
                        }
                        Text(
                            "Важно: два найденных пункта ещё не доказывают, что служба Accessibility сможет различить экземпляры. Это будет следующий тест.",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        }
    }

    private fun scan(out: MutableList<Candidate>): String {
        return try {
            val users = launcherApps.profiles
            val details = mutableListOf<String>()
            var count = 0
            users.forEachIndexed { index, user ->
                val activities = launcherApps.getActivityList("com.whatsapp", user)
                val profile = "Профиль Android ${index + 1}: $user"
                if (activities.isEmpty()) {
                    details += "$profile — WhatsApp не обнаружен"
                } else {
                    activities.forEach { info ->
                        out.add(
                            Candidate(
                                title = info.label?.toString() ?: "WhatsApp",
                                packageName = info.applicationInfo.packageName,
                                component = info.componentName,
                                user = user,
                                profileLabel = profile
                            )
                        )
                        count++
                        details += "$profile — найдено: ${info.label}"
                    }
                }
            }
            if (count == 0) {
                "Доступных точек запуска WhatsApp не найдено. Возможно, клон скрыт системными ограничениями профиля."
            } else {
                "Найдено точек запуска: $count\n" + details.joinToString("\n")
            }
        } catch (e: SecurityException) {
            "Android запретил доступ к одному из профилей: ${e.message}"
        } catch (e: Exception) {
            "Ошибка: ${e.javaClass.simpleName}: ${e.message}"
        }
    }

    private fun launch(item: Candidate): String {
        return try {
            launcherApps.startMainActivity(item.component, item.user, null, null)
            "Команда запуска отправлена: ${item.title}. Посмотри, какой именно WhatsApp открылся, и сообщи результат."
        } catch (e: SecurityException) {
            "Запуск этого профиля запрещён Android: ${e.message}"
        } catch (e: Exception) {
            "Не удалось запустить: ${e.javaClass.simpleName}: ${e.message}"
        }
    }
}
