package ru.tsautoreport.diagnostic

import android.content.Context

/** Stores Android-published WhatsApp conversation shortcut IDs bound to a specific Android user profile. */
object ShortcutBindingStore {
    private const val PREFS = "chat_shortcut_bindings"
    data class Binding(val label: String, val user: String, val serial: Long, val uid: Int, val shortcutId: String)
    fun parse(row: String): Binding? {
        val p = row.split('\t')
        if (p.size != 5) return null
        return try { Binding(p[0], p[1], p[2].toLong(), p[3].toInt(), p[4]) } catch (_: Exception) { null }
    }
    fun bindings(context: Context): List<String> = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .getString("rows", "").orEmpty().split('\n').filter { it.isNotBlank() }.reversed()
    fun save(context: Context, user: String, serial: Long, uid: Int, shortcutId: String, label: String): Boolean {
        val cleanLabel = label.replace('\n', ' ').replace('\t', ' ').take(100).ifBlank { shortcutId }
        val row = listOf(cleanLabel, user, serial, uid, shortcutId).joinToString("\t")
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val rows = prefs.getString("rows", "").orEmpty().split('\n').filter { it.isNotBlank() }.toMutableList()
        rows.removeAll { old -> parse(old)?.let { it.user == user && it.shortcutId == shortcutId } == true }
        rows.add(row)
        val committed = prefs.edit().putString("rows", rows.joinToString("\n")).commit()
        val verified = committed && prefs.getString("rows", "").orEmpty().split('\n').filter { it.isNotBlank() } == rows
        DiagnosticStore.add(context, "${stamp()} | CHAT_SHORTCUT_BOUND | label=$cleanLabel | user=$user | serial=$serial | uid=$uid | shortcutId=$shortcutId | verified=$verified")
        return verified
    }
    fun delete(context: Context, row: String) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val rows = prefs.getString("rows", "").orEmpty().split('\n').filter { it.isNotBlank() }.toMutableList()
        rows.remove(row)
        prefs.edit().putString("rows", rows.joinToString("\n")).commit()
        DiagnosticStore.add(context, "${stamp()} | CHAT_SHORTCUT_BINDING_DELETED | label=${row.substringBefore('\t')}")
    }
    private fun stamp() = java.text.SimpleDateFormat("HH:mm:ss.SSS", java.util.Locale.getDefault()).format(java.util.Date())
}
