package ru.tsautoreport.diagnostic

import android.app.ActivityManager
import android.content.Context
import android.content.pm.LauncherApps
import android.os.Build
import android.os.UserManager

/** Read-only audit of public profile/app metadata. It never claims an Accessibility event belongs to a profile. */
object ProfileAudit {
    data class Entry(
        val user: String,
        val serial: Long,
        val uid: Int,
        val packageName: String,
        val processName: String,
        val versionName: String,
        val versionCode: Long,
        val component: String,
        val sourceDir: String
    )

    fun discover(context: Context): List<Entry> {
        val launcher = context.getSystemService(Context.LAUNCHER_APPS_SERVICE) as LauncherApps
        val users = context.getSystemService(Context.USER_SERVICE) as UserManager
        return launcher.profiles.flatMap { user ->
            launcher.getActivityList("com.whatsapp", user).mapNotNull { activity ->
                val app = activity.applicationInfo
                val pkgInfo = try { context.packageManager.getPackageInfo("com.whatsapp", 0) } catch (_: Exception) { null }
                val versionCode = if (Build.VERSION.SDK_INT >= 28) pkgInfo?.longVersionCode ?: -1L else legacyVersionCode(pkgInfo)
                Entry(
                    user = user.toString(),
                    serial = try { users.getSerialNumberForUser(user) } catch (_: Exception) { -1L },
                    uid = app.uid,
                    packageName = app.packageName ?: "com.whatsapp",
                    processName = app.processName ?: "unknown",
                    versionName = pkgInfo?.versionName ?: "unknown",
                    versionCode = versionCode,
                    component = activity.componentName.flattenToShortString(),
                    sourceDir = app.sourceDir ?: "unknown"
                )
            }
        }.distinctBy { "${it.user}|${it.uid}|${it.component}" }
    }

    @Suppress("DEPRECATION")
    private fun legacyVersionCode(info: android.content.pm.PackageInfo?): Long = info?.versionCode?.toLong() ?: -1L

    fun runningProcessReport(context: Context, entries: List<Entry>): String {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val running = try { am.runningAppProcesses.orEmpty() } catch (_: Exception) { emptyList() }
        if (running.isEmpty()) return "runningProcesses=not_visible_or_empty"
        val candidates = entries.map { it.uid }.toSet()
        val matches = running.filter { it.uid in candidates || it.processName.contains("com.whatsapp") }
        return if (matches.isEmpty()) "runningProcesses=WhatsApp_process_not_exposed_to_this_app (visible=${running.size})"
        else "runningProcesses=" + matches.joinToString(";") { "${it.processName}:uid=${it.uid}:importance=${it.importance}" }
    }
}
