package ru.tsautoreport.diagnostic

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.LauncherApps
import android.content.pm.ShortcutInfo
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import android.view.accessibility.AccessibilityManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    private val launcherApps by lazy { getSystemService(Context.LAUNCHER_APPS_SERVICE) as LauncherApps }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DiagnosticStore.add(this, "${stamp()} | APP_BUILD_ID | id=TS-BIND-012 | version=0.12-ts-shortcut-012 | versionCode=13")
        recordBootAndPersistenceCheck()
        ProfileBindingStore.verifyLoaded(this)
        setContent { Screen() }
    }

    override fun onResume() {
        super.onResume()
        DiagnosticStore.add(this, "${stamp()} | APP_RESUMED | bootCount=${currentBootCount()}")
    }

    /** The first app launch after a device reboot compares Android's BOOT_COUNT with the prior launch. */
    private fun recordBootAndPersistenceCheck() {
        val bootCount = currentBootCount()
        val prefs = getSharedPreferences("boot_audit_store", Context.MODE_PRIVATE)
        val previous = prefs.getInt("last_boot_count", -1)
        when {
            bootCount < 0 -> DiagnosticStore.add(this, "${stamp()} | BOOT_COUNT_UNAVAILABLE | reboot_test_cannot_be_verified")
            previous < 0 -> DiagnosticStore.add(this, "${stamp()} | BOOT_BASELINE_SET | bootCount=$bootCount | next_launch_after_reboot_will_be_checked=true")
            previous != bootCount -> {
                DiagnosticStore.add(this, "${stamp()} | DEVICE_REBOOT_DETECTED | previousBootCount=$previous | currentBootCount=$bootCount")
                val result = ProfileBindingStore.verifyLoaded(this)
                DiagnosticStore.add(this, "${stamp()} | BIND_LOAD_AFTER_REBOOT_${if (result.first) "VERIFIED" else "FAILED"} | count=${result.second} | bootCount=$bootCount")
            }
            else -> DiagnosticStore.add(this, "${stamp()} | SAME_BOOT_SESSION | bootCount=$bootCount | previousBootCount=$previous")
        }
        if (bootCount >= 0) prefs.edit().putInt("last_boot_count", bootCount).commit()
    }

    private fun currentBootCount(): Int = try {
        Settings.Global.getInt(contentResolver, Settings.Global.BOOT_COUNT, -1)
    } catch (_: Exception) { -1 }

    @Composable private fun Screen() {
        var enabled by remember { mutableStateOf(isServiceEnabled()) }
        var logs by remember { mutableStateOf(DiagnosticStore.read(this@MainActivity)) }
        var entries by remember { mutableStateOf<List<ProfileAudit.Entry>>(emptyList()) }
        var status by remember { mutableStateOf("Сначала проведи аудит профилей, затем привяжи тестовый чат.") }
        var auditDone by remember { mutableStateOf(false) }
        var label by remember { mutableStateOf("") }
        var observation by remember { mutableStateOf(ProfileBindingStore.observation(this@MainActivity)) }
        var bindings by remember { mutableStateOf(ProfileBindingStore.bindings(this@MainActivity)) }
        var bindingsLoaded by remember { mutableStateOf(ProfileBindingStore.verifyLoaded(this@MainActivity)) }
        var pending by remember { mutableStateOf(ProfileBindingStore.pending(this@MainActivity)) }
        var editingRow by remember { mutableStateOf<String?>(null) }
        var editingLabel by remember { mutableStateOf("") }
        var shortcutResults by remember { mutableStateOf<Map<String, List<ShortcutInfo>>>(emptyMap()) }
        var shortcutStatus by remember { mutableStateOf("Для точного запуска чата нужны ярлыки переписок WhatsApp. Сначала создай ярлык нужного чата в самом WhatsApp.") }
        var shortcutBindings by remember { mutableStateOf(ShortcutBindingStore.bindings(this@MainActivity)) }

        fun refresh() {
            enabled = isServiceEnabled()
            logs = DiagnosticStore.read(this@MainActivity)
            observation = ProfileBindingStore.observation(this@MainActivity)
            bindings = ProfileBindingStore.bindings(this@MainActivity)
            bindingsLoaded = ProfileBindingStore.verifyLoaded(this@MainActivity)
            pending = ProfileBindingStore.pending(this@MainActivity)
            shortcutBindings = ShortcutBindingStore.bindings(this@MainActivity)
        }
        fun audit() {
            try {
                entries = ProfileAudit.discover(this@MainActivity)
                auditDone = true
                val processReport = ProfileAudit.runningProcessReport(this@MainActivity, entries)
                val now = stamp()
                DiagnosticStore.add(this@MainActivity, "$now | PROFILE_API_AUDIT | count=${entries.size} | $processReport")
                entries.forEach { e ->
                    DiagnosticStore.add(this@MainActivity, "$now | PROFILE_ENTRY | user=${e.user} | serial=${e.serial} | uid=${e.uid} | pkg=${e.packageName} | process=${e.processName} | version=${e.versionName}/${e.versionCode} | component=${e.component} | sourceDir=${e.sourceDir}")
                }
                status = if (entries.isEmpty()) "LauncherApps не вернул доступных точек запуска WhatsApp."
                else "Найдено ${entries.size} точек запуска. UID/serial различают записи профилей, но не удостоверяют источник Accessibility-события."
                refresh()
            } catch (e: Exception) {
                auditDone = true
                status = "Ошибка публичного API: ${e.javaClass.simpleName}: ${e.message ?: "без подробностей"}"
                DiagnosticStore.add(this@MainActivity, "${stamp()} | PROFILE_API_AUDIT_ERROR | $status")
                refresh()
            }
        }
        fun startBinding(entry: ProfileAudit.Entry) {
            try {
                val component = ComponentName.unflattenFromString(entry.component)
                    ?: throw IllegalStateException("Некорректный компонент запуска")
                val user = launcherApps.profiles.firstOrNull { it.toString() == entry.user }
                    ?: throw IllegalStateException("Профиль больше не доступен; обнови аудит")
                val startedAt = System.currentTimeMillis()
                ProfileBindingStore.begin(this@MainActivity, ProfileBindingStore.Session(entry.user, entry.serial, entry.uid, entry.component, startedAt))
                launcherApps.startMainActivity(component, user, null, Bundle())
                Toast.makeText(this@MainActivity, "WhatsApp запущен. Открой нужный чат, затем вернись сюда.", Toast.LENGTH_LONG).show()
                refresh()
            } catch (e: Exception) {
                ProfileBindingStore.cancel(this@MainActivity)
                Toast.makeText(this@MainActivity, "Не удалось запустить: ${e.message}", Toast.LENGTH_LONG).show()
                refresh()
            }
        }
        fun discoverChatShortcuts(entry: ProfileAudit.Entry) {
            try {
                val user = launcherApps.profiles.firstOrNull { it.toString() == entry.user }
                    ?: throw IllegalStateException("Профиль больше не доступен")
                val query = LauncherApps.ShortcutQuery()
                    .setPackage("com.whatsapp")
                    .setQueryFlags(LauncherApps.ShortcutQuery.FLAG_MATCH_DYNAMIC or LauncherApps.ShortcutQuery.FLAG_MATCH_PINNED or LauncherApps.ShortcutQuery.FLAG_MATCH_MANIFEST)
                val found = launcherApps.getShortcuts(query, user).orEmpty()
                shortcutResults = shortcutResults + (entry.user to found)
                shortcutStatus = if (found.isEmpty()) "В ${entry.user} Android не отдал ярлыки WhatsApp. Создай ярлык переписки на рабочем столе средствами WhatsApp и нажми поиск снова; если WhatsApp не публикует ярлыки через LauncherApps, точный запуск из приложения на этом устройстве недоступен." else "Найдено ярлыков в ${entry.user}: ${found.size}. Выбери нужную переписку ниже."
                DiagnosticStore.add(this@MainActivity, "${stamp()} | CHAT_SHORTCUT_DISCOVERY | user=${entry.user} | count=${found.size} | ids=${found.joinToString(",") { it.id }}")
            } catch (e: Exception) {
                shortcutStatus = "Ошибка чтения ярлыков: ${e.javaClass.simpleName}: ${e.message}"
                DiagnosticStore.add(this@MainActivity, "${stamp()} | CHAT_SHORTCUT_DISCOVERY_FAILED | user=${entry.user} | error=$shortcutStatus")
            }
            refresh()
        }
        fun saveChatShortcut(entry: ProfileAudit.Entry, shortcut: ShortcutInfo) {
            val ok = ShortcutBindingStore.save(this@MainActivity, entry.user, entry.serial, entry.uid, shortcut.id, shortcut.shortLabel?.toString() ?: shortcut.id)
            shortcutStatus = if (ok) "Кнопка привязана к ярлыку «${shortcut.shortLabel}» для ${entry.user}." else "Не удалось сохранить привязку ярлыка."
            refresh()
        }
        fun launchSavedShortcut(row: String) {
            try {
                val b = ShortcutBindingStore.parse(row) ?: throw IllegalStateException("Повреждена запись кнопки")
                val user = launcherApps.profiles.firstOrNull { it.toString() == b.user } ?: throw IllegalStateException("Профиль WhatsApp недоступен")
                launcherApps.startShortcut("com.whatsapp", b.shortcutId, null, Bundle(), user)
                DiagnosticStore.add(this@MainActivity, "${stamp()} | CHAT_SHORTCUT_LAUNCHED | label=${b.label} | user=${b.user} | shortcutId=${b.shortcutId}")
                shortcutStatus = "Команда запуска ярлыка «${b.label}» передана Android для ${b.user}. Проверь, открылся ли нужный чат."
            } catch (e: Exception) {
                shortcutStatus = "Не удалось открыть чат: ${e.javaClass.simpleName}: ${e.message}"
                DiagnosticStore.add(this@MainActivity, "${stamp()} | CHAT_SHORTCUT_LAUNCH_FAILED | error=$shortcutStatus")
            }
            refresh()
        }
        fun confirmBinding() {
            val ok = ProfileBindingStore.confirm(this@MainActivity, label)
            status = if (ok) "Запись сохранена и проверена повторным чтением. Это не доказательство источника профиля." else "Не удалось подтвердить сохранение. Проверь журнал и повтори привязку только после нового запуска."
            if (ok) label = ""
            refresh()
        }

        MaterialTheme {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("TS AutoReport", style = MaterialTheme.typography.headlineLarge)
                Text("Версия 0.12 — запуск сохранённых чатов по кнопке", style = MaterialTheme.typography.titleMedium)
                Text("BUILD ID: TS-BIND-012 · versionCode 13", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                Text("Теперь проверяем не только сохранение метки: кнопка должна запускать конкретный чат в выбранном экземпляре WhatsApp. Для этого приложение использует официальные Android conversation shortcuts. Сначала создай ярлык нужной переписки в самом WhatsApp (меню чата → Ещё → Добавить ярлык), затем найди его здесь и привяжи.")
                Text(if (enabled) "Accessibility включена" else "Accessibility выключена", color = if (enabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                Button(onClick = { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }) { Text("Открыть специальные возможности") }
                Button(onClick = { refresh() }) { Text("Обновить статус и журнал") }
                HorizontalDivider()
                Text("1. Найти экземпляры", style = MaterialTheme.typography.titleLarge)
                Button(onClick = { audit() }) { Text("Провести аудит профилей и UID") }
                Text(status, style = MaterialTheme.typography.bodySmall)
                if (auditDone && entries.isEmpty()) Text("Экземпляры не обнаружены.", color = MaterialTheme.colorScheme.error)
                entries.forEachIndexed { index, e ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Text("Экземпляр ${index + 1}", style = MaterialTheme.typography.titleMedium)
                            Text("UserHandle: ${e.user} · Serial: ${e.serial} · UID: ${e.uid}")
                            Text("${e.packageName} · ${e.versionName} · ${e.component}", style = MaterialTheme.typography.bodySmall)
                            Button(onClick = { startBinding(e) }) { Text("Открыть этот экземпляр WhatsApp") }
                            OutlinedButton(onClick = { discoverChatShortcuts(e) }) { Text("Найти ярлыки чатов этого WhatsApp") }
                            shortcutResults[e.user].orEmpty().forEach { shortcut ->
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(shortcut.shortLabel?.toString() ?: shortcut.id, modifier = Modifier.weight(1f))
                                    TextButton(onClick = { saveChatShortcut(e, shortcut) }) { Text("Привязать к кнопке") }
                                }
                            }
                        }
                    }
                }
                Text(shortcutStatus, style = MaterialTheme.typography.bodySmall)
                HorizontalDivider()
                Text("Кнопки запуска сохранённых чатов", style = MaterialTheme.typography.titleLarge)
                if (shortcutBindings.isEmpty()) Text("Пока нет привязанных ярлыков чатов.")
                shortcutBindings.forEach { saved ->
                    val b = ShortcutBindingStore.parse(saved)
                    if (b != null) Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(b.label, style = MaterialTheme.typography.titleMedium)
                            Text(if (b.user == "UserHandle{0}") "Основной WhatsApp" else if (b.user == "UserHandle{95}") "WhatsApp Dual Messenger (клон)" else b.user)
                            Button(onClick = { launchSavedShortcut(saved) }) { Text("Открыть этот чат") }
                            TextButton(onClick = { ShortcutBindingStore.delete(this@MainActivity, saved); refresh() }) { Text("Удалить кнопку") }
                        }
                    }
                }
                HorizontalDivider()
                Text("Диагностика ручной привязки (старый тест)", style = MaterialTheme.typography.titleLarge)
                Text("Секция ниже оставлена для диагностики Accessibility; для открытия конкретного чата используй ярлык и кнопку выше.")
                Text("2. Подтвердить именно открытый чат", style = MaterialTheme.typography.titleLarge)
                Text("После запуска WhatsApp найди нужного человека/группу и открой сам экран переписки. Не оставайся на списке чатов. Затем вернись сюда и нажми кнопку проверки.")
                val obs = observation
                if (pending != null) {
                    Text("Сессия ожидает подтверждения: ${pending!!.user} (UID ${pending!!.uid})")
                    Button(onClick = { refresh() }) { Text("2. Проверить, что нужная переписка открыта") }
                    if (obs != null && obs.eventAt >= pending!!.startedAt) {
                        Text("Экран переписки обнаружен. Теперь введи свою метку и подтверди привязку.", color = MaterialTheme.colorScheme.primary)
                        Text("Техническая запись: windowId=${obs.windowId} · ${Date(obs.eventAt)}", style = MaterialTheme.typography.bodySmall)
                    } else {
                        Text("Пока не обнаружен экран переписки. Вернись в WhatsApp, открой нужный чат и повтори проверку.", color = MaterialTheme.colorScheme.error)
                    }
                    OutlinedTextField(value = label, onValueChange = { label = it.take(80) }, label = { Text("Метка чата (введи сам)") }, placeholder = { Text("Например: Рабочая смена") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    Button(onClick = { confirmBinding() }, enabled = obs != null && obs.eventAt >= pending!!.startedAt && label.isNotBlank()) { Text("3. Сохранить этот чат") }
                    TextButton(onClick = { ProfileBindingStore.cancel(this@MainActivity); refresh() }) { Text("Отменить сессию") }
                } else {
                    Text("Активной сессии привязки нет.")
                }
                HorizontalDivider()
                Text("3. Мои сохранённые чаты", style = MaterialTheme.typography.titleLarge)
                val loadOk = bindingsLoaded.first
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Сохранено: ${bindings.size}", style = MaterialTheme.typography.titleMedium)
                    Text(if (loadOk) "Загрузка проверена" else "Проверка загрузки не пройдена", color = if (loadOk) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                }
                if (bindings.isEmpty()) Text("Пока нет подтверждённых привязок.")
                bindings.forEach { row ->
                    val p = row.split('\t')
                    val profileTitle = when (p.getOrNull(1)) {
                        "UserHandle{0}" -> "Основной WhatsApp"
                        "UserHandle{95}" -> "WhatsApp Dual Messenger (клон)"
                        else -> "WhatsApp — профиль не распознан"
                    }
                    val profileShort = when (p.getOrNull(1)) {
                        "UserHandle{0}" -> "Основной профиль Android"
                        "UserHandle{95}" -> "Профиль клона Samsung Dual Messenger"
                        else -> "Профиль Android: ${p.getOrNull(1) ?: "неизвестен"}"
                    }
                    val savedAt = p.getOrNull(6)?.toLongOrNull()?.let { SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date(it)) } ?: "неизвестно"
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(p.getOrNull(0) ?: "Чат без названия", style = MaterialTheme.typography.titleMedium)
                                Text("Сохранено", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelLarge)
                            }
                            Text(profileTitle, style = MaterialTheme.typography.bodyLarge)
                            Text(profileShort, style = MaterialTheme.typography.bodySmall)
                            Text("UID: ${p.getOrNull(3) ?: "—"} · Serial: ${p.getOrNull(2) ?: "—"}", style = MaterialTheme.typography.bodySmall)
                            Text("Время подтверждения: $savedAt", style = MaterialTheme.typography.bodySmall)
                            Text("Метка введена вручную; имя контакта WhatsApp не считывается.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                TextButton(onClick = { editingRow = row; editingLabel = p.getOrNull(0).orEmpty() }) { Text("Изменить название") }
                                TextButton(onClick = {
                                    val ok = ProfileBindingStore.deleteBinding(this@MainActivity, row)
                                    status = if (ok) "Привязка удалена и проверена." else "Не удалось проверить удаление."
                                    refresh()
                                }) { Text("Удалить") }
                            }
                        }
                    }
                }
                if (editingRow != null) {
                    AlertDialog(
                        onDismissRequest = { editingRow = null },
                        title = { Text("Изменить метку чата") },
                        text = { OutlinedTextField(value = editingLabel, onValueChange = { editingLabel = it.take(80) }, label = { Text("Новая метка") }, singleLine = true) },
                        confirmButton = { TextButton(onClick = {
                            val ok = ProfileBindingStore.updateLabel(this@MainActivity, editingRow!!, editingLabel)
                            status = if (ok) "Метка изменена, запись проверена." else "Не удалось сохранить изменение."
                            editingRow = null
                            refresh()
                        }) { Text("Сохранить") } },
                        dismissButton = { TextButton(onClick = { editingRow = null }) { Text("Отмена") } }
                    )
                }
                Text("Ограничение: метка чата вводится оператором; приложение не читает название чата. Событие Conversation после контролируемого запуска — полезный сигнал последовательности, но AccessibilityEvent не содержит UserHandle. Поэтому это ручная привязка, не независимое доказательство источника события и не разрешение на автоматическую отправку.", color = MaterialTheme.colorScheme.error)
                HorizontalDivider()
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Журнал", style = MaterialTheme.typography.titleLarge)
                    TextButton(onClick = { DiagnosticStore.clear(this@MainActivity); refresh() }) { Text("Очистить журнал") }
                }
                Text("Событий: ${logs.size}. Журнал хранится только локально внутри приложения (SharedPreferences); внешний TXT-файл и автоматическая отправка журнала не создаются. Текст переписки не считывается.", style = MaterialTheme.typography.bodySmall)
                logs.forEach { Text(it, style = MaterialTheme.typography.bodySmall) }
            }
        }
    }

    private fun stamp() = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault()).format(Date())

    private fun isServiceEnabled(): Boolean {
        val manager = getSystemService(ACCESSIBILITY_SERVICE) as AccessibilityManager
        val expected = ComponentName(this, WhatsAppAccessibilityService::class.java)
        return manager.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            .any { it.resolveInfo.serviceInfo.let { info -> ComponentName(info.packageName, info.name) == expected } }
    }
}
