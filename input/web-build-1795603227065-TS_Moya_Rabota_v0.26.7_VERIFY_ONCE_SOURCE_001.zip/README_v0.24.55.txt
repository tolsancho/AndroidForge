TS AutoReport v0.24.55
BUILD ID: TS-VISUAL-POLISH-CHEVRON-NOTICES-02455
versionCode: 86

This source snapshot is based on v0.24.54. It contains visual-only refinements in MainActivity:
- Both chat and interval disclosure controls use the same white rounded chevron drawing, centered in the existing circular backgrounds (46 dp and 22 dp). The whole circle+chevron rotates 180 degrees in place; no ripple/square press highlight is shown.
- Interval rows have a transparent press indication. The message preview is a single larger line with ellipsis and reserved room for the status dot and disclosure control.
- The Permissions heading is moved slightly upward while keeping the permission pills at their previous vertical position.
- In-app Toast-style notices are displayed as a compact clickable two-line preview; tapping opens a dialog with the complete message, dismissible by the close icon or outside tap.

No scheduling, SEND/READ/CHECK, WhatsApp shortcut binding, message persistence, or status-state implementation was intentionally changed. The only application source file changed is MainActivity.kt; build metadata was advanced to versionCode 86.

Build status: source-level static checks only. No Gradle build, APK build, or physical-device testing was performed.
