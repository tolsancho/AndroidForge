package ru.tsautoreport.diagnostic

import android.content.Context

/** Stores an operator-confirmed chat label and the technical observation from a controlled launch session. */
object ProfileBindingStore {
    private const val PREFS = "profile_binding_store"
    private const val KEY_PENDING = "pending_session"
    private const val KEY_OBSERVATION = "conversation_observation"
    private const val KEY_BINDINGS = "confirmed_bindings"

    data class Session(val user: String, val serial: Long, val uid: Int, val component: String, val startedAt: Long)
    data class Observation(val eventAt: Long, val windowId: Int, val className: String)

    fun begin(context: Context, session: Session) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_PENDING, listOf(session.user, session.serial, session.uid, session.component, session.startedAt).joinToString("\t"))
            .remove(KEY_OBSERVATION)
            .apply()
        DiagnosticStore.add(context, "${stamp()} | BIND_SESSION_START | user=${session.user} | serial=${session.serial} | uid=${session.uid} | component=${session.component} | startedAt=${session.startedAt}")
    }

    fun pending(context: Context): Session? {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_PENDING, null) ?: return null
        val p = raw.split('\t')
        if (p.size != 5) return null
        return try { Session(p[0], p[1].toLong(), p[2].toInt(), p[3], p[4].toLong()) } catch (_: Exception) { null }
    }

    fun observeConversation(context: Context, windowId: Int, className: String, eventAt: Long) {
        val session = pending(context) ?: return
        if (eventAt < session.startedAt) return
        val raw = listOf(eventAt, windowId, className).joinToString("\t")
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_OBSERVATION, raw).apply()
        DiagnosticStore.add(context, "${stamp()} | BIND_CONVERSATION_OBSERVED | sessionUser=${session.user} | eventAt=$eventAt | window=$windowId | class=$className | note=profile_origin_not_independently_verified")
    }

    fun observation(context: Context): Observation? {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_OBSERVATION, null) ?: return null
        val p = raw.split('\t')
        if (p.size != 3) return null
        return try { Observation(p[0].toLong(), p[1].toInt(), p[2]) } catch (_: Exception) { null }
    }

    fun confirm(context: Context, label: String): Boolean {
        val session = pending(context) ?: return false
        val observation = observation(context) ?: return false
        if (observation.eventAt < session.startedAt || observation.className != "com.whatsapp.Conversation") return false
        val clean = label.trim().replace('\n', ' ').replace('\t', ' ').take(80)
        if (clean.isBlank()) return false
        val row = listOf(clean, session.user, session.serial, session.uid, session.component, observation.windowId, observation.eventAt).joinToString("\t")
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val rows = prefs.getString(KEY_BINDINGS, "").orEmpty().split('\n').filter { it.isNotBlank() } + row
        prefs.edit().putString(KEY_BINDINGS, rows.takeLast(100).joinToString("\n")).remove(KEY_PENDING).remove(KEY_OBSERVATION).apply()
        DiagnosticStore.add(context, "${stamp()} | BIND_CONFIRMED_BY_OPERATOR | label=$clean | user=${session.user} | serial=${session.serial} | uid=${session.uid} | conversationWindow=${observation.windowId} | note=manual_label_and_controlled_launch_context_not_android_profile_proof")
        return true
    }

    fun bindings(context: Context): List<String> = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .getString(KEY_BINDINGS, "").orEmpty().split('\n').filter { it.isNotBlank() }.reversed()

    fun cancel(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY_PENDING).remove(KEY_OBSERVATION).apply()
        DiagnosticStore.add(context, "${stamp()} | BIND_SESSION_CANCELLED")
    }

    private fun stamp() = java.text.SimpleDateFormat("HH:mm:ss.SSS", java.util.Locale.getDefault()).format(java.util.Date())
}
