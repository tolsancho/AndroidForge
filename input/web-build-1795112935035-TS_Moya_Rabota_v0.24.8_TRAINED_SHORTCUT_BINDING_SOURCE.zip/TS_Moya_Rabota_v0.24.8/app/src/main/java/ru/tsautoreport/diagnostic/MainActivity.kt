package ru.tsautoreport.diagnostic

import android.app.Activity
import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.os.UserManager
import android.provider.Settings
import android.accessibilityservice.AccessibilityServiceInfo
import android.view.accessibility.AccessibilityManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import java.util.Calendar

class MainActivity : ComponentActivity() {
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState); val p=getSharedPreferences("ts_activation",0); if(!p.getBoolean("activated",false)){setContent{ActivationScreen{p.edit().putBoolean("activated",true).commit(); recreate() }};return}; setContent{ WorkApp() } }
}

@Composable private fun ActivationScreen(done:()->Unit){ var pass by remember{mutableStateOf("")}; MaterialTheme { Surface(Modifier.fillMaxSize()){ Column(Modifier.fillMaxSize().padding(28.dp),verticalArrangement=Arrangement.Center){Text("Пароль ка черкани или не видать тебе чёткой смены.",style=MaterialTheme.typography.titleLarge); Spacer(Modifier.height(18.dp)); OutlinedTextField(pass,{pass=it},label={Text("Пароль")},visualTransformation=PasswordVisualTransformation(),singleLine=true); Spacer(Modifier.height(12.dp)); Button(onClick={if(pass=="TolSancho")done()}){Text("Продолжить")} } } } }

@Composable private fun WorkApp(){
 val ctx= LocalContext.current; val prefs= remember{ctx.getSharedPreferences("ts_ui",0)}
 val availableProfiles= remember { detectWhatsAppProfiles(ctx) }; var chats by remember { mutableStateOf(ChatScheduleStore.all(ctx)) }; var pendingEnabled by remember { mutableStateOf(chats.filter{it.enabled}.map{it.id}.toSet()) }; var active by remember{mutableStateOf(ScheduledTestStore.active(ctx))}; var stateKnown by remember{mutableStateOf(ctx.getSharedPreferences("ts_ui",0).getBoolean("state_known",false))}; var permissionTick by remember{mutableIntStateOf(0)}; var permissionWarning by remember{mutableStateOf("")}
 var drawer by remember{mutableStateOf(false)}; var drawerDrag by remember{mutableFloatStateOf(0f)}; var instruction by remember{mutableStateOf(false)}; var section by remember{mutableStateOf(prefs.getString("guide_section","Назначение")?:"Назначение")}; var scale by remember{mutableFloatStateOf(prefs.getInt("scale",0).toFloat())}; var theme by remember{mutableStateOf(prefs.getString("theme","system")?:"system")}; var ownerPassword by remember{mutableStateOf(prefs.getString("owner_password","").orEmpty())}; var ownerGate by remember{mutableStateOf(ownerPassword.isNotBlank())}; var showPasswordDialog by remember{mutableStateOf(false)}; var passDraft by remember{mutableStateOf("")}; var expandedChat by remember{mutableStateOf("")}; var expandedInterval by remember{mutableStateOf("")}; var showTimeFor by remember{mutableStateOf("")}; var showMessageFor by remember{mutableStateOf("")}; var draftMessage by remember{mutableStateOf("")}; var draftTime by remember{mutableStateOf("00:00")}; var pickerHour by remember{mutableIntStateOf(0)}; var pickerMinute by remember{mutableIntStateOf(0)}; var showThanks by remember{mutableStateOf(false)}; var showAddChat by remember{mutableStateOf(false)}; var newLabel by remember{mutableStateOf("")}; var newProfile by remember{mutableStateOf(if("clone" in availableProfiles)"clone" else "main")}; var pendingConfirm by remember{mutableStateOf("")}; var editingModeChat by remember{mutableStateOf("")}; var modeDraft by remember{mutableStateOf("SEND")}; var guideScroll by remember{mutableIntStateOf(prefs.getInt("guide_scroll",0))}
 val dark = when(theme){"dark"->true;"light"->false;else-> androidx.compose.foundation.isSystemInDarkTheme()}
 val cs= if(dark) darkColorScheme(
  primary=Color(0xFF79C99A), onPrimary=Color(0xFF10291B),
  secondary=Color(0xFFB9A2C8), onSecondary=Color(0xFF241D2A),
  background=Color(0xFF171619), onBackground=Color(0xFFD6D2D9),
  surface=Color(0xFF211F24), onSurface=Color(0xFFD6D2D9),
  surfaceVariant=Color(0xFF302C33), onSurfaceVariant=Color(0xFFC5C0C9),
  outline=Color(0xFF625C66), outlineVariant=Color(0xFF49434D),
  surfaceContainerLowest=Color(0xFF171619), surfaceContainerLow=Color(0xFF1D1B20), surfaceContainer=Color(0xFF242127), surfaceContainerHigh=Color(0xFF2A272E), surfaceContainerHighest=Color(0xFF302C33),
  error=Color(0xFFFFB4AB), onError=Color(0xFF690005)
 ) else lightColorScheme(
  primary=Color(0xFF237A48), onPrimary=Color.White,
  secondary=Color(0xFF86552F), onSecondary=Color.White,
  background=Color.White, onBackground=Color(0xFF171717),
  surface=Color.White, onSurface=Color(0xFF171717),
  surfaceVariant=Color(0xFFF0F0F0), onSurfaceVariant=Color(0xFF303030),
  outline=Color(0xFF666666), outlineVariant=Color(0xFFB0B0B0)
 )
 fun refresh(){chats=ChatScheduleStore.all(ctx);pendingEnabled=chats.filter{it.enabled}.map{it.id}.toSet();active=ScheduledTestStore.active(ctx)}
 LaunchedEffect(Unit){while(true){
  active=ScheduledTestStore.active(ctx); permissionTick++
  val problems=PermissionGate.status(ctx).problems()
  if(active && problems.isNotEmpty()){
   ScheduledTestStore.cancel(ctx); active=false
   permissionWarning=problems.joinToString("\n")
   PermissionGate.notifyBlocked(ctx,problems)
  }
  delay(1000)
 }}
 fun persist(list:List<WorkChat>){ if(list!=chats && ScheduledTestStore.active(ctx)){ScheduledTestStore.cancel(ctx);active=false;stateKnown=true;prefs.edit().putBoolean("state_known",true).apply();Toast.makeText(ctx,"Настройки изменены. Расписание остановлено — нажми «Сохранить и запустить».",Toast.LENGTH_LONG).show()}; ChatScheduleStore.save(ctx,list);chats=list;pendingEnabled=list.filter{it.enabled}.map{it.id}.toSet() }
 BackHandler(drawer||instruction||ownerGate){ if(ownerGate) Unit else if(instruction) instruction=false else drawer=false }
 val baseDensity=LocalDensity.current
 CompositionLocalProvider(LocalDensity provides androidx.compose.ui.unit.Density(baseDensity.density*(1f+scale/100f).coerceAtLeast(0.5f), baseDensity.fontScale*(1f+scale/100f).coerceAtLeast(0.5f))){ MaterialTheme(colorScheme=cs){
  CompositionLocalProvider(androidx.compose.material3.LocalContentColor provides MaterialTheme.colorScheme.onBackground){
  Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)){
   Column(Modifier.fillMaxSize().statusBarsPadding().padding(bottom=84.dp).verticalScroll(rememberScrollState()).padding(horizontal=24.dp, vertical=16.dp), horizontalAlignment=Alignment.CenterHorizontally){
    Box(Modifier.fillMaxWidth().heightIn(min=52.dp)){ Text("TS Моя работа",style=MaterialTheme.typography.headlineMedium,modifier=Modifier.align(Alignment.CenterStart)) }
    Spacer(Modifier.height(12.dp)); Text("Разрешения",style=MaterialTheme.typography.titleMedium,modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.Center)
    val permissionStatus = PermissionGate.status(ctx)
    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(3.dp),verticalAlignment=Alignment.CenterVertically){
     PermissionPill("Доступ",permissionStatus.accessibility,Modifier.weight(1f)){ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))}
     PermissionPill("Батар.",permissionStatus.battery,Modifier.weight(1f)){PermissionGate.openBattery(ctx)}
     PermissionPill("Будил.",permissionStatus.exactAlarm,Modifier.weight(1f)){PermissionGate.openAlarm(ctx)}
     PermissionPill("Увед.",permissionStatus.notifications,Modifier.weight(1f)){PermissionGate.openNotifications(ctx)}
     PermissionPill("Замок",permissionStatus.screenLockDisabled,Modifier.weight(1f)){PermissionGate.openLockSettings(ctx)}
    }
    Spacer(Modifier.height(18.dp)); Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Text("Чаты",style=MaterialTheme.typography.titleLarge,modifier=Modifier.weight(1f),textAlign=TextAlign.Center);Text("${chats.size}/10",style=MaterialTheme.typography.labelLarge)}
    Text("Введите точное название ярлыка переписки на рабочем столе. Проверка откроет именно этот ярлык; вернитесь сюда и подтвердите результат.",style=MaterialTheme.typography.bodySmall,modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.Center,color=MaterialTheme.colorScheme.onSurfaceVariant)
    chats.forEach { chat ->
     Card(Modifier.fillMaxWidth().padding(vertical=5.dp),shape=RoundedCornerShape(16.dp)){
      Column(Modifier.padding(12.dp)){
       Row(verticalAlignment=Alignment.CenterVertically,modifier=Modifier.fillMaxWidth()){
        Checkbox(checked=chat.id in pendingEnabled,onCheckedChange={checked->pendingEnabled=if(checked)pendingEnabled+chat.id else pendingEnabled-chat.id})
        Column(Modifier.weight(1f).clickable{expandedChat=if(expandedChat==chat.id)"" else chat.id;expandedInterval=""}){Text(chat.launcherLabel.ifBlank{"Новый чат"},style=MaterialTheme.typography.titleMedium);Text("${chat.profile.uppercase()} · ${chat.intervals.size}/24 интервалов",style=MaterialTheme.typography.bodySmall)}
        if(chat.behavior.isNotBlank()) {
         val (modeTitle,modeColor,modeText)=when(chat.behavior){"READ"->Triple("Чтение",Color(0xFF3979C9),Color.White);"CHECK"->Triple("Проверка",Color(0xFFE05A5A),Color.Black);else->Triple("Отправка",Color(0xFF238447),Color.White)}
         Surface(color=modeColor,shape=RoundedCornerShape(50)){Text(modeTitle,color=modeText,style=MaterialTheme.typography.labelSmall,modifier=Modifier.padding(horizontal=9.dp,vertical=5.dp))}
         Spacer(Modifier.width(5.dp)); TextButton(onClick={editingModeChat=chat.id;modeDraft=chat.behavior;expandedChat=chat.id}){Text("Ред.",color=MaterialTheme.colorScheme.onSurfaceVariant)}
        }
        Text(if(expandedChat==chat.id)"⌃" else "⌄",modifier=Modifier.clickable{expandedChat=if(expandedChat==chat.id)"" else chat.id;expandedInterval=""})
       }
       AnimatedVisibility(expandedChat==chat.id,enter=androidx.compose.animation.expandVertically(tween(220)),exit=androidx.compose.animation.shrinkVertically(tween(180))){
        Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
         if(!chat.confirmed || pendingConfirm==chat.id){
          Text("Ярлык рабочего стола",style=MaterialTheme.typography.labelLarge)
          OutlinedTextField(chat.launcherLabel,{v->persist(chats.map{if(it.id==chat.id)it.copy(launcherLabel=v.take(100),confirmed=false) else it})},modifier=Modifier.fillMaxWidth(),singleLine=true)
          Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
           if("main" in availableProfiles) FilterChip(selected=chat.profile=="main",onClick={persist(chats.map{if(it.id==chat.id)it.copy(profile="main",confirmed=false)else it})},modifier=Modifier.weight(1f).height(58.dp),label={Text("Основной\nWhatsApp",modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.Center)})
           if("clone" in availableProfiles) FilterChip(selected=chat.profile=="clone",onClick={persist(chats.map{if(it.id==chat.id)it.copy(profile="clone",confirmed=false)else it})},modifier=Modifier.weight(1f).height(58.dp),label={Text("Клон\nWhatsApp",modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.Center)})
          }
         }
         OutlinedButton(onClick={pendingConfirm=chat.id; launchShortcutCheck(ctx,chat.id,chat.profile,chat.launcherLabel) },modifier=Modifier.fillMaxWidth(),enabled=chat.launcherLabel.isNotBlank()) { Text(if(chat.confirmed) "Перепривязать ярлык" else "Привязать ярлык",modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.Center) }
         if(pendingConfirm==chat.id){
          Text(if(ShortcutCaptureStore.canConfirm(ctx,chat.id)) "Чат открыт. Если это нужный чат и профиль, нажми «Верно»." else "После выхода на рабочий стол вручную нажми нужный ярлык с фотографией профиля. Дождись открытия чата и вернись сюда.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
          Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
           Button(onClick={if(ShortcutCaptureStore.confirm(ctx,chat.id)){ChatScheduleStore.clearPending(ctx);persist(chats.map{if(it.id==chat.id)it.copy(confirmed=true)else it});pendingConfirm=""}else Toast.makeText(ctx,"Сначала открой нужный ярлык и дождись появления переписки.",Toast.LENGTH_LONG).show()},enabled=ShortcutCaptureStore.canConfirm(ctx,chat.id),modifier=Modifier.weight(1f)){Text("Верно",modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.Center)}
           OutlinedButton(onClick={ShortcutCaptureStore.cancel(ctx);ChatScheduleStore.clearPending(ctx);pendingConfirm=""},modifier=Modifier.weight(1f)){Text("Не верно",modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.Center)}
          }
         }
         if(!chat.confirmed) Text("Ярлык ещё не подтверждён",color=MaterialTheme.colorScheme.error,style=MaterialTheme.typography.bodySmall)
         if(chat.behavior.isBlank() || editingModeChat==chat.id){
          Text("Режим работы чата",style=MaterialTheme.typography.labelLarge)
          Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(5.dp)){
           listOf("READ" to "Чтение","SEND" to "Отправка","CHECK" to "Проверка").forEach{(key,label)->
            val color=when(key){"READ"->Color(0xFF3979C9);"CHECK"->Color(0xFFE05A5A);else->Color(0xFF238447)}
            Button(onClick={modeDraft=key},modifier=Modifier.weight(1f),contentPadding=PaddingValues(horizontal=3.dp,vertical=7.dp),colors=ButtonDefaults.buttonColors(containerColor=if(modeDraft==key)color else MaterialTheme.colorScheme.surfaceVariant,contentColor=if(modeDraft==key)Color.White else MaterialTheme.colorScheme.onSurface)){Text(label,style=MaterialTheme.typography.labelSmall,maxLines=1)}
           }
          }
          Button(onClick={persist(chats.map{if(it.id==chat.id)it.copy(behavior=modeDraft)else it});editingModeChat=""},modifier=Modifier.align(Alignment.CenterHorizontally)){Text("Сохранить режим")}
         }
         HorizontalDivider()
         chat.intervals.forEach { slot ->
          Column(Modifier.fillMaxWidth().border(1.dp,MaterialTheme.colorScheme.outlineVariant,RoundedCornerShape(12.dp)).padding(9.dp)){
           Row(Modifier.fillMaxWidth().clickable{expandedInterval=if(expandedInterval==slot.id)"" else slot.id},verticalAlignment=Alignment.CenterVertically){Text(slot.time,style=MaterialTheme.typography.titleMedium);Spacer(Modifier.width(10.dp));Text(slot.message.take(42),Modifier.weight(1f),style=MaterialTheme.typography.bodySmall);Text(if(expandedInterval==slot.id)"⌃" else "⌄")}
           if(expandedInterval==slot.id){Row(verticalAlignment=Alignment.CenterVertically){Text("Время: ${slot.time}");Spacer(Modifier.width(8.dp));TextButton(onClick={draftTime=slot.time;pickerHour=slot.time.substringBefore(":").toIntOrNull()?:0;pickerMinute=slot.time.substringAfter(":").toIntOrNull()?:0;showTimeFor="edit:${chat.id}:${slot.id}"}){Text("Изменить")};Spacer(Modifier.weight(1f));TextButton(onClick={persist(chats.map{c->if(c.id==chat.id)c.copy(intervals=c.intervals.filterNot{it.id==slot.id})else c})}){Text("Удалить")}}
            if(chat.behavior!="READ") { Text("Сообщение: ${slot.message.take(120)}",style=MaterialTheme.typography.bodySmall); OutlinedButton(onClick={draftMessage=slot.message;showMessageFor="edit:${chat.id}:${slot.id}"},modifier=Modifier.fillMaxWidth()){Text(if(slot.message.isBlank())"Добавить сообщение" else "Изменить сообщение") } }
            Text("Повторение",style=MaterialTheme.typography.labelLarge)
            val repeatModes=listOf("ONCE" to "Один раз","DAILY" to "Ежедневно")
            repeatModes.chunked(2).forEach { pair -> Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)) { pair.forEach { (mode,title) -> FilterChip(selected=slot.mode==mode,onClick={persist(chats.map{c->if(c.id==chat.id)c.copy(intervals=c.intervals.map{if(it.id==slot.id)it.copy(mode=mode)else it})else c})},modifier=Modifier.weight(1f),label={Text(title,modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.Center,style=MaterialTheme.typography.labelMedium)},leadingIcon=null) } } }
           }
          }
         }
         OutlinedButton(onClick={if(chat.intervals.size<24){draftTime="00:00";pickerHour=0;pickerMinute=0;draftMessage="";showTimeFor=chat.id}},enabled=chat.intervals.size<24,modifier=Modifier.wrapContentWidth().align(Alignment.CenterHorizontally),border=androidx.compose.foundation.BorderStroke(1.dp,MaterialTheme.colorScheme.primary),colors=ButtonDefaults.outlinedButtonColors(contentColor=MaterialTheme.colorScheme.primary)){Text("＋ Добавить время",modifier=Modifier.padding(horizontal=8.dp))}
         TextButton(onClick={persist(chats.filterNot{it.id==chat.id});expandedChat=""}){Text("Удалить чат")}
        }
       }
      }
     }
    }
    OutlinedButton(onClick={showAddChat=true},enabled=chats.size<10,modifier=Modifier.wrapContentWidth().align(Alignment.CenterHorizontally),border=androidx.compose.foundation.BorderStroke(1.dp,MaterialTheme.colorScheme.primary),colors=ButtonDefaults.outlinedButtonColors(contentColor=MaterialTheme.colorScheme.primary)){Text("＋ Добавить чат",modifier=Modifier.padding(horizontal=8.dp))}
   }
   // fixed footer
   Surface(Modifier.align(Alignment.BottomCenter).fillMaxWidth(),shadowElevation=8.dp,color=MaterialTheme.colorScheme.surface){Column(Modifier.navigationBarsPadding().padding(10.dp),verticalArrangement=Arrangement.spacedBy(7.dp)){
    if(pendingEnabled != chats.filter{it.enabled}.map{it.id}.toSet()) Button(onClick={val next=chats.map{it.copy(enabled=it.id in pendingEnabled)};ScheduledTestStore.cancel(ctx);ChatScheduleStore.save(ctx,next);chats=next;active=false;stateKnown=true;prefs.edit().putBoolean("state_known",true).apply();pendingEnabled=next.filter{it.enabled}.map{it.id}.toSet();Toast.makeText(ctx,"Выбор чатов применён. Расписание остановлено — нажми «Сохранить и запустить».",Toast.LENGTH_LONG).show()},modifier=Modifier.fillMaxWidth()){Text("Сохранить и применить",modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.Center)}
    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){
    Button(onClick={try{val gate=PermissionGate.status(ctx);require(gate.allReady){"Для запуска все пять индикаторов должны быть зелёными:\n${gate.problems().joinToString("\n")}"};val count=ScheduledTestStore.scheduleAll(ctx);stateKnown=true;ctx.getSharedPreferences("ts_ui",0).edit().putBoolean("state_known",true).apply();refresh();Toast.makeText(ctx,"Запущено заданий: $count",Toast.LENGTH_LONG).show()}catch(e:Exception){Toast.makeText(ctx,e.message?:"Не удалось запустить",Toast.LENGTH_LONG).show()}},modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=if(active)Color(0xFF238447) else Color.Gray)){Text("Сохранить и запустить",modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.Center)}
    Button(onClick={ScheduledTestStore.cancel(ctx);stateKnown=true;ctx.getSharedPreferences("ts_ui",0).edit().putBoolean("state_known",true).apply();refresh()},modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=if(!active && stateKnown)Color(0xFFC62828) else Color.Gray)){Text("Отменить и остановить",modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.Center)}
   }}}
   // Right-edge drawer: only a small handle remains visible while closed.
   if(!drawer){
    Surface(Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(top=4.dp).width(136.dp).height(46.dp).pointerInput(Unit){var dx=0f;detectHorizontalDragGestures(onHorizontalDrag={_,d->dx+=d;drawerDrag=(drawerDrag+d).coerceIn(-136f,0f)},onDragEnd={if(dx < -24f)drawer=true;drawerDrag=0f;dx=0f})},color=MaterialTheme.colorScheme.surfaceVariant,shape=RoundedCornerShape(topStart=18.dp,bottomStart=18.dp),shadowElevation=4.dp){Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center){Icon(Icons.Default.Menu,null,tint=MaterialTheme.colorScheme.onSurfaceVariant,modifier=Modifier.size(23.dp))}}
   }
   AnimatedVisibility(drawer,modifier=Modifier.align(Alignment.CenterEnd),enter=androidx.compose.animation.slideInHorizontally(tween(320)){it},exit=androidx.compose.animation.slideOutHorizontally(tween(280)){it}){
    Surface(Modifier.fillMaxHeight().width(290.dp).pointerInput(Unit){var dx=0f;detectHorizontalDragGestures(onHorizontalDrag={_,d->dx+=d},onDragEnd={if(dx > 18f)drawer=false;dx=0f})},shadowElevation=16.dp,color=MaterialTheme.colorScheme.surface){Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
     Row(verticalAlignment=Alignment.CenterVertically){Text("Настройки",style=MaterialTheme.typography.titleLarge,modifier=Modifier.weight(1f));IconButton(onClick={drawer=false}){Icon(Icons.Default.Close,"Закрыть", tint=MaterialTheme.colorScheme.error)}}
     Text("Тема",style=MaterialTheme.typography.titleMedium)
     Button(onClick={theme="system";prefs.edit().putString("theme",theme).apply()},modifier=Modifier.fillMaxWidth()){Text("Как в телефоне",modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.Center)}
     Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
      Button(onClick={theme="dark";prefs.edit().putString("theme",theme).apply()},modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF343038),contentColor=Color(0xFFEAE6ED))){Text("Тёмная",modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.Center)}
      Button(onClick={theme="light";prefs.edit().putString("theme",theme).apply()},modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=Color.White,contentColor=Color(0xFF222222))){Text("Светлая",modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.Center)}
     }
     Text("Шрифт и масштаб: ${scale.toInt()}%",style=MaterialTheme.typography.titleMedium);Slider(value=scale,onValueChange={scale=it.toInt().toFloat();prefs.edit().putInt("scale",scale.toInt()).apply()},valueRange=-50f..200f,steps=249);Text("От −50% до +200%. Меняются размеры текста и элементов.",style=MaterialTheme.typography.bodySmall)
     OutlinedButton(onClick={scale=0f;prefs.edit().putInt("scale",0).apply()},modifier=Modifier.align(Alignment.CenterHorizontally)){Text("Сбросить масштаб",modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.Center)}
     Button(onClick={instruction=true;drawer=false},modifier=Modifier.fillMaxWidth()){Text("Инструкция",modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.Center)}
     Button(onClick={showPasswordDialog=true},modifier=Modifier.fillMaxWidth()){Text("Пароль владельца",modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.Center)};if(ownerPassword.isNotBlank())TextButton(onClick={ownerPassword="";prefs.edit().remove("owner_password").apply()},modifier=Modifier.fillMaxWidth()){Text("Сбросить пароль",modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.Center)}
     Button(onClick={showThanks=true},modifier=Modifier.fillMaxWidth()){Text("Благодарности",modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.Center)}
     Spacer(Modifier.weight(1f));OutlinedButton(onClick={ScheduledTestStore.cancel(ctx);ctx.getSharedPreferences("ts_ui",0).edit().clear().apply();ctx.getSharedPreferences("ts_work_model",0).edit().clear().apply();chats=emptyList();active=false;stateKnown=false;theme="system";scale=0f;ownerPassword="";ownerGate=false;drawer=false;Toast.makeText(ctx,"Настройки приложения сброшены. Разрешения Android сохранены.",Toast.LENGTH_LONG).show()},modifier=Modifier.fillMaxWidth()){Text("Сбросить приложение до заводских настроек",modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.Center)}
    }}
   }
   if(showAddChat) AlertDialog(onDismissRequest={showAddChat=false},title={Text("Новый чат")},text={Column{OutlinedTextField(newLabel,{newLabel=it},label={Text("Точное имя ярлыка на рабочем столе")});Spacer(Modifier.height(8.dp));Text("Обнаруженные экземпляры WhatsApp");Row{if("main" in availableProfiles)FilterChip(newProfile=="main",{newProfile="main"},label={Text("Основной")});if("clone" in availableProfiles)FilterChip(newProfile=="clone",{newProfile="clone"},label={Text("Клон")})}}},confirmButton={TextButton(onClick={if(newLabel.isNotBlank()){val ch=WorkChat(launcherLabel=newLabel.trim(),profile=newProfile,behavior="");persist(chats+ch);expandedChat=ch.id;newLabel="";showAddChat=false}}){Text("Добавить")}},dismissButton={TextButton(onClick={showAddChat=false}){Text("Отмена")}})
   if(showTimeFor.isNotBlank()){
    val hp=pickerHour.coerceIn(0,23)
    val mp=pickerMinute.coerceIn(0,59)
    AlertDialog(
     onDismissRequest={showTimeFor=""},
     title={Text("Время запуска",modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.Center)},
     text={Box(Modifier.fillMaxWidth().height(142.dp),contentAlignment=Alignment.Center){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.Center,verticalAlignment=Alignment.CenterVertically){
      androidx.compose.ui.viewinterop.AndroidView(factory={android.widget.NumberPicker(it).apply{minValue=0;maxValue=23;value=hp;setFormatter{v->"%02d".format(v)};wrapSelectorWheel=true;styleTimePicker(this,dark);setOnValueChangedListener{_,_,v->pickerHour=v;draftTime="%02d:%02d".format(pickerHour,pickerMinute)}}},update={if(it.value!=hp)it.value=hp;styleTimePicker(it,dark)},modifier=Modifier.width(92.dp).height(126.dp))
      Text(":",style=MaterialTheme.typography.headlineMedium,color=MaterialTheme.colorScheme.onSurface)
      androidx.compose.ui.viewinterop.AndroidView(factory={android.widget.NumberPicker(it).apply{minValue=0;maxValue=59;value=mp;setFormatter{v->"%02d".format(v)};wrapSelectorWheel=true;styleTimePicker(this,dark);setOnValueChangedListener{_,_,v->pickerMinute=v;draftTime="%02d:%02d".format(pickerHour,pickerMinute)}}},update={if(it.value!=mp)it.value=mp;styleTimePicker(it,dark)},modifier=Modifier.width(92.dp).height(126.dp))
     } }},
     confirmButton={Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.Center){TextButton(onClick={showTimeFor=""}){Text("Отмена")};TextButton(onClick={val chosen="%02d:%02d".format(pickerHour.coerceIn(0,23),pickerMinute.coerceIn(0,59));draftTime=chosen;if(chosen.matches(Regex("([01]\\d|2[0-3]):[0-5]\\d"))){if(showTimeFor.startsWith("edit:")){val parts=showTimeFor.split(":");val cid=parts[1];val iid=parts[2];persist(chats.map{c->if(c.id==cid)c.copy(intervals=c.intervals.map{if(it.id==iid)it.copy(time=chosen)else it})else c});showTimeFor=""}else{val cid=showTimeFor;val ch=chats.firstOrNull{it.id==cid};if(ch?.behavior=="READ"){persist(chats.map{if(it.id==cid)it.copy(intervals=it.intervals+WorkInterval(time=chosen,message=""))else it});expandedChat=cid;showTimeFor=""}else{showMessageFor=cid;showTimeFor=""}}}}){Text("Готово")}}},
     dismissButton={}
    )
   }
   if(showMessageFor.isNotBlank()) AlertDialog(onDismissRequest={showMessageFor=""},title={Text("Сообщение")},text={OutlinedTextField(draftMessage,{draftMessage=it.take(3000)},modifier=Modifier.fillMaxWidth(),minLines=4,label={Text("До 3000 символов")},keyboardOptions=KeyboardOptions(capitalization=KeyboardCapitalization.Sentences,autoCorrectEnabled=true))},confirmButton={TextButton(onClick={if(draftMessage.isNotBlank()){if(showMessageFor.startsWith("edit:")){val parts=showMessageFor.split(":");val cid=parts[1];val iid=parts[2];persist(chats.map{c->if(c.id==cid)c.copy(intervals=c.intervals.map{if(it.id==iid)it.copy(message=draftMessage)else it})else c});expandedChat=cid}else{val ch=chats.first{it.id==showMessageFor};persist(chats.map{if(it.id==ch.id)it.copy(intervals=it.intervals+WorkInterval(time=draftTime,message=draftMessage))else it});expandedChat=ch.id};showMessageFor="";draftMessage=""}}){Text("Сохранить")}},dismissButton={TextButton(onClick={showMessageFor=""}){Text("Отмена")}})
   if(permissionWarning.isNotBlank()) AlertDialog(onDismissRequest={},title={Text("Автоматическая работа остановлена")},text={Text("Не выполнено обязательное условие:\n$permissionWarning\n\nИсправьте настройки и проверьте, чтобы все пять индикаторов стали зелёными. Затем запустите расписание вручную.")},confirmButton={TextButton(onClick={PermissionGate.dismissBlockedNotification(ctx);permissionWarning=""}){Text("Понял")}})
   if(showThanks) AlertDialog(onDismissRequest={showThanks=false},title={Text("Благодарности",modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.Center)},text={Text("Рахмет Толясику скажи, не будь козлом. Зря он прогу писал эту? Старался же.",modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.Center,color=MaterialTheme.colorScheme.onSurface)},confirmButton={TextButton(onClick={showThanks=false}){Text("Закрыть")}})
   if(showPasswordDialog) AlertDialog(onDismissRequest={showPasswordDialog=false;passDraft=""},title={Text("Пароль владельца")},text={OutlinedTextField(passDraft,{passDraft=it},visualTransformation=PasswordVisualTransformation(),label={Text("Новый пароль")})},confirmButton={TextButton(onClick={if(passDraft.isNotBlank()){ownerPassword=passDraft;prefs.edit().putString("owner_password",ownerPassword).apply();passDraft="";showPasswordDialog=false}}){Text("Сохранить")}},dismissButton={TextButton(onClick={showPasswordDialog=false}){Text("Отмена")}})
   if(instruction) GuideDialog(section,{section=it;prefs.edit().putString("guide_section",it).apply()},guideScroll,{guideScroll=it;prefs.edit().putInt("guide_scroll",it).apply()},{instruction=false})
   if(ownerGate && ownerPassword.isNotBlank()) { var entered by remember{mutableStateOf("")}; AlertDialog(onDismissRequest={},title={Text("Введите пароль")},text={OutlinedTextField(entered,{entered=it},visualTransformation=PasswordVisualTransformation())},confirmButton={TextButton(onClick={if(entered==ownerPassword)ownerGate=false}){Text("Войти")}}) }
  }
 }}
}
}

private fun styleTimePicker(picker:android.widget.NumberPicker,dark:Boolean){
    val selected=if(dark)android.graphics.Color.rgb(214,210,217) else android.graphics.Color.rgb(25,25,25)
    val adjacent=if(dark)android.graphics.Color.rgb(105,101,110) else android.graphics.Color.rgb(105,105,105)
    val divider=if(dark)android.graphics.Color.rgb(205,201,211) else android.graphics.Color.rgb(55,55,55)
    for(i in 0 until picker.childCount){(picker.getChildAt(i) as? android.widget.EditText)?.apply{setTextColor(selected);setHintTextColor(adjacent)}}
    runCatching { val f=android.widget.NumberPicker::class.java.getDeclaredField("mSelectionDivider");f.isAccessible=true;f.set(picker,android.graphics.drawable.ColorDrawable(divider)) }
    runCatching { val f=android.widget.NumberPicker::class.java.getDeclaredField("mSelectorWheelPaint");f.isAccessible=true;(f.get(picker) as? android.graphics.Paint)?.color=adjacent }
    picker.invalidate()
}

@Composable private fun PermissionPill(label:String,ok:Boolean,modifier:Modifier=Modifier,onClick:()->Unit){
 val bg=if(ok)Color(0xFF238447) else Color(0xFFC62828)
 Surface(onClick=onClick,color=bg,shape=RoundedCornerShape(13.dp),modifier=modifier.height(36.dp)){
  Row(Modifier.fillMaxSize().padding(horizontal=2.dp),horizontalArrangement=Arrangement.Center,verticalAlignment=Alignment.CenterVertically){
   Text("●",color=Color.White,style=MaterialTheme.typography.labelSmall)
   Spacer(Modifier.width(2.dp))
   Text(label,color=Color.White,style=MaterialTheme.typography.labelSmall,maxLines=1,softWrap=false)
  }
 }
}
private fun detectWhatsAppProfiles(c:Context):Set<String> = try {
 val launcher=c.getSystemService(Context.LAUNCHER_APPS_SERVICE) as android.content.pm.LauncherApps
 val userManager=c.getSystemService(Context.USER_SERVICE) as UserManager
 launcher.profiles.mapNotNull { user ->
  runCatching { launcher.getActivityList("com.whatsapp",user) }.getOrNull()?.takeIf{it.isNotEmpty()}?.let {
   val serial=runCatching { userManager.getSerialNumberForUser(user) }.getOrDefault(-1L)
   when(serial) { 0L -> "main"; in 1L..Long.MAX_VALUE -> "clone"; else -> null }
  }
 }.toSet()
} catch (_:Exception) {
 if(runCatching{c.packageManager.getPackageInfo("com.whatsapp",0)}.isSuccess) setOf("main") else emptySet()
}
private fun accessibilityEnabled(c:Context)=try{val m=c.getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager;m.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK).any{it.resolveInfo.serviceInfo.packageName==c.packageName}}catch(_:Exception){false}
private fun batteryExempt(c:Context)= (c.getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(c.packageName)
private fun exactAllowed(c:Context)=Build.VERSION.SDK_INT<31 || (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).canScheduleExactAlarms()
private fun launchShortcutCheck(c:Context,chatId:String,profile:String,label:String){ChatScheduleStore.setPending(c,chatId); ShortcutCaptureStore.begin(c,chatId); val ok=WhatsAppAccessibilityService.requestHomeNavigation(); if(!ok){ShortcutCaptureStore.cancel(c);Toast.makeText(c,"Включи Специальные возможности для TS Моя работа, затем повтори привязку.",Toast.LENGTH_LONG).show()}else Toast.makeText(c,"Рабочий стол открыт. Вручную нажми ярлык «$label» профиля $profile. После открытия чата вернись сюда и нажми «Верно».",Toast.LENGTH_LONG).show()}

@Composable private fun GuideDialog(section:String,onSection:(String)->Unit,scroll:Int,onScroll:(Int)->Unit,onClose:()->Unit){val items=listOf("Назначение","Общие настройки","WhatsApp","Чаты и ярлыки","Разрешения","Samsung","Xiaomi / Redmi / POCO","Huawei / Honor","OPPO / Realme","Vivo","OnePlus","Motorola","Google Pixel","Другие Android");Dialog(onDismissRequest={},properties=DialogProperties(usePlatformDefaultWidth=false)){Surface(Modifier.fillMaxWidth(.96f).fillMaxHeight(.92f),shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(12.dp)){Row(verticalAlignment=Alignment.CenterVertically){Text("Инструкция",style=MaterialTheme.typography.titleLarge,modifier=Modifier.weight(1f));IconButton(onClick=onClose){Icon(Icons.Default.Close,"Закрыть", tint=Color.Red)}};Row(Modifier.weight(1f)){Column(Modifier.width(130.dp).verticalScroll(rememberScrollState())){items.forEach{TextButton(onClick={onSection(it)},modifier=Modifier.fillMaxWidth()){Text(it,style=MaterialTheme.typography.labelSmall)}}};Divider(Modifier.fillMaxHeight().width(1.dp));val state= rememberScrollState(scroll);LaunchedEffect(state.value){onScroll(state.value)};Column(Modifier.weight(1f).verticalScroll(state).padding(10.dp)){Text(section,style=MaterialTheme.typography.titleMedium);Spacer(Modifier.height(8.dp));Text(guideText(section) + if(section in setOf("Samsung","Xiaomi / Redmi / POCO","Huawei / Honor","OPPO / Realme","Vivo","OnePlus","Motorola","Google Pixel","Другие Android")) "\n\nЕсли кнопка Accessibility в TS Моя работа серая или не включается: откройте системные Настройки → Приложения → TS Моя работа и найдите специальные возможности/разрешения службы доступности. Разрешите службу там вручную, затем вернитесь в приложение и повторно нажмите «Доступ». Если раздел не виден, найдите «Специальные возможности» или «Accessibility» через поиск настроек. Это возможный дополнительный путь на разных марках телефонов." else "",style=MaterialTheme.typography.bodyMedium)}}}}}}
private fun guideText(s:String)=when(s){"Назначение"->"TS Моя работа запускает подтверждённый ярлык переписки по локальному расписанию. Для каждого чата отдельно выбирается режим: Чтение, Отправка или Проверка. Чтение не вводит текст; Проверка вставляет и очищает текст без отправки; Отправка использует прежнюю проверенную последовательность.";"Общие настройки"->"Тема: системная, светлая или тёмная. Масштаб регулируется от −50% до +200%. Сброс удаляет только настройки TS Моя работа и её будильники. Разрешения Android не отзываются.";"WhatsApp"->"Выберите основной WhatsApp или клон Dual Messenger. Для каждого чата ярлык подтверждается отдельно. Профиль WhatsApp нельзя надёжно установить только по Accessibility-событиям: проверяйте визуально, что ярлык ведёт в нужный аккаунт.";"Чаты и ярлыки"->"Галочкой включите чаты, которые должны участвовать в расписании; нажмите «Сохранить и применить», чтобы применить выбор и остановить текущее расписание. Для каждого чата подтвердите точное название ярлыка, затем выберите режим: Чтение (3 секунды, без ввода), Отправка (прежняя отправка) или Проверка (ввод и очистка без отправки). Кнопка «Ред.» меняет режим. Для каждого включённого чата нужно добавить хотя бы одно время. Для Отправки и Проверки требуется текст.";"Разрешения"->"Accessibility: Настройки → Специальные возможности → Установленные приложения → TS Моя работа → Включить. Батарея: Настройки → Приложения → TS Моя работа → Батарея → Без ограничений. Точные будильники: Настройки → Приложения → Специальный доступ → Будильники и напоминания. Уведомления: Настройки → Приложения → TS Моя работа → Уведомления.";"Samsung"->"Настройки → Приложения → TS Моя работа → Батарея → Без ограничений. Настройки → Обслуживание устройства → Батарея → Ограничения фонового использования: не добавлять приложение в спящие. Специальные возможности → Установленные приложения → TS Моя работа.";"Xiaomi / Redmi / POCO"->"Настройки → Приложения → Управление приложениями → TS Моя работа → Экономия энергии → Нет ограничений. Автозапуск: Настройки → Приложения → Разрешения → Автозапуск (путь зависит от MIUI/HyperOS). В информации приложения разрешить всплывающие окна/фоновые запуски, если доступны.";"Huawei / Honor"->"Настройки → Приложения → Запуск приложений → TS Моя работа → вручную; включить автозапуск, вторичный запуск и работу в фоне. Батарея → Оптимизация запуска/Оптимизация батареи: разрешить работу без ограничений, если пункт есть.";"OPPO / Realme"->"Настройки → Батарея → Управление расходом батареи приложениями → TS Моя работа → разрешить фоновую активность. В настройках приложений включить автозапуск и запуск из других приложений, если доступны.";"Vivo"->"Настройки → Батарея → Высокое фоновое энергопотребление → TS Моя работа разрешить. В iManager разрешить автозапуск и фоновую работу.";"OnePlus"->"Настройки → Батарея → Оптимизация батареи → TS Моя работа → Не оптимизировать. Проверьте управление автозапуском и фоновую активность.";"Motorola"->"Настройки → Приложения → TS Моя работа → Батарея → Без ограничений; Специальные возможности → TS Моя работа → Включить.";"Google Pixel"->"Настройки → Приложения → TS Моя работа → Батарея приложения → Без ограничений. Специальные возможности → TS Моя работа.";else->"Названия пунктов различаются в зависимости от версии Android и оболочки производителя. Откройте карточку приложения TS Моя работа в системных настройках и проверьте батарею, автозапуск, фоновые действия, уведомления, точные будильники и Accessibility. Производитель может ограничивать запуск экранов из фона."}
