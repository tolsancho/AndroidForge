package ru.tsautoreport.diagnostic

import android.accessibilityservice.AccessibilityService
import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityWindowInfo
import android.view.accessibility.AccessibilityNodeInfo
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Records technical metadata; reads only the user-specified launcher icon label during the explicit home-shortcut test. */
class WhatsAppAccessibilityService : AccessibilityService() {
    private val lastLogged = mutableMapOf<String, Long>()
    private var homeClickAttempted = false
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onServiceConnected() {
        super.onServiceConnected()
        activeService = this
        DiagnosticStore.add(this, "${stamp()} | ACCESSIBILITY_SERVICE_CONNECTED | homeNavigation=available")
    }

    override fun onDestroy() {
        if (activeService === this) activeService = null
        super.onDestroy()
    }

    /** Close the app drawer/launcher overlay by issuing the system HOME action.
     * This does not force-stop or close other applications. */
    fun navigateHomeAndScan(): Boolean {
        val first = try { performGlobalAction(GLOBAL_ACTION_HOME) } catch (_: Exception) { false }
        DiagnosticStore.add(this, "${stamp()} | HOME_GLOBAL_ACTION | attempt=1 | accepted=$first")
        mainHandler.postDelayed({
            val second = try { performGlobalAction(GLOBAL_ACTION_HOME) } catch (_: Exception) { false }
            DiagnosticStore.add(this, "${stamp()} | HOME_GLOBAL_ACTION | attempt=2 | accepted=$second")
            mainHandler.postDelayed({ scanActiveLauncher("delayed_1200ms") }, 450)
        }, 700)
        mainHandler.postDelayed({ scanActiveLauncher("delayed_2500ms") }, 1800)
        mainHandler.postDelayed({ scanActiveLauncher("delayed_5000ms") }, 4300)
        return first
    }

    private fun scanActiveLauncher(source: String) {
        if (HomeShortcutStore.pendingLabel(this) == null || homeClickAttempted) return
        val root = try { rootInActiveWindow } catch (_: Exception) { null } ?: return
        val pkg = root.packageName?.toString().orEmpty()
        try {
            if (pkg in launcherPackages) {
                DiagnosticStore.add(this, "${stamp()} | HOME_LAUNCHER_SCAN_TRIGGER | source=$source | launcher=$pkg")
                inspectHomeShortcut(pkg)
            } else {
                DiagnosticStore.add(this, "${stamp()} | HOME_LAUNCHER_NOT_FOREGROUND | source=$source | foreground=$pkg")
            }
        } finally { try { root.recycle() } catch (_: Exception) {} }
    }

    companion object {
        @Volatile private var activeService: WhatsAppAccessibilityService? = null
        private val launcherPackages = setOf(
            "com.sec.android.app.launcher", "com.android.launcher3",
            "com.google.android.apps.nexuslauncher", "com.miui.home",
            "com.oppo.launcher", "com.oneplus.launcher", "com.huawei.android.launcher"
        )
        fun requestHomeNavigation(): Boolean = activeService?.navigateHomeAndScan() ?: false
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString() ?: return
        if (HomeShortcutStore.pendingLabel(this) == null) homeClickAttempted = false
        if (pkg != "com.whatsapp") {
            if (HomeShortcutStore.pendingLabel(this) != null && pkg in launcherPackages) inspectHomeShortcut(pkg)
            return
        }

        val type = when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> "WINDOW_STATE_CHANGED"
            AccessibilityEvent.TYPE_WINDOWS_CHANGED -> "WINDOWS_CHANGED"
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED -> "WINDOW_CONTENT_CHANGED"
            AccessibilityEvent.TYPE_VIEW_FOCUSED -> "VIEW_FOCUSED"
            else -> "EVENT_${event.eventType}"
        }
        val cls = event.className?.toString() ?: "(class-not-provided)"
        val winId = event.windowId
        if (cls == "com.whatsapp.Conversation") {
            ProfileBindingStore.observeConversation(this, winId, cls, System.currentTimeMillis())
            HomeShortcutStore.markConversationObserved(this, winId)
        }
        val displayId = if (Build.VERSION.SDK_INT >= 30) event.displayId else -1
        val now = System.currentTimeMillis()
        val fingerprint = "$type|$pkg|$cls|$winId|$displayId"
        val throttleMs = if (event.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) 900L else 250L
        val previous = lastLogged[fingerprint] ?: 0L
        if (now - previous < throttleMs) return
        lastLogged[fingerprint] = now
        if (lastLogged.size > 100) lastLogged.clear()

        val sourceInfo = try {
            event.source?.let { node ->
                val result = "source=${node.packageName}/${node.className}#${node.windowId}"
                node.recycle()
                result
            } ?: "source=null"
        } catch (_: Exception) { "source=unavailable" }
        val activeRoot = try {
            rootInActiveWindow?.let { root ->
                val result = "root=${root.packageName}/${root.className}#${root.windowId}"
                root.recycle()
                result
            } ?: "root=null"
        } catch (_: Exception) { "root=unavailable" }
        val windows = try { describeWindows() } catch (_: Exception) { "windows=unavailable" }
        val processReport = try { runningProcessReport() } catch (_: Exception) { "runningProcesses=unavailable" }
        val time = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault()).format(Date(now))
        DiagnosticStore.add(this, "$time | $type | pkg=$pkg | class=$cls | eventWindow=$winId | display=$displayId | $sourceInfo | $activeRoot | $windows | $processReport | originUserHandle=NOT_EXPOSED_BY_ACCESSIBILITY_EVENT")
    }


    /**
     * Assisted launcher-icon method: after the user requests a clone-only test, inspect only
     * launcher accessibility nodes for the exact user-entered home-screen shortcut label.
     * It never reads WhatsApp conversation UI or message contents.
     */
    private fun inspectHomeShortcut(launcherPackage: String) {
        if (homeClickAttempted) return
        val target = HomeShortcutStore.pendingLabel(this) ?: return
        val root = try { rootInActiveWindow } catch (_: Exception) { null } ?: return
        if (root.packageName?.toString() != launcherPackage) {
            try { root.recycle() } catch (_: Exception) {}
            return
        }
        val candidates = mutableListOf<AccessibilityNodeInfo>()
        try {
            collectMatchingNodes(root, target, candidates, 0)
            val unique = candidates.distinctBy { node ->
                val r = android.graphics.Rect(); node.getBoundsInScreen(r)
                "${node.viewIdResourceName}|${r.flattenToString()}"
            }
            if (unique.size == 1) {
                val clickable = findClickableAncestor(unique.first())
                if (clickable != null) {
                    homeClickAttempted = true
                    val clicked = try { clickable.performAction(AccessibilityNodeInfo.ACTION_CLICK) } catch (_: Exception) { false }
                    try { clickable.recycle() } catch (_: Exception) {}
                    HomeShortcutStore.finish(this, if (clicked) "LAUNCHER_ICON_CLICK_ACTION_ACCEPTED" else "LAUNCHER_ICON_CLICK_REJECTED", unique.size, clicked)
                } else {
                    HomeShortcutStore.finish(this, "MATCH_FOUND_BUT_NO_CLICKABLE_ANCESTOR", unique.size, false)
                }
            } else if (unique.size > 1) {
                HomeShortcutStore.finish(this, "AMBIGUOUS_MULTIPLE_MATCHES_NO_CLICK", unique.size, false)
            } else {
                // Keep the request pending while the home screen is still populating.
                DiagnosticStore.add(this, "${stamp()} | HOME_SHORTCUT_SCAN | launcher=$launcherPackage | label=$target | matches=0 | retry_on_next_launcher_event=true")
            }
        } finally {
            candidates.forEach { try { it.recycle() } catch (_: Exception) {} }
            try { root.recycle() } catch (_: Exception) {}
        }
    }

    private fun collectMatchingNodes(node: AccessibilityNodeInfo, target: String, out: MutableList<AccessibilityNodeInfo>, depth: Int) {
        if (depth > 18 || out.size > 12) return
        val text = node.text?.toString().orEmpty().trim()
        val desc = node.contentDescription?.toString().orEmpty().trim()
        fun matches(value: String): Boolean {
            if (value.length < 3) return false
            val a = value.lowercase(Locale.ROOT).replace("…", "").replace("...", "").trim()
            val b = target.trim().lowercase(Locale.ROOT).replace("…", "").replace("...", "").trim()
            return a == b || (a.startsWith(b) && b.length >= 4) || (b.startsWith(a) && a.length >= 5)
        }
        if (matches(text) || matches(desc)) out.add(AccessibilityNodeInfo.obtain(node))
        for (i in 0 until node.childCount) {
            val child = try { node.getChild(i) } catch (_: Exception) { null } ?: continue
            try { collectMatchingNodes(child, target, out, depth + 1) } finally { try { child.recycle() } catch (_: Exception) {} }
        }
    }

    private fun findClickableAncestor(start: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var node: AccessibilityNodeInfo? = AccessibilityNodeInfo.obtain(start)
        repeat(6) {
            val current = node ?: return null
            if (current.isClickable) return current
            val parent = try { current.parent } catch (_: Exception) { null }
            try { current.recycle() } catch (_: Exception) {}
            node = parent
        }
        node?.let { try { it.recycle() } catch (_: Exception) {} }
        return null
    }

    private fun runningProcessReport(): String {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val running = am.runningAppProcesses.orEmpty()
        if (running.isEmpty()) return "runningProcesses=not_visible_or_empty"
        val whatsapp = running.filter { it.processName.contains("com.whatsapp") }
        return if (whatsapp.isEmpty()) "runningProcesses=WhatsApp_process_not_exposed (visible=${running.size})"
        else "runningProcesses=" + whatsapp.joinToString(";") { "${it.processName}:uid=${it.uid}:importance=${it.importance}" }
    }

    private fun describeWindows(): String {
        val entries = windows.orEmpty().take(8).map { w: AccessibilityWindowInfo ->
            val root = try { w.root } catch (_: Exception) { null }
            val rootPkg = root?.packageName?.toString() ?: "?"
            val rootClass = root?.className?.toString() ?: "?"
            val display = if (Build.VERSION.SDK_INT >= 30) w.displayId else -1
            val description = "${w.id}:${w.type}:active=${w.isActive}:focused=${w.isFocused}:display=$display:$rootPkg/$rootClass"
            root?.recycle()
            description
        }
        return "windows=[${entries.joinToString(";")}]"
    }

    /** Local timestamp helper for automatic diagnostic journal entries. */
    private fun stamp(): String = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault()).format(Date())

    override fun onInterrupt() = Unit
}
