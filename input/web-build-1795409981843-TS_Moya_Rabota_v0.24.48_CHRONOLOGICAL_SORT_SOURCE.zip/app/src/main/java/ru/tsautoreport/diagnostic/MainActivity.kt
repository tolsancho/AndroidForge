package ru.tsautoreport.diagnostic

import android.app.Activity
import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.content.ClipData
import android.content.ClipboardManager
import android.os.UserManager
import android.provider.Settings
import android.accessibilityservice.AccessibilityServiceInfo
import android.view.accessibility.AccessibilityManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.GenericShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import java.util.Calendar

private val DrawerGripShape = GenericShape { size, _ ->
    val w = size.width
    val h = size.height
    // The wide grip is a true rounded rectangle: all four corners use the same radius.
    // The narrow extension joins its right edge with matching top/bottom shoulder curves.
    val headRight = w * 0.48f
    val headRadius = h * 0.22f
    val neckRadius = h * 0.08f
    val neckTop = h * 0.33f
    val neckBottom = h * 0.67f

    moveTo(headRadius, 0f)
    lineTo(headRight - headRadius, 0f)
    quadraticBezierTo(headRight, 0f, headRight, headRadius)
    lineTo(headRight, neckTop - neckRadius)
    quadraticBezierTo(headRight, neckTop, headRight + neckRadius, neckTop)
    lineTo(w, neckTop)
    lineTo(w, neckBottom)
    lineTo(headRight + neckRadius, neckBottom)
    quadraticBezierTo(headRight, neckBottom, headRight, neckBottom + neckRadius)
    lineTo(headRight, h - headRadius)
    quadraticBezierTo(headRight, h, headRight - headRadius, h)
    lineTo(headRadius, h)
    quadraticBezierTo(0f, h, 0f, h - headRadius)
    lineTo(0f, headRadius)
    quadraticBezierTo(0f, 0f, headRadius, 0f)
    close()
}

class MainActivity : ComponentActivity() {
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState); val p=getSharedPreferences("ts_activation",0); if(!p.getBoolean("activated",false)){setContent{ActivationScreen{p.edit().putBoolean("activated",true).commit(); recreate() }};return}; setContent{ WorkApp() } }
}

@Composable private fun ActivationScreen(done:()->Unit){
 var pass by remember{mutableStateOf("")}
 val dark = androidx.compose.foundation.isSystemInDarkTheme()
 val colors = if(dark) darkColorScheme(primary=Color(0xFF79C99A),onPrimary=Color(0xFF10291B),background=Color(0xFF171619),onBackground=Color(0xFFD6D2D9),surface=Color(0xFF211F24),onSurface=Color(0xFFD6D2D9),surfaceVariant=Color(0xFF302C33),onSurfaceVariant=Color(0xFFC5C0C9)) else lightColorScheme(primary=Color(0xFF237A48),onPrimary=Color.White,background=Color.White,onBackground=Color(0xFF171717),surface=Color.White,onSurface=Color(0xFF171717),surfaceVariant=Color(0xFFF0F0F0),onSurfaceVariant=Color(0xFF303030))
 val activity = LocalContext.current as? Activity
 MaterialTheme(colorScheme=colors){
  SideEffect { activity?.window?.let { w -> w.statusBarColor=if(dark)android.graphics.Color.rgb(23,22,25) else android.graphics.Color.WHITE; w.navigationBarColor=if(dark)android.graphics.Color.rgb(23,22,25) else android.graphics.Color.WHITE; @Suppress("DEPRECATION") val flags=if(dark)0 else android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR; @Suppress("DEPRECATION") w.decorView.systemUiVisibility=flags } }
  Surface(Modifier.fillMaxSize(),color=MaterialTheme.colorScheme.background){
   // imePadding reduces the usable height when the keyboard opens, keeping the whole
   // centered password form above it instead of letting the keyboard cover the button.
   BoxWithConstraints(Modifier.fillMaxSize().imePadding()) {
    Column(
     Modifier.fillMaxWidth().heightIn(min=maxHeight).verticalScroll(rememberScrollState()).padding(horizontal=28.dp, vertical=20.dp),
     verticalArrangement=Arrangement.Center,
     horizontalAlignment=Alignment.CenterHorizontally
    ) {
     Text("Пароль ка черкани или не видать тебе чёткой смены.",style=MaterialTheme.typography.titleLarge,color=MaterialTheme.colorScheme.onBackground,textAlign=TextAlign.Center,modifier=Modifier.fillMaxWidth())
     Spacer(Modifier.height(18.dp))
     OutlinedTextField(pass,{pass=capitalizeLabel(it)},modifier=Modifier.fillMaxWidth(),label={Text("Пароль")},visualTransformation=PasswordVisualTransformation(),singleLine=true,keyboardOptions=KeyboardOptions(capitalization=KeyboardCapitalization.Sentences,keyboardType=KeyboardType.Password))
     Spacer(Modifier.height(14.dp))
     Button(onClick={if(pass=="TolSancho")done()},modifier=Modifier.align(Alignment.CenterHorizontally)){Text("Продолжить")}
    }
   }
  }
 }
}

@Composable private fun WorkApp(){
 val ctx= LocalContext.current; val prefs= remember{ctx.getSharedPreferences("ts_ui",0)}
 val availableProfiles= remember { detectWhatsAppProfiles(ctx) }; var chats by remember { mutableStateOf(ChatScheduleStore.all(ctx)) }; var pendingScheduleSave by remember{mutableStateOf(false)}; var pendingEnabled by remember { mutableStateOf(chats.filter{it.enabled}.map{it.id}.toSet()) }; var active by remember{mutableStateOf(ScheduledTestStore.active(ctx))}; var stateKnown by remember{mutableStateOf(ctx.getSharedPreferences("ts_ui",0).getBoolean("state_known",false))}; var permissionTick by remember{mutableIntStateOf(0)}; var captureTick by remember{mutableIntStateOf(0)}; var verifyTick by remember{mutableIntStateOf(0)}; var verifyingChat by remember{mutableStateOf("")}; var permissionWarning by remember{mutableStateOf("")}
 var showDiagnosticJournal by remember{mutableStateOf(false)}; var diagnosticRefresh by remember{mutableIntStateOf(0)}; var showAccessOptions by remember{mutableStateOf(false)}; var drawer by remember{mutableStateOf(false)}; var instruction by remember{mutableStateOf(false)}; var section by remember{mutableStateOf(prefs.getString("guide_section","Назначение")?:"Назначение")}; var scale by remember{mutableFloatStateOf(prefs.getInt("scale",0).coerceIn(-10,10).toFloat().also { safe -> if (safe.toInt() != prefs.getInt("scale",0)) prefs.edit().putInt("scale",safe.toInt()).apply() })}; var theme by remember{mutableStateOf(prefs.getString("theme","system")?:"system")}; var ownerPassword by remember{mutableStateOf(prefs.getString("owner_password","").orEmpty())}; var ownerGate by remember{mutableStateOf(ownerPassword.isNotBlank())}; var showPasswordDialog by remember{mutableStateOf(false)}; var passDraft by remember{mutableStateOf("")}; var expandedChat by remember{mutableStateOf("")}; var expandedInterval by remember{mutableStateOf("")}; var showTimeFor by remember{mutableStateOf("")}; var showMessageFor by remember{mutableStateOf("")}; var draftMessage by remember{mutableStateOf("")}; var draftTime by remember{mutableStateOf("00:00")}; var pickerHour by remember{mutableIntStateOf(0)}; var pickerMinute by remember{mutableIntStateOf(0)}; var showAddChat by remember{mutableStateOf(false)}; var newLabel by remember{mutableStateOf("")}; var newProfile by remember{mutableStateOf(if("clone" in availableProfiles)"clone" else "main")}; var pendingConfirm by remember{mutableStateOf("")}; var editingModeChat by remember{mutableStateOf("")}; var modeDraft by remember{mutableStateOf("SEND")}; var guideScroll by remember{mutableIntStateOf(prefs.getInt("guide_scroll",0))}
 val dark = when(theme){"dark"->true;"light"->false;else-> androidx.compose.foundation.isSystemInDarkTheme()}
 SideEffect { (ctx as? Activity)?.window?.let { w -> w.statusBarColor=if(dark)android.graphics.Color.rgb(23,22,25) else android.graphics.Color.WHITE; w.navigationBarColor=if(dark)android.graphics.Color.rgb(23,22,25) else android.graphics.Color.WHITE; @Suppress("DEPRECATION") val flags=if(dark)0 else android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR; @Suppress("DEPRECATION") w.decorView.systemUiVisibility=flags } }
 val cs= if(dark) darkColorScheme(
  primary=Color(0xFF79C99A), onPrimary=Color(0xFF10291B),
  secondary=Color(0xFFB9A2C8), onSecondary=Color(0xFF241D2A),
  background=Color(0xFF171619), onBackground=Color(0xFFD6D2D9),
  surface=Color(0xFF211F24), onSurface=Color(0xFFD6D2D9),
  surfaceVariant=Color(0xFF302C33), onSurfaceVariant=Color(0xFFC5C0C9),
  outline=Color(0xFF625C66), outlineVariant=Color(0xFF49434D),
  surfaceContainerLowest=Color(0xFF171619), surfaceContainerLow=Color(0xFF1D1B20), surfaceContainer=Color(0xFF242127), surfaceContainerHigh=Color(0xFF2A272E), surfaceContainerHighest=Color(0xFF302C33),
  error=Color(0xFFFFB4AB), onError=Color(0xFF690005)
 ) else lightColorScheme(
  primary=Color(0xFF237A48), onPrimary=Color.White,
  secondary=Color(0xFF86552F), onSecondary=Color.White,
  background=Color.White, onBackground=Color(0xFF171717),
  surface=Color.White, onSurface=Color(0xFF171717),
  surfaceVariant=Color(0xFFF0F0F0), onSurfaceVariant=Color(0xFF303030),
  outline=Color(0xFF666666), outlineVariant=Color(0xFFB0B0B0)
 )
 fun refresh(){chats=ChatScheduleStore.all(ctx);pendingEnabled=chats.filter{it.enabled}.map{it.id}.toSet();active=ScheduledTestStore.active(ctx)}
 LaunchedEffect(showDiagnosticJournal){ if(showDiagnosticJournal){ delay(60_000L); showDiagnosticJournal=false } }
 LaunchedEffect(Unit){while(true){
  active=ScheduledTestStore.active(ctx); HiddenJournalGate.expireIfNeeded(ctx); permissionTick++; if(pendingConfirm.isNotBlank()) captureTick++; if(verifyingChat.isNotBlank()) verifyTick++
  val problems=PermissionGate.status(ctx).problems()
  if(active && problems.isNotEmpty()){
   ScheduledTestStore.cancel(ctx); active=false
   permissionWarning=problems.joinToString("\n")
   PermissionGate.notifyBlocked(ctx,problems)
  }
  delay(1000)
 }}
 fun persist(list:List<WorkChat>){ chats=list;pendingEnabled=list.filter{it.enabled}.map{it.id}.toSet();pendingScheduleSave=(list!=ChatScheduleStore.all(ctx)) }
 fun applyPendingSchedule(){ if(pendingScheduleSave){ val previous=ChatScheduleStore.all(ctx); ChatScheduleStore.save(ctx,chats); if(ScheduledTestStore.active(ctx)) ScheduledTestStore.reconcileLive(ctx,previous,chats); pendingScheduleSave=false; active=ScheduledTestStore.active(ctx); Toast.makeText(ctx,"Изменения сохранены. Работа очереди продолжается.",Toast.LENGTH_SHORT).show() } }
 BackHandler(drawer||instruction||ownerGate){ if(ownerGate) Unit else if(instruction) instruction=false else drawer=false }
 val baseDensity=LocalDensity.current
 CompositionLocalProvider(LocalDensity provides androidx.compose.ui.unit.Density(baseDensity.density*(1f+scale.coerceIn(-10f,10f)/100f), baseDensity.fontScale*(1f+scale.coerceIn(-10f,10f)/100f))){ MaterialTheme(colorScheme=cs){
  CompositionLocalProvider(androidx.compose.material3.LocalContentColor provides MaterialTheme.colorScheme.onBackground){
  Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)){
   Column(Modifier.fillMaxSize().statusBarsPadding().padding(bottom=84.dp).verticalScroll(rememberScrollState()).padding(horizontal=24.dp, vertical=16.dp), horizontalAlignment=Alignment.CenterHorizontally){
    Box(Modifier.fillMaxWidth().heightIn(min=52.dp)){ Text("TS Моя работа",style=MaterialTheme.typography.headlineMedium,modifier=Modifier.align(Alignment.CenterStart)) }
    Spacer(Modifier.height(12.dp)); Text("Разрешения",style=MaterialTheme.typography.titleMedium,modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.Center)
    val permissionStatus = remember(permissionTick) { PermissionGate.status(ctx) }
    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(3.dp),verticalAlignment=Alignment.CenterVertically){
     PermissionPill("Доступ",permissionStatus.accessibility,Modifier.weight(1f)){showAccessOptions=true}
     PermissionPill("Батар.",permissionStatus.battery,Modifier.weight(1f)){PermissionGate.openBattery(ctx)}
     PermissionPill("Будил.",permissionStatus.exactAlarm,Modifier.weight(1f)){PermissionGate.openAlarm(ctx)}
     PermissionPill("Увед.",permissionStatus.notifications,Modifier.weight(1f)){PermissionGate.openNotifications(ctx)}
     PermissionPill("Замок",permissionStatus.screenLockDisabled,Modifier.weight(1f)){PermissionGate.openLockSettings(ctx)}
    }
    Spacer(Modifier.height(18.dp)); Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Text("Чаты",style=MaterialTheme.typography.titleLarge,modifier=Modifier.weight(1f),textAlign=TextAlign.Center);Text("${chats.size}/10",style=MaterialTheme.typography.labelLarge)}
    Text("Введите точное название ярлыка переписки на рабочем столе. Проверка откроет именно этот ярлык; вернитесь сюда и подтвердите результат.",style=MaterialTheme.typography.bodySmall,modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.Center,color=MaterialTheme.colorScheme.onSurfaceVariant)
    chats.forEach { chat ->
     Card(Modifier.fillMaxWidth().padding(vertical=5.dp),shape=RoundedCornerShape(16.dp)){
      Column(Modifier.padding(12.dp)){
       Row(verticalAlignment=Alignment.CenterVertically,modifier=Modifier.fillMaxWidth()){
        Checkbox(checked=chat.id in pendingEnabled,onCheckedChange={checked->pendingEnabled=if(checked)pendingEnabled+chat.id else pendingEnabled-chat.id})
        Column(Modifier.weight(1f).clickable{expandedChat=if(expandedChat==chat.id)"" else chat.id;expandedInterval=""}){Text(chat.launcherLabel.ifBlank{"Новый чат"},style=MaterialTheme.typography.titleMedium);Text("${chat.profile.uppercase()} · ${chat.intervals.size}/24 интервалов",style=MaterialTheme.typography.bodySmall)}
        if(chat.behavior.isNotBlank()) {
         val (modeTitle,modeColor,modeText)=when(chat.behavior){"READ"->Triple("Чтение",Color(0xFF3979C9),Color.White);"CHECK"->Triple("Проверка",Color(0xFFE05A5A),Color.Black);else->Triple("Отправка",Color(0xFF238447),Color.White)}
         Surface(color=modeColor,shape=RoundedCornerShape(50)){Text(modeTitle,color=modeText,style=MaterialTheme.typography.labelSmall,modifier=Modifier.padding(horizontal=9.dp,vertical=5.dp))}
         Spacer(Modifier.width(5.dp)); TextButton(onClick={editingModeChat=chat.id;modeDraft=chat.behavior;expandedChat=chat.id}){Text("Ред.",color=MaterialTheme.colorScheme.onSurfaceVariant)}
        }
        Text(if(expandedChat==chat.id)"⌃" else "⌄",modifier=Modifier.clickable{expandedChat=if(expandedChat==chat.id)"" else chat.id;expandedInterval=""})
       }
       AnimatedVisibility(expandedChat==chat.id,enter=androidx.compose.animation.expandVertically(tween(220)),exit=androidx.compose.animation.shrinkVertically(tween(180))){
        Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
         if(!chat.confirmed || pendingConfirm==chat.id){
          Text("Ярлык рабочего стола",style=MaterialTheme.typography.labelLarge)
          OutlinedTextField(chat.launcherLabel,{v->val capitalized=capitalizeLabel(v.take(100)); persist(chats.map{if(it.id==chat.id)it.copy(launcherLabel=capitalized,confirmed=false) else it})},modifier=Modifier.fillMaxWidth(),singleLine=true,keyboardOptions=KeyboardOptions(capitalization=KeyboardCapitalization.Sentences,autoCorrectEnabled=true))
          Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
           if("main" in availableProfiles) FilterChip(selected=chat.profile=="main",onClick={persist(chats.map{if(it.id==chat.id)it.copy(profile="main",confirmed=false)else it})},modifier=Modifier.weight(1f).height(58.dp),label={Text("Основной\nWhatsApp",modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.Center)})
           if("clone" in availableProfiles) FilterChip(selected=chat.profile=="clone",onClick={persist(chats.map{if(it.id==chat.id)it.copy(profile="clone",confirmed=false)else it})},modifier=Modifier.weight(1f).height(58.dp),label={Text("Клон\nWhatsApp",modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.Center)})
          }
         }
         OutlinedButton(onClick={val modelSaved=ChatScheduleStore.save(ctx,chats); if(!modelSaved){Toast.makeText(ctx,"Не удалось сохранить данные чата перед привязкой ярлыка.",Toast.LENGTH_LONG).show()}else{pendingConfirm=chat.id; launchShortcutCheck(ctx,chat.id,chat.profile,chat.launcherLabel)} },modifier=Modifier.fillMaxWidth(),enabled=chat.launcherLabel.isNotBlank()) { Text(if(chat.confirmed) "Перепривязать ярлык" else "Привязать ярлык",modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.Center) }
         if(chat.confirmed && pendingConfirm!=chat.id){
          OutlinedButton(onClick={val modelSaved=ChatScheduleStore.save(ctx,chats); if(!modelSaved){Toast.makeText(ctx,"Не удалось сохранить данные чата перед проверкой ярлыка.",Toast.LENGTH_LONG).show()}else{verifyingChat=chat.id; ShortcutCaptureStore.beginVerification(ctx,chat.id); ChatScheduleStore.setPending(ctx,chat.id); val ok=WhatsAppAccessibilityService.requestHomeNavigation(); if(!ok){ShortcutCaptureStore.finishVerification(ctx,chat.id,false);ChatScheduleStore.clearPending(ctx);verifyingChat="";Toast.makeText(ctx,"Не удалось открыть рабочий стол через службу доступности. Проверь разрешение и повтори.",Toast.LENGTH_LONG).show()}else Toast.makeText(ctx,"Открываю сохранённый ярлык. Проверь чат и профиль, затем вернись сюда.",Toast.LENGTH_LONG).show()}},modifier=Modifier.fillMaxWidth()) { Text("Проверить ярлык",modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.Center) }
          Text("Имя для поиска: ${chat.launcherLabel}",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
          ShortcutCaptureStore.summary(ctx,chat.id)?.let { saved ->
           Text("Распознано при привязке: ${saved.visibleName.ifBlank { "лаунчер не передал название; будет использоваться точное имя выше" }}",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
           Text("Лаунчер: ${saved.launcher}",style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
          }
         }
         if(verifyingChat==chat.id){
          val ready=remember(verifyTick,chat.id){ShortcutCaptureStore.canConfirmVerification(ctx,chat.id)}
          Text(if(ready) "WhatsApp открылся по сохранённому ярлыку. Проверь, что это нужный чат и профиль." else "Ищу сохранённый ярлык на рабочем столе и открываю его…",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
          Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
           Button(onClick={if(ShortcutCaptureStore.canConfirmVerification(ctx,chat.id)){ShortcutCaptureStore.finishVerification(ctx,chat.id,true);ChatScheduleStore.clearPending(ctx);verifyingChat="";Toast.makeText(ctx,"Проверка ярлыка подтверждена.",Toast.LENGTH_SHORT).show()}},enabled=ready,modifier=Modifier.weight(1f)){Text("Верно",modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.Center)}
           OutlinedButton(onClick={ShortcutCaptureStore.finishVerification(ctx,chat.id,false);ChatScheduleStore.clearPending(ctx);verifyingChat=""},modifier=Modifier.weight(1f)){Text("Не верно",modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.Center)}
          }
         }
         if(pendingConfirm==chat.id){
          val shortcutReady = remember(captureTick, chat.id) { ShortcutCaptureStore.canConfirm(ctx,chat.id) }
          Text(if(shortcutReady) "WhatsApp открыт. Проверь визуально нужный чат и профиль, затем нажми «Верно»." else "После выхода на рабочий стол вручную нажми нужный ярлык с фотографией профиля. Дождись открытия WhatsApp и вернись сюда.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
          Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
           Button(onClick={if(ShortcutCaptureStore.confirm(ctx,chat.id)){ChatScheduleStore.clearPending(ctx);persist(chats.map{if(it.id==chat.id)it.copy(confirmed=true)else it});pendingConfirm=""}else Toast.makeText(ctx,"Сначала открой нужный ярлык и дождись появления переписки.",Toast.LENGTH_LONG).show()},enabled=shortcutReady,modifier=Modifier.weight(1f)){Text("Верно",modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.Center)}
           OutlinedButton(onClick={ShortcutCaptureStore.cancel(ctx);ChatScheduleStore.clearPending(ctx);pendingConfirm=""},modifier=Modifier.weight(1f)){Text("Не верно",modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.Center)}
          }
         }
         if(!chat.confirmed) Text("Ярлык ещё не подтверждён",color=MaterialTheme.colorScheme.error,style=MaterialTheme.typography.bodySmall)
         if(chat.behavior.isBlank() || editingModeChat==chat.id){
          Text("Режим работы чата",style=MaterialTheme.typography.labelLarge)
          Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(5.dp)){
           listOf("READ" to "Чтение","SEND" to "Отправка","CHECK" to "Проверка").forEach{(key,label)->
            val color=when(key){"READ"->Color(0xFF3979C9);"CHECK"->Color(0xFFE05A5A);else->Color(0xFF238447)}
            Button(onClick={modeDraft=key},modifier=Modifier.weight(1f),contentPadding=PaddingValues(horizontal=3.dp,vertical=7.dp),colors=ButtonDefaults.buttonColors(containerColor=if(modeDraft==key)color else MaterialTheme.colorScheme.surfaceVariant,contentColor=if(modeDraft==key)Color.White else MaterialTheme.colorScheme.onSurface)){Text(label,style=MaterialTheme.typography.labelSmall,maxLines=1)}
           }
          }
          Button(onClick={persist(chats.map{if(it.id==chat.id)it.copy(behavior=modeDraft)else it});editingModeChat=""},modifier=Modifier.align(Alignment.CenterHorizontally)){Text("Сохранить режим")}
         }
         HorizontalDivider()
         chat.intervals.sortedBy { slot -> runCatching { val parts=slot.time.split(":"); parts[0].toInt()*60+parts[1].toInt() }.getOrDefault(Int.MAX_VALUE) }.forEach { slot ->
          Column(Modifier.fillMaxWidth().border(1.dp,MaterialTheme.colorScheme.outlineVariant,RoundedCornerShape(12.dp)).padding(9.dp)){
           Row(Modifier.fillMaxWidth().clickable{expandedInterval=if(expandedInterval==slot.id)"" else slot.id},verticalAlignment=Alignment.CenterVertically){Text(slot.time,style=MaterialTheme.typography.titleMedium);Spacer(Modifier.width(10.dp));Text(slot.message.take(42),Modifier.weight(1f),style=MaterialTheme.typography.bodySmall);Box(Modifier.size(10.dp).clip(RoundedCornerShape(50)).background(if(ScheduledTestStore.isFired(ctx,chat.id,slot.id)) Color(0xFFD94A4A) else Color(0xFF36B978)))
            Spacer(Modifier.width(8.dp)); Text(if(expandedInterval==slot.id)"⌃" else "⌄")}
           if(expandedInterval==slot.id){Row(verticalAlignment=Alignment.CenterVertically){Text("Время: ${slot.time}");Spacer(Modifier.width(8.dp));TextButton(onClick={draftTime=slot.time;pickerHour=slot.time.substringBefore(":").toIntOrNull()?:0;pickerMinute=slot.time.substringAfter(":").toIntOrNull()?:0;showTimeFor="edit:${chat.id}:${slot.id}"}){Text("Изменить")};Spacer(Modifier.weight(1f));TextButton(onClick={persist(chats.map{c->if(c.id==chat.id)c.copy(intervals=c.intervals.filterNot{it.id==slot.id})else c})}){Text("Удалить")}}
            if(chat.behavior!="READ") { Text("Сообщение: ${slot.message.take(120)}",style=MaterialTheme.typography.bodySmall); OutlinedButton(onClick={draftMessage=slot.message;showMessageFor="edit:${chat.id}:${slot.id}"},modifier=Modifier.fillMaxWidth()){Text(if(slot.message.isBlank())"Добавить сообщение" else "Изменить сообщение") } }
            Text(if(ScheduledTestStore.isFired(ctx,chat.id,slot.id)) "Отправлено" else "Ожидает", modifier=Modifier.fillMaxWidth(), textAlign=TextAlign.Center, style=MaterialTheme.typography.titleMedium, color=if(ScheduledTestStore.isFired(ctx,chat.id,slot.id)) Color(0xFFD94A4A) else Color(0xFF36B978))
           }
          }
         }
         OutlinedButton(onClick={if(chat.intervals.size<24){draftTime="00:00";pickerHour=0;pickerMinute=0;draftMessage="";showTimeFor=chat.id}},enabled=chat.intervals.size<24,modifier=Modifier.wrapContentWidth().align(Alignment.CenterHorizontally),border=androidx.compose.foundation.BorderStroke(1.dp,MaterialTheme.colorScheme.primary),colors=ButtonDefaults.outlinedButtonColors(contentColor=MaterialTheme.colorScheme.primary)){Text("＋ Добавить время",modifier=Modifier.padding(horizontal=8.dp))}
         TextButton(onClick={persist(chats.filterNot{it.id==chat.id});expandedChat=""}){Text("Удалить чат")}
        }
       }
      }
     }
    }
    OutlinedButton(onClick={showAddChat=true},enabled=chats.size<10,modifier=Modifier.wrapContentWidth().align(Alignment.CenterHorizontally),border=androidx.compose.foundation.BorderStroke(1.dp,MaterialTheme.colorScheme.primary),colors=ButtonDefaults.outlinedButtonColors(contentColor=MaterialTheme.colorScheme.primary)){Text("＋ Добавить чат",modifier=Modifier.padding(horizontal=8.dp))}
   }
   // fixed footer
   Surface(Modifier.align(Alignment.BottomCenter).fillMaxWidth(),shadowElevation=8.dp,color=MaterialTheme.colorScheme.surface){Column(Modifier.navigationBarsPadding().padding(10.dp),verticalArrangement=Arrangement.spacedBy(7.dp)){
    if(pendingScheduleSave) OutlinedButton(onClick={applyPendingSchedule()},modifier=Modifier.fillMaxWidth()){Text("Сохранить изменения",modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.Center)}
    if(pendingEnabled != chats.filter{it.enabled}.map{it.id}.toSet()) Button(onClick={val next=chats.map{it.copy(enabled=it.id in pendingEnabled)};ScheduledTestStore.cancel(ctx);ChatScheduleStore.save(ctx,next);chats=next;active=false;stateKnown=true;prefs.edit().putBoolean("state_known",true).apply();pendingEnabled=next.filter{it.enabled}.map{it.id}.toSet();Toast.makeText(ctx,"Выбор чатов применён. Расписание остановлено — нажми «Сохранить и запустить».",Toast.LENGTH_LONG).show()},modifier=Modifier.fillMaxWidth()){Text("Сохранить и применить",modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.Center)}
    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){
    Button(onClick={try{applyPendingSchedule();val gate=PermissionGate.status(ctx);require(gate.allReady){"Для запуска все пять индикаторов должны быть зелёными:\n${gate.problems().joinToString("\n")}"};val count=ScheduledTestStore.scheduleAll(ctx);stateKnown=true;ctx.getSharedPreferences("ts_ui",0).edit().putBoolean("state_known",true).apply();refresh();Toast.makeText(ctx,"Запущено заданий: $count",Toast.LENGTH_LONG).show()}catch(e:Exception){Toast.makeText(ctx,e.message?:"Не удалось запустить",Toast.LENGTH_LONG).show()}},modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=if(active)Color(0xFF238447) else Color.Gray)){Text("Сохранить и запустить",modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.Center)}
    Button(onClick={ScheduledTestStore.cancel(ctx);pendingScheduleSave=false;chats=ChatScheduleStore.all(ctx);pendingEnabled=chats.filter{it.enabled}.map{it.id}.toSet();stateKnown=true;ctx.getSharedPreferences("ts_ui",0).edit().putBoolean("state_known",true).apply();refresh()},modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=if(!active && stateKnown)Color(0xFFC62828) else Color.Gray)){Text("Отменить и остановить",modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.Center)}
   }}}
   // Right-edge drawer grip: broad rounded tab with a tapered neck connected to the drawer edge.
   // The grip remains visible while the drawer is closed; horizontal pull opens the settings panel.
   if(!drawer){
    Surface(
     modifier=Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(top=19.dp)
      .width(136.dp).height(46.dp)
      .shadow(4.dp,DrawerGripShape).clip(DrawerGripShape)
      .pointerInput(Unit){var dx=0f;detectHorizontalDragGestures(onHorizontalDrag={_,d->dx+=d},onDragEnd={if(dx < -24f)drawer=true;dx=0f})},
     color=MaterialTheme.colorScheme.surfaceVariant,
     contentColor=Color.White
    ){
     Box(Modifier.fillMaxSize(),contentAlignment=Alignment.CenterStart){
      Column(Modifier.padding(start=21.dp),verticalArrangement=Arrangement.spacedBy(4.dp),horizontalAlignment=Alignment.CenterHorizontally){
       repeat(3){ Box(Modifier.width(23.dp).height(3.dp).background(Color.White,RoundedCornerShape(2.dp))) }
      }
     }
    }
   }
   if(drawer){
    // Transparent full-screen hit target behind the panel: tapping the work area closes the drawer.
    Box(Modifier.fillMaxSize().pointerInput(Unit){
     detectTapGestures(onTap={offset->if(offset.x < size.width - 290.dp.toPx()) drawer=false})
    })
   }
   AnimatedVisibility(drawer,modifier=Modifier.align(Alignment.CenterEnd),enter=androidx.compose.animation.slideInHorizontally(tween(320)){it},exit=androidx.compose.animation.slideOutHorizontally(tween(280)){it}){
    Surface(Modifier.fillMaxHeight().width(290.dp).pointerInput(Unit){var dx=0f;detectHorizontalDragGestures(onHorizontalDrag={_,d->dx+=d},onDragEnd={if(dx > 18f)drawer=false;dx=0f})},shadowElevation=16.dp,color=MaterialTheme.colorScheme.surface){Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
     Row(verticalAlignment=Alignment.CenterVertically){Text("Настройки",style=MaterialTheme.typography.titleLarge,modifier=Modifier.weight(1f));IconButton(onClick={drawer=false}){Icon(Icons.Default.Close,"Закрыть", tint=MaterialTheme.colorScheme.error)}}
     Text("Тема",style=MaterialTheme.typography.titleMedium)
     Button(onClick={theme="system";prefs.edit().putString("theme",theme).apply()},modifier=Modifier.fillMaxWidth()){Text("Как в телефоне",modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.Center)}
     Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
      Button(onClick={theme="dark";prefs.edit().putString("theme",theme).apply()},modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF343038),contentColor=Color(0xFFEAE6ED))){Text("Тёмная",modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.Center)}
      Button(onClick={theme="light";prefs.edit().putString("theme",theme).apply()},modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=Color.White,contentColor=Color(0xFF222222))){Text("Светлая",modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.Center)}
     }
     Text("Шрифт и масштаб: ${scale.toInt()}%",style=MaterialTheme.typography.titleMedium);Slider(value=scale.coerceIn(-10f,10f),onValueChange={scale=it.coerceIn(-10f,10f).toInt().toFloat();prefs.edit().putInt("scale",scale.toInt()).apply()},valueRange=-10f..10f,steps=19);Text("От −10% до +10%. Другие значения отключены.",style=MaterialTheme.typography.bodySmall)
     OutlinedButton(onClick={scale=0f;prefs.edit().putInt("scale",0).apply()},modifier=Modifier.align(Alignment.CenterHorizontally)){Text("Сбросить масштаб",modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.Center)}
     Button(onClick={instruction=true;drawer=false},modifier=Modifier.fillMaxWidth()){Text("Инструкция",modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.Center)}
     Button(onClick={showPasswordDialog=true},modifier=Modifier.fillMaxWidth()){Text("Пароль владельца",modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.Center)};if(ownerPassword.isNotBlank())TextButton(onClick={ownerPassword="";prefs.edit().remove("owner_password").apply()},modifier=Modifier.fillMaxWidth()){Text("Сбросить пароль",modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.Center)}
     Spacer(Modifier.weight(1f));OutlinedButton(onClick={
      val openJournal = HiddenJournalGate.registerResetTap(ctx)
      ScheduledTestStore.cancel(ctx)
      ctx.getSharedPreferences("ts_ui",0).edit().clear().apply()
      ctx.getSharedPreferences("ts_work_model",0).edit().clear().apply()
      chats=emptyList();active=false;stateKnown=false;theme="system";scale=0f;ownerPassword="";ownerGate=false;drawer=!openJournal
      DiagnosticStore.add(ctx, "FACTORY_RESET_EXECUTED | hiddenJournalGateTap=${if(openJournal) 10 else "recorded"}")
      Toast.makeText(ctx,"Настройки приложения сброшены. Разрешения Android сохранены.",Toast.LENGTH_LONG).show()
      if(openJournal){ diagnosticRefresh++; showDiagnosticJournal=true }
     },modifier=Modifier.fillMaxWidth()){Text("Сбросить приложение до заводских настроек",modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.Center)}
    }}
   }
   if(showDiagnosticJournal) {
    val diagnosticLines = remember(diagnosticRefresh) { DiagnosticStore.read(ctx) }
    Dialog(onDismissRequest={showDiagnosticJournal=false},properties=DialogProperties(usePlatformDefaultWidth=false)) {
     Surface(Modifier.fillMaxWidth(.94f).fillMaxHeight(.86f).statusBarsPadding().padding(top=10.dp),shape=RoundedCornerShape(18.dp),color=MaterialTheme.colorScheme.surface) {
      Column(Modifier.fillMaxSize().padding(14.dp)) {
       Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
        Text("Скрытый журнал диагностики",style=MaterialTheme.typography.titleMedium,modifier=Modifier.weight(1f))
        IconButton(onClick={showDiagnosticJournal=false}){Icon(Icons.Default.Close,"Закрыть",tint=MaterialTheme.colorScheme.error)}
       }
       OutlinedButton(onClick={
        val text = DiagnosticStore.readAllChronological(ctx).joinToString("\n")
        val clipboard = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("TS Моя работа — полный журнал", text))
        Toast.makeText(ctx,"Весь журнал скопирован",Toast.LENGTH_SHORT).show()
       },modifier=Modifier.fillMaxWidth().padding(top=8.dp)) { Text("Скопировать весь лог") }
       Spacer(Modifier.height(8.dp))
       Text("Записи за последние 7 дней · ${diagnosticLines.size}",style=MaterialTheme.typography.labelSmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
       Spacer(Modifier.height(6.dp))
       if(diagnosticLines.isEmpty()) Text("Записей пока нет",style=MaterialTheme.typography.bodyMedium)
       else LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(5.dp)) {
        items(diagnosticLines){ line -> Text(line,style=MaterialTheme.typography.bodySmall,modifier=Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant,RoundedCornerShape(6.dp)).padding(7.dp)) }
       }
      }
     }
    }
   }
   if(showAddChat) AlertDialog(onDismissRequest={showAddChat=false},title={Text("Новый чат")},text={Column{OutlinedTextField(newLabel,{newLabel=capitalizeLabel(it)},label={Text("Точное имя ярлыка на рабочем столе")},keyboardOptions=KeyboardOptions(capitalization=KeyboardCapitalization.Sentences,autoCorrectEnabled=true));Spacer(Modifier.height(8.dp));Text("Обнаруженные экземпляры WhatsApp");Row{if("main" in availableProfiles)FilterChip(newProfile=="main",{newProfile="main"},label={Text("Основной")});if("clone" in availableProfiles)FilterChip(newProfile=="clone",{newProfile="clone"},label={Text("Клон")})}}},confirmButton={TextButton(onClick={if(newLabel.isNotBlank()){val ch=WorkChat(launcherLabel=newLabel.trim(),profile=newProfile,behavior="");persist(chats+ch);expandedChat=ch.id;newLabel="";showAddChat=false}}){Text("Добавить")}},dismissButton={TextButton(onClick={showAddChat=false}){Text("Отмена")}})
   if(showTimeFor.isNotBlank()){
    val hp=pickerHour.coerceIn(0,23)
    val mp=pickerMinute.coerceIn(0,59)
    AlertDialog(
     onDismissRequest={showTimeFor=""},
     title={Text("Время запуска",modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.Center)},
     text={Box(Modifier.fillMaxWidth().height(142.dp),contentAlignment=Alignment.Center){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.Center,verticalAlignment=Alignment.CenterVertically){
      androidx.compose.ui.viewinterop.AndroidView(factory={android.widget.NumberPicker(it).apply{minValue=0;maxValue=23;value=hp;setFormatter{v->"%02d".format(v)};wrapSelectorWheel=true;styleTimePicker(this,dark);setOnValueChangedListener{_,_,v->pickerHour=v;draftTime="%02d:%02d".format(pickerHour,pickerMinute)}}},update={if(it.value!=hp)it.value=hp;styleTimePicker(it,dark)},modifier=Modifier.width(92.dp).height(126.dp))
      Text(":",style=MaterialTheme.typography.headlineMedium,color=MaterialTheme.colorScheme.onSurface)
      androidx.compose.ui.viewinterop.AndroidView(factory={android.widget.NumberPicker(it).apply{minValue=0;maxValue=59;value=mp;setFormatter{v->"%02d".format(v)};wrapSelectorWheel=true;styleTimePicker(this,dark);setOnValueChangedListener{_,_,v->pickerMinute=v;draftTime="%02d:%02d".format(pickerHour,pickerMinute)}}},update={if(it.value!=mp)it.value=mp;styleTimePicker(it,dark)},modifier=Modifier.width(92.dp).height(126.dp))
     } }},
     confirmButton={Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.Center){TextButton(onClick={showTimeFor=""}){Text("Отмена")};TextButton(onClick={val chosen="%02d:%02d".format(pickerHour.coerceIn(0,23),pickerMinute.coerceIn(0,59));draftTime=chosen;if(chosen.matches(Regex("([01]\\d|2[0-3]):[0-5]\\d"))){if(showTimeFor.startsWith("edit:")){val parts=showTimeFor.split(":");val cid=parts[1];val iid=parts[2];persist(chats.map{c->if(c.id==cid)c.copy(intervals=c.intervals.map{if(it.id==iid)it.copy(time=chosen)else it})else c});showTimeFor=""}else{val cid=showTimeFor;val ch=chats.firstOrNull{it.id==cid};if(ch?.behavior=="READ"){persist(chats.map{if(it.id==cid)it.copy(intervals=it.intervals+WorkInterval(time=chosen,message=""))else it});expandedChat=cid;showTimeFor=""}else{showMessageFor=cid;showTimeFor=""}}}}){Text("Готово")}}},
     dismissButton={}
    )
   }
   if(showMessageFor.isNotBlank()) AlertDialog(onDismissRequest={showMessageFor=""},title={Text("Сообщение")},text={OutlinedTextField(draftMessage,{draftMessage=it.take(3000)},modifier=Modifier.fillMaxWidth(),minLines=4,label={Text("До 3000 символов")},keyboardOptions=KeyboardOptions(capitalization=KeyboardCapitalization.Sentences,autoCorrectEnabled=true))},confirmButton={TextButton(onClick={if(draftMessage.isNotBlank()){if(showMessageFor.startsWith("edit:")){val parts=showMessageFor.split(":");val cid=parts[1];val iid=parts[2];persist(chats.map{c->if(c.id==cid)c.copy(intervals=c.intervals.map{if(it.id==iid)it.copy(message=draftMessage)else it})else c});expandedChat=cid}else{val ch=chats.first{it.id==showMessageFor};persist(chats.map{if(it.id==ch.id)it.copy(intervals=it.intervals+WorkInterval(time=draftTime,message=draftMessage))else it});expandedChat=ch.id};showMessageFor="";draftMessage=""}}){Text("Сохранить")}},dismissButton={TextButton(onClick={showMessageFor=""}){Text("Отмена")}})
   if(showAccessOptions) AlertDialog(
    onDismissRequest={showAccessOptions=false},
    title={Text("Настройка доступа")},
    text={Text("Сначала можно открыть системный раздел специальных возможностей. Если служба TS Моя работа там не включается или пункт недоступен, открой карточку приложения и проверь специальные разрешения.")},
    confirmButton={TextButton(onClick={showAccessOptions=false;runCatching{ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))}.onFailure{Toast.makeText(ctx,"Не удалось открыть настройки специальных возможностей",Toast.LENGTH_LONG).show()}}){Text("Специальные возможности")}},
    dismissButton={TextButton(onClick={showAccessOptions=false;runCatching{ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:${ctx.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))}.onFailure{Toast.makeText(ctx,"Не удалось открыть карточку приложения",Toast.LENGTH_LONG).show()}}){Text("Доступ из приложений")}}
   )
   if(permissionWarning.isNotBlank()) AlertDialog(onDismissRequest={},title={Text("Автоматическая работа остановлена")},text={Text("Не выполнено обязательное условие:\n$permissionWarning\n\nИсправьте настройки и проверьте, чтобы все пять индикаторов стали зелёными. Затем запустите расписание вручную.")},confirmButton={TextButton(onClick={PermissionGate.dismissBlockedNotification(ctx);permissionWarning=""}){Text("Понял")}})
   if(showPasswordDialog) AlertDialog(onDismissRequest={showPasswordDialog=false;passDraft=""},title={Text("Пароль владельца")},text={OutlinedTextField(passDraft,{passDraft=capitalizeLabel(it)},visualTransformation=PasswordVisualTransformation(),label={Text("Новый пароль")},keyboardOptions=KeyboardOptions(capitalization=KeyboardCapitalization.Sentences,keyboardType=KeyboardType.Password))},confirmButton={TextButton(onClick={if(passDraft.isNotBlank()){ownerPassword=passDraft;prefs.edit().putString("owner_password",ownerPassword).apply();passDraft="";showPasswordDialog=false}}){Text("Сохранить")}},dismissButton={TextButton(onClick={showPasswordDialog=false}){Text("Отмена")}})
   if(instruction) GuideDialog(section,{section=it;prefs.edit().putString("guide_section",it).apply()},guideScroll,{guideScroll=it;prefs.edit().putInt("guide_scroll",it).apply()},{instruction=false})
   if(ownerGate && ownerPassword.isNotBlank()) { var entered by remember{mutableStateOf("")}; AlertDialog(onDismissRequest={},title={Text("Введите пароль")},text={OutlinedTextField(entered,{entered=capitalizeLabel(it)},visualTransformation=PasswordVisualTransformation(),keyboardOptions=KeyboardOptions(capitalization=KeyboardCapitalization.Sentences,keyboardType=KeyboardType.Password))},confirmButton={TextButton(onClick={if(entered==ownerPassword)ownerGate=false}){Text("Войти")}}) }
  }
 }}
}
}

private fun capitalizeLabel(value:String):String {
    val clean = value.take(100)
    val first = clean.indexOfFirst { it.isLetter() }
    return if (first < 0) clean else clean.replaceRange(first, first + 1, clean[first].uppercase(java.util.Locale.getDefault()))
}

private fun styleTimePicker(picker:android.widget.NumberPicker,dark:Boolean){
    val selected=if(dark)android.graphics.Color.rgb(214,210,217) else android.graphics.Color.rgb(25,25,25)
    val adjacent=if(dark)android.graphics.Color.rgb(105,101,110) else android.graphics.Color.rgb(105,105,105)
    val divider=if(dark)android.graphics.Color.rgb(205,201,211) else android.graphics.Color.rgb(55,55,55)
    for(i in 0 until picker.childCount){(picker.getChildAt(i) as? android.widget.EditText)?.apply{setTextColor(selected);setHintTextColor(adjacent)}}
    runCatching { val f=android.widget.NumberPicker::class.java.getDeclaredField("mSelectionDivider");f.isAccessible=true;f.set(picker,android.graphics.drawable.ColorDrawable(divider)) }
    runCatching { val f=android.widget.NumberPicker::class.java.getDeclaredField("mSelectorWheelPaint");f.isAccessible=true;(f.get(picker) as? android.graphics.Paint)?.color=adjacent }
    picker.invalidate()
}

@Composable private fun PermissionPill(label:String,ok:Boolean,modifier:Modifier=Modifier,onClick:()->Unit){
 val bg=if(ok)Color(0xFF238447) else Color(0xFFC62828)
 Surface(onClick=onClick,color=bg,shape=RoundedCornerShape(13.dp),modifier=modifier.height(36.dp)){
  Row(Modifier.fillMaxSize().padding(horizontal=2.dp),horizontalArrangement=Arrangement.Center,verticalAlignment=Alignment.CenterVertically){
   Text("●",color=Color.White,style=MaterialTheme.typography.labelSmall)
   Spacer(Modifier.width(2.dp))
   Text(label,color=Color.White,style=MaterialTheme.typography.labelSmall,maxLines=1,softWrap=false)
  }
 }
}
private fun detectWhatsAppProfiles(c:Context):Set<String> = try {
 val launcher=c.getSystemService(Context.LAUNCHER_APPS_SERVICE) as android.content.pm.LauncherApps
 val userManager=c.getSystemService(Context.USER_SERVICE) as UserManager
 launcher.profiles.mapNotNull { user ->
  runCatching { launcher.getActivityList("com.whatsapp",user) }.getOrNull()?.takeIf{it.isNotEmpty()}?.let {
   val serial=runCatching { userManager.getSerialNumberForUser(user) }.getOrDefault(-1L)
   when(serial) { 0L -> "main"; in 1L..Long.MAX_VALUE -> "clone"; else -> null }
  }
 }.toSet()
} catch (_:Exception) {
 if(runCatching{c.packageManager.getPackageInfo("com.whatsapp",0)}.isSuccess) setOf("main") else emptySet()
}
private fun accessibilityEnabled(c:Context)=try{val m=c.getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager;m.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK).any{it.resolveInfo.serviceInfo.packageName==c.packageName}}catch(_:Exception){false}
private fun batteryExempt(c:Context)= (c.getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(c.packageName)
private fun exactAllowed(c:Context)=Build.VERSION.SDK_INT<31 || (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).canScheduleExactAlarms()
private fun launchShortcutCheck(c:Context,chatId:String,profile:String,label:String){ChatScheduleStore.setPending(c,chatId); ShortcutCaptureStore.begin(c,chatId); val ok=WhatsAppAccessibilityService.requestHomeNavigation(); if(!ok){ShortcutCaptureStore.cancel(c);Toast.makeText(c,"Включи Специальные возможности для TS Моя работа, затем повтори привязку.",Toast.LENGTH_LONG).show()}else Toast.makeText(c,"Рабочий стол открыт. Вручную нажми ярлык «$label» профиля $profile. После открытия чата вернись сюда и нажми «Верно».",Toast.LENGTH_LONG).show()}

@Composable private fun GuideDialog(section:String,onSection:(String)->Unit,scroll:Int,onScroll:(Int)->Unit,onClose:()->Unit){val items=listOf("Назначение","Общие настройки","WhatsApp","Чаты и ярлыки","Разрешения","Samsung","Xiaomi / Redmi / POCO","Huawei / Honor","OPPO / Realme","Vivo","OnePlus","Motorola","Google Pixel","Другие Android");Dialog(onDismissRequest={},properties=DialogProperties(usePlatformDefaultWidth=false)){Surface(Modifier.fillMaxWidth(.96f).fillMaxHeight(.92f),shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(12.dp)){Row(verticalAlignment=Alignment.CenterVertically){Text("Инструкция",style=MaterialTheme.typography.titleLarge,modifier=Modifier.weight(1f));IconButton(onClick=onClose){Icon(Icons.Default.Close,"Закрыть", tint=Color.Red)}};Row(Modifier.weight(1f)){Column(Modifier.width(130.dp).verticalScroll(rememberScrollState())){items.forEach{TextButton(onClick={onSection(it)},modifier=Modifier.fillMaxWidth()){Text(it,style=MaterialTheme.typography.labelSmall)}}};Divider(Modifier.fillMaxHeight().width(1.dp));val state= rememberScrollState(scroll);LaunchedEffect(state.value){onScroll(state.value)};Column(Modifier.weight(1f).verticalScroll(state).padding(10.dp)){Text(section,style=MaterialTheme.typography.titleMedium);Spacer(Modifier.height(8.dp));Text(guideText(section) + if(section in setOf("Samsung","Xiaomi / Redmi / POCO","Huawei / Honor","OPPO / Realme","Vivo","OnePlus","Motorola","Google Pixel","Другие Android")) "\n\nЕсли кнопка Accessibility в TS Моя работа серая или не включается: откройте системные Настройки → Приложения → TS Моя работа и найдите специальные возможности/разрешения службы доступности. Разрешите службу там вручную, затем вернитесь в приложение и повторно нажмите «Доступ». Если раздел не виден, найдите «Специальные возможности» или «Accessibility» через поиск настроек. Это возможный дополнительный путь на разных марках телефонов." else "",style=MaterialTheme.typography.bodyMedium)}}}}}}
private fun guideText(s:String)=when(s){"Назначение"->"TS Моя работа запускает подтверждённый ярлык переписки по локальному расписанию. Для каждого чата отдельно выбирается режим: Чтение, Отправка или Проверка. Чтение не вводит текст; Проверка вставляет и очищает текст без отправки; Отправка использует прежнюю проверенную последовательность.";"Общие настройки"->"Тема: системная, светлая или тёмная. Масштаб регулируется от −10% до +10%; другие значения отключены. Сброс удаляет только настройки TS Моя работа и её будильники. Разрешения Android не отзываются.";"WhatsApp"->"Выберите основной WhatsApp или клон Dual Messenger. Для каждого чата ярлык подтверждается отдельно. Профиль WhatsApp нельзя надёжно установить только по Accessibility-событиям: проверяйте визуально, что ярлык ведёт в нужный аккаунт.";"Чаты и ярлыки"->"Галочкой включите чаты, которые должны участвовать в расписании; нажмите «Сохранить и применить», чтобы применить выбор и остановить текущее расписание. Для каждого чата подтвердите точное название ярлыка, затем выберите режим: Чтение (3 секунды, без ввода), Отправка (прежняя отправка) или Проверка (ввод и очистка без отправки). Кнопка «Ред.» меняет режим. Для каждого включённого чата нужно добавить хотя бы одно время. Для Отправки и Проверки требуется текст.";"Разрешения"->"Accessibility: Настройки → Специальные возможности → Установленные приложения → TS Моя работа → Включить. Батарея: Настройки → Приложения → TS Моя работа → Батарея → Без ограничений. Точные будильники: Настройки → Приложения → Специальный доступ → Будильники и напоминания. Уведомления: Настройки → Приложения → TS Моя работа → Уведомления.";"Samsung"->"Настройки → Приложения → TS Моя работа → Батарея → Без ограничений. Настройки → Обслуживание устройства → Батарея → Ограничения фонового использования: не добавлять приложение в спящие. Специальные возможности → Установленные приложения → TS Моя работа.";"Xiaomi / Redmi / POCO"->"Настройки → Приложения → Управление приложениями → TS Моя работа → Экономия энергии → Нет ограничений. Автозапуск: Настройки → Приложения → Разрешения → Автозапуск (путь зависит от MIUI/HyperOS). В информации приложения разрешить всплывающие окна/фоновые запуски, если доступны.";"Huawei / Honor"->"Настройки → Приложения → Запуск приложений → TS Моя работа → вручную; включить автозапуск, вторичный запуск и работу в фоне. Батарея → Оптимизация запуска/Оптимизация батареи: разрешить работу без ограничений, если пункт есть.";"OPPO / Realme"->"Настройки → Батарея → Управление расходом батареи приложениями → TS Моя работа → разрешить фоновую активность. В настройках приложений включить автозапуск и запуск из других приложений, если доступны.";"Vivo"->"Настройки → Батарея → Высокое фоновое энергопотребление → TS Моя работа разрешить. В iManager разрешить автозапуск и фоновую работу.";"OnePlus"->"Настройки → Батарея → Оптимизация батареи → TS Моя работа → Не оптимизировать. Проверьте управление автозапуском и фоновую активность.";"Motorola"->"Настройки → Приложения → TS Моя работа → Батарея → Без ограничений; Специальные возможности → TS Моя работа → Включить.";"Google Pixel"->"Настройки → Приложения → TS Моя работа → Батарея приложения → Без ограничений. Специальные возможности → TS Моя работа.";else->"Названия пунктов различаются в зависимости от версии Android и оболочки производителя. Откройте карточку приложения TS Моя работа в системных настройках и проверьте батарею, автозапуск, фоновые действия, уведомления, точные будильники и Accessibility. Производитель может ограничивать запуск экранов из фона."}
