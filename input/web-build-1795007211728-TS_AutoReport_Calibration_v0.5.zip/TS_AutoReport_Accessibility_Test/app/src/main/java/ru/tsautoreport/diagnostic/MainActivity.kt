package ru.tsautoreport.diagnostic

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.LauncherApps
import android.os.Bundle
import android.os.UserHandle
import android.provider.Settings
import android.widget.Toast
import android.view.accessibility.AccessibilityManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private data class WhatsAppProfile(val user: UserHandle, val component: ComponentName) {
    val handleText: String get() = user.toString()
}

class MainActivity : ComponentActivity() {
    private val launcherApps by lazy { getSystemService(Context.LAUNCHER_APPS_SERVICE) as LauncherApps }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { Screen() }
    }

    @Composable private fun Screen() {
        var enabled by remember { mutableStateOf(isServiceEnabled()) }
        var logs by remember { mutableStateOf(DiagnosticStore.read(this@MainActivity)) }
        var profiles by remember { mutableStateOf<List<WhatsAppProfile>>(emptyList()) }
        var scanMessage by remember { mutableStateOf("Нажми «Найти экземпляры WhatsApp».") }
        var calibration by remember { mutableStateOf(CalibrationStore.current(this@MainActivity)) }

        fun refreshLogs() {
            enabled = isServiceEnabled()
            logs = DiagnosticStore.read(this@MainActivity)
            calibration = CalibrationStore.current(this@MainActivity)
        }

        fun scanProfiles() {
            try {
                val found = launcherApps.profiles.flatMap { user ->
                    launcherApps.getActivityList("com.whatsapp", user).map { info ->
                        WhatsAppProfile(user, info.componentName)
                    }
                }.distinctBy { it.user.toString() + "|" + it.component.flattenToString() }
                profiles = found
                scanMessage = if (found.isEmpty()) {
                    "WhatsApp не найден в доступных профилях. Проверь установку и доступность приложения."
                } else {
                    "Найдено точек запуска: ${found.size}. Профили отображаются отдельно; проверь, какой запуск открывает основной WhatsApp, а какой — клон."
                }
            } catch (e: Exception) {
                profiles = emptyList()
                scanMessage = "Ошибка поиска профилей: ${e.javaClass.simpleName}: ${e.message ?: "без подробностей"}"
            }
        }

        fun launchForCalibration(profile: WhatsAppProfile, label: String) {
            try {
                CalibrationStore.start(this@MainActivity, label, profile.handleText)
                calibration = CalibrationStore.current(this@MainActivity)
                launcherApps.startMainActivity(profile.component, profile.user, null, Bundle())
                Toast.makeText(this@MainActivity, "Запуск: $label (${profile.handleText})", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                CalibrationStore.stop(this@MainActivity)
                calibration = null
                Toast.makeText(this@MainActivity, "Не удалось запустить: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }

        MaterialTheme {
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("TS AutoReport", style = MaterialTheme.typography.headlineLarge)
                Text("Версия 0.5 — калибровка экземпляров", style = MaterialTheme.typography.titleMedium)
                Text("Проверяем, можно ли связать контролируемый запуск конкретного Android-профиля с событиями Accessibility.")
                Text("Конфиденциальность: журнал содержит только технические метаданные окон и выбранную тобой метку калибровки. Текст переписки, имена контактов и содержимое полей не читаются.")

                Text(
                    if (enabled) "Служба Accessibility включена" else "Служба Accessibility выключена",
                    color = if (enabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                )
                Button(onClick = { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }) {
                    Text("Открыть специальные возможности")
                }
                Button(onClick = { refreshLogs() }) { Text("Обновить статус и журнал") }
                HorizontalDivider()

                Text("1. Найти экземпляры", style = MaterialTheme.typography.titleLarge)
                Button(onClick = { scanProfiles() }) { Text("Найти экземпляры WhatsApp") }
                Text(scanMessage, style = MaterialTheme.typography.bodySmall)
                if (profiles.isNotEmpty()) {
                    profiles.forEachIndexed { index, profile ->
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("Точка запуска ${index + 1}", style = MaterialTheme.typography.titleMedium)
                                Text("Профиль: ${profile.handleText}")
                                Text("Компонент: ${profile.component.className}", style = MaterialTheme.typography.bodySmall)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(onClick = { launchForCalibration(profile, "Основной WhatsApp") }) {
                                        Text("Калибровать как основной")
                                    }
                                }
                                OutlinedButton(onClick = { launchForCalibration(profile, "Клон WhatsApp") }) {
                                    Text("Калибровать как клон")
                                }
                            }
                        }
                    }
                    Text("Важно: назначай метки по фактическому результату запуска. Если не уверен, не выбирай метку.", style = MaterialTheme.typography.bodySmall)
                }

                HorizontalDivider()
                Text("2. Текущая калибровка", style = MaterialTheme.typography.titleLarge)
                if (calibration == null) {
                    Text("Калибровка не активна.")
                } else {
                    Text("Выбранная метка: ${calibration!!.label}")
                    Text("Профиль запуска: ${calibration!!.profile}")
                    Text("Начало: ${SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(calibration!!.startedAt))}")
                    Text("Эта метка означает только, что ты выбрал данный профиль для тестового запуска. Она НЕ доказывает, что каждое событие пришло именно из этого профиля.", color = MaterialTheme.colorScheme.error)
                    Button(onClick = {
                        CalibrationStore.stop(this@MainActivity)
                        calibration = null
                        Toast.makeText(this@MainActivity, "Калибровка остановлена", Toast.LENGTH_SHORT).show()
                    }) { Text("Завершить калибровку") }
                }
                Text("Порядок: выбери нужную точку запуска, дождись открытия WhatsApp, открой один и тот же тестовый чат, затем вернись сюда и нажми «Завершить калибровку». Повтори отдельно для второго экземпляра. Сообщения не отправляй.", style = MaterialTheme.typography.bodySmall)

                HorizontalDivider()
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Журнал событий", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                    TextButton(onClick = { copyEntireLog() }) { Text("Копировать лог") }
                    TextButton(onClick = { DiagnosticStore.clear(this@MainActivity); logs = emptyList() }) { Text("Очистить") }
                }
                Text("Сохранено событий: ${logs.size}. Копируется весь сохранённый журнал, от старых записей к новым.", style = MaterialTheme.typography.bodySmall)
                if (logs.isEmpty()) Text("Пока событий нет.")
                logs.forEach { line -> Text(line, style = MaterialTheme.typography.bodySmall) }
                Text("Ограничение: Android AccessibilityEvent не предоставляет приложению надёжный публичный UserHandle источника события. Калибровочная метка — контекст контролируемого теста, а не подтверждённая идентичность источника. Автоматическую отправку по этой метке включать нельзя.", style = MaterialTheme.typography.bodySmall)
            }
        }
    }

    private fun copyEntireLog() {
        val allEvents = DiagnosticStore.readAllChronological(this)
        val target = CalibrationStore.current(this)
        val header = buildString {
            appendLine("TS AutoReport — журнал диагностики")
            appendLine("Версия приложения: 0.5-calibration")
            appendLine("Устройство: ${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}")
            appendLine("Android: ${android.os.Build.VERSION.RELEASE} (API ${android.os.Build.VERSION.SDK_INT})")
            appendLine("Калибровка: ${target?.label ?: "не активна"}")
            appendLine("Профиль калибровки: ${target?.profile ?: "нет"}")
            appendLine("Событий: ${allEvents.size}")
            appendLine("Порядок: от старых к новым")
            appendLine("----------------------------------------")
        }
        val fullLog = header + if (allEvents.isEmpty()) "Журнал пуст." else allEvents.joinToString("\n")
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("TS AutoReport log", fullLog))
        Toast.makeText(this, "Скопировано событий: ${allEvents.size}", Toast.LENGTH_LONG).show()
    }

    private fun isServiceEnabled(): Boolean {
        val manager = getSystemService(ACCESSIBILITY_SERVICE) as AccessibilityManager
        val expected = ComponentName(this, WhatsAppAccessibilityService::class.java)
        return manager.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            .any { it.resolveInfo.serviceInfo.let { info -> ComponentName(info.packageName, info.name) == expected } }
    }
}
