package ru.tsautoreport.diagnostic

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object ScheduledTestStore {
    private const val PREFS = "scheduled_draft_test"
    private const val REQUEST_BASE = 19019
    const val ACTION_RUN = "ru.tsautoreport.diagnostic.RUN_DRAFT_TEST"
    const val EXTRA_SLOT = "slot_index"
    const val EXTRA_MESSAGE = "draft_message"

    data class Entry(val time: String, val message: String)

    fun scheduleEntries(context: Context, entries: List<Entry>): List<Long> {
        require(entries.isNotEmpty() && entries.size <= 3) { "Добавь от 1 до 3 времён" }
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        if (Build.VERSION.SDK_INT >= 31 && !alarm.canScheduleExactAlarms()) throw SecurityException("Нет разрешения на точные будильники")
        cancelAlarms(context)
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val times = mutableListOf<Long>()
        entries.forEachIndexed { index, entry ->
            val parts = entry.time.trim().split(":")
            require(parts.size == 2)
            val hour = parts[0].toInt(); val minute = parts[1].toInt()
            require(hour in 0..23 && minute in 0..59)
            require(entry.message.isNotBlank() && entry.message.length <= 3000) { "Сообщение №${index + 1}: от 1 до 3000 символов" }
            val now = Calendar.getInstance()
            val target = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                if (timeInMillis <= now.timeInMillis) add(Calendar.DAY_OF_YEAR, 1)
            }
            val intent = Intent(context, ScheduledTestReceiver::class.java).setAction(ACTION_RUN)
                .putExtra(EXTRA_SLOT, index).putExtra(EXTRA_MESSAGE, entry.message)
            val pi = PendingIntent.getBroadcast(context, REQUEST_BASE + index, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, target.timeInMillis, pi)
            prefs.edit().putLong("slot_${index}_at", target.timeInMillis).putString("slot_${index}_time", entry.time).putString("slot_${index}_message", entry.message).commit()
            times.add(target.timeInMillis)
            DiagnosticStore.add(context, "${stamp()} | DRAFT_TEST_SCHEDULED | slot=${index + 1} | at=${SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(target.time)} | exact=true | cloneOnly=true | textLength=${entry.message.length} | send=false")
        }
        prefs.edit().putBoolean("active", true).putInt("slot_count", entries.size).putLong("scheduled_at", times.minOrNull() ?: 0L).commit()
        ScheduleKeepAliveService.start(context, ScheduleKeepAliveService.ACTION_MONITOR)
        return times
    }

    /** Legacy one-slot API retained for compatibility with older project code. */
    fun schedule(context: Context, hhmm: String): Long = scheduleEntries(context, listOf(Entry(hhmm, "проверка"))).first()

    fun cancel(context: Context) {
        cancelAlarms(context)
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("active", false).putInt("slot_count", 0).commit()
        DiagnosticStore.add(context, "${stamp()} | DRAFT_TEST_CANCELLED | user_action=true")
        ScheduleKeepAliveService.start(context, ScheduleKeepAliveService.ACTION_STOP)
    }

    private fun cancelAlarms(context: Context) {
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        repeat(3) { index ->
            val intent = Intent(context, ScheduledTestReceiver::class.java).setAction(ACTION_RUN)
            val pi = PendingIntent.getBroadcast(context, REQUEST_BASE + index, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            alarm.cancel(pi); pi.cancel()
        }
    }

    fun savedEntries(context: Context): List<Entry> {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val count = p.getInt("slot_count", 0).coerceIn(0, 3)
        return (0 until count).mapNotNull { i ->
            val time = p.getString("slot_${i}_time", null) ?: return@mapNotNull null
            val msg = p.getString("slot_${i}_message", null) ?: return@mapNotNull null
            Entry(time, msg)
        }
    }

    fun active(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean("active", false)
    fun scheduledAt(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getLong("scheduled_at", 0L)
    fun markFired(context: Context, index: Int) {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val count = p.getInt("slot_count", 1)
        val remaining = (0 until count).any { it != index && p.getLong("slot_${it}_at", 0L) > System.currentTimeMillis() }
        p.edit().putLong("slot_${index}_at", 0L).putBoolean("active", remaining).commit()
        if (!remaining) ScheduleKeepAliveService.start(context, ScheduleKeepAliveService.ACTION_STOP)
    }
    private fun stamp() = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault()).format(Date())
}

class ScheduledTestReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != ScheduledTestStore.ACTION_RUN) return
        val index = intent.getIntExtra(ScheduledTestStore.EXTRA_SLOT, 0)
        val message = intent.getStringExtra(ScheduledTestStore.EXTRA_MESSAGE).orEmpty()
        DiagnosticStore.add(context, "${SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault()).format(Date())} | DRAFT_TEST_ALARM_RECEIVED | slot=${index + 1} | cloneOnly=true")
        ScheduledTestStore.markFired(context, index)
        val run = Intent(context, ScheduleKeepAliveService::class.java).setAction(ScheduleKeepAliveService.ACTION_RUN)
            .putExtra(ScheduledTestStore.EXTRA_SLOT, index).putExtra(ScheduledTestStore.EXTRA_MESSAGE, message)
        try {
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(run) else context.startService(run)
            DiagnosticStore.add(context, "${SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault()).format(Date())} | DRAFT_TEST_DISPATCHED_TO_FOREGROUND_SERVICE | slot=${index + 1} | cloneOnly=true")
        } catch (e: Exception) {
            DiagnosticStore.add(context, "${SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault()).format(Date())} | DRAFT_TEST_DISPATCH_FAILED | slot=${index + 1} | error=${e.javaClass.simpleName}")
        }
    }
}
