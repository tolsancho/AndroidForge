package ru.tsautoreport.diagnostic

import android.content.Context
import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo

/** Persists a user-trained launcher selector; it stores UI metadata, never WhatsApp private data. */
object ShortcutCaptureStore {
    private const val PREFS = "trained_launcher_shortcuts"
    data class Selector(val chatId:String,val launcher:String,val text:String,val description:String,val viewId:String,val className:String,val bounds:String,val capturedAt:Long,val conversationObserved:Boolean)

    fun begin(context:Context, chatId:String, launcher:String="") {
        context.getSharedPreferences(PREFS,0).edit().putString("pending_chat",chatId).putString("pending_launcher",launcher)
            .remove("pending_text").remove("pending_desc").remove("pending_view_id").remove("pending_class").remove("pending_bounds")
            .putBoolean("pending_conversation",false).putLong("pending_at",System.currentTimeMillis()).commit()
        DiagnosticStore.add(context,"${stamp()} | SHORTCUT_CAPTURE_STARTED | chatId=$chatId | method=manual_launcher_tap")
    }

    fun isCapturing(context:Context)=context.getSharedPreferences(PREFS,0).getString("pending_chat",null)!=null
    fun pendingChat(context:Context)=context.getSharedPreferences(PREFS,0).getString("pending_chat",null)

    fun capture(context:Context, launcher:String, node:AccessibilityNodeInfo):Boolean {
        val p=context.getSharedPreferences(PREFS,0); if(p.getString("pending_chat",null)==null) return false
        val rect=Rect(); runCatching{node.getBoundsInScreen(rect)}
        val text=node.text?.toString().orEmpty().take(120)
        val desc=node.contentDescription?.toString().orEmpty().take(160)
        val viewId=node.viewIdResourceName.orEmpty().take(180)
        val cls=node.className?.toString().orEmpty().take(180)
        val bounds=listOf(rect.left,rect.top,rect.right,rect.bottom).joinToString(",")
        val ok=p.edit().putString("pending_launcher",launcher).putString("pending_text",text).putString("pending_desc",desc)
            .putString("pending_view_id",viewId).putString("pending_class",cls).putString("pending_bounds",bounds)
            .putLong("pending_at",System.currentTimeMillis()).commit()
        DiagnosticStore.add(context,"${stamp()} | SHORTCUT_CAPTURE_NODE | launcher=$launcher | text=$text | desc=$desc | viewId=$viewId | class=$cls | bounds=$bounds | saved=$ok")
        return ok
    }

    fun observeLauncher(context:Context, launcher:String) {
        if (launcher.isBlank()) return
        val p=context.getSharedPreferences(PREFS,0)
        if (p.getString("pending_chat",null)!=null) {
            p.edit().putString("pending_launcher",launcher).commit()
            DiagnosticStore.add(context,"${stamp()} | SHORTCUT_CAPTURE_LAUNCHER_OBSERVED | launcher=$launcher")
        }
    }

    fun markConversation(context:Context, launcher:String, evidence:String) {
        val p=context.getSharedPreferences(PREFS,0)
        if (p.getString("pending_chat",null)==null) return
        val chosenLauncher = p.getString("pending_launcher","").orEmpty().ifBlank { launcher.ifBlank { "launcher_not_reported" } }
        val safeEvidence = evidence.take(180).ifBlank { "WhatsApp_Conversation_window" }
        p.edit().putString("pending_launcher",chosenLauncher)
            .putString("pending_text",p.getString("pending_text","").orEmpty().ifBlank { safeEvidence })
            .putBoolean("pending_conversation",true).putLong("pending_at",System.currentTimeMillis()).commit()
        DiagnosticStore.add(context,"${stamp()} | SHORTCUT_CAPTURE_CONVERSATION_OBSERVED | launcher=$chosenLauncher | evidence=$safeEvidence")
    }

    fun markConversation(context:Context) {
        val p=context.getSharedPreferences(PREFS,0); if(p.getString("pending_chat",null)!=null) p.edit().putBoolean("pending_conversation",true).commit()
    }

    fun canConfirm(context:Context,chatId:String):Boolean {
        val p=context.getSharedPreferences(PREFS,0)
        return p.getString("pending_chat",null)==chatId && p.getString("pending_launcher","").orEmpty().isNotBlank() &&
            (p.getString("pending_text","").orEmpty().isNotBlank() || p.getString("pending_desc","").orEmpty().isNotBlank() || p.getString("pending_view_id","").orEmpty().isNotBlank() || p.getString("pending_bounds","").orEmpty().isNotBlank()) && p.getBoolean("pending_conversation",false)
    }

    fun confirm(context:Context,chatId:String):Boolean {
        if(!canConfirm(context,chatId)) return false
        val p=context.getSharedPreferences(PREFS,0)
        val ok=p.edit().putString("$chatId.launcher",p.getString("pending_launcher","")).putString("$chatId.text",p.getString("pending_text","")).putString("$chatId.desc",p.getString("pending_desc","")).putString("$chatId.viewId",p.getString("pending_view_id","")).putString("$chatId.class",p.getString("pending_class","")).putString("$chatId.bounds",p.getString("pending_bounds","")).putLong("$chatId.capturedAt",p.getLong("pending_at",0L)).remove("pending_chat").remove("pending_launcher").remove("pending_text").remove("pending_desc").remove("pending_view_id").remove("pending_class").remove("pending_bounds").remove("pending_conversation").remove("pending_at").commit()
        DiagnosticStore.add(context,"${stamp()} | SHORTCUT_CAPTURE_CONFIRMED | chatId=$chatId | saved=$ok | user_confirmed=true")
        return ok
    }

    fun selector(context:Context,chatId:String):Selector? {
        val p=context.getSharedPreferences(PREFS,0); val launcher=p.getString("$chatId.launcher",null)?:return null
        return Selector(chatId,launcher,p.getString("$chatId.text","").orEmpty(),p.getString("$chatId.desc","").orEmpty(),p.getString("$chatId.viewId","").orEmpty(),p.getString("$chatId.class","").orEmpty(),p.getString("$chatId.bounds","").orEmpty(),p.getLong("$chatId.capturedAt",0L),true)
    }
    fun cancel(context:Context){context.getSharedPreferences(PREFS,0).edit().remove("pending_chat").remove("pending_launcher").remove("pending_text").remove("pending_desc").remove("pending_view_id").remove("pending_class").remove("pending_bounds").remove("pending_conversation").remove("pending_at").commit()}
    fun delete(context:Context,chatId:String){val e=context.getSharedPreferences(PREFS,0).edit(); listOf("launcher","text","desc","viewId","class","bounds","capturedAt").forEach{e.remove("$chatId.$it")};e.commit()}
    private fun stamp()=java.text.SimpleDateFormat("HH:mm:ss.SSS",java.util.Locale.getDefault()).format(java.util.Date())
}
