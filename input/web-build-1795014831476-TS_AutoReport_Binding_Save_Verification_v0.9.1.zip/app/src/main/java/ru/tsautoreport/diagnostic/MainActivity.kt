package ru.tsautoreport.diagnostic

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.LauncherApps
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import android.view.accessibility.AccessibilityManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    private val launcherApps by lazy { getSystemService(Context.LAUNCHER_APPS_SERVICE) as LauncherApps }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DiagnosticStore.add(this, "${stamp()} | APP_BUILD_ID | id=TS-BIND-091 | version=0.9.1-ts-bind-091 | versionCode=10")
        setContent { Screen() }
    }

    override fun onResume() {
        super.onResume()
    }

    @Composable private fun Screen() {
        var enabled by remember { mutableStateOf(isServiceEnabled()) }
        var logs by remember { mutableStateOf(DiagnosticStore.read(this@MainActivity)) }
        var entries by remember { mutableStateOf<List<ProfileAudit.Entry>>(emptyList()) }
        var status by remember { mutableStateOf("Сначала проведи аудит профилей, затем привяжи тестовый чат.") }
        var auditDone by remember { mutableStateOf(false) }
        var label by remember { mutableStateOf("") }
        var observation by remember { mutableStateOf(ProfileBindingStore.observation(this@MainActivity)) }
        var bindings by remember { mutableStateOf(ProfileBindingStore.bindings(this@MainActivity)) }
        var pending by remember { mutableStateOf(ProfileBindingStore.pending(this@MainActivity)) }
        var editingRow by remember { mutableStateOf<String?>(null) }
        var editingLabel by remember { mutableStateOf("") }

        fun refresh() {
            enabled = isServiceEnabled()
            logs = DiagnosticStore.read(this@MainActivity)
            observation = ProfileBindingStore.observation(this@MainActivity)
            bindings = ProfileBindingStore.bindings(this@MainActivity)
            pending = ProfileBindingStore.pending(this@MainActivity)
        }
        fun audit() {
            try {
                entries = ProfileAudit.discover(this@MainActivity)
                auditDone = true
                val processReport = ProfileAudit.runningProcessReport(this@MainActivity, entries)
                val now = stamp()
                DiagnosticStore.add(this@MainActivity, "$now | PROFILE_API_AUDIT | count=${entries.size} | $processReport")
                entries.forEach { e ->
                    DiagnosticStore.add(this@MainActivity, "$now | PROFILE_ENTRY | user=${e.user} | serial=${e.serial} | uid=${e.uid} | pkg=${e.packageName} | process=${e.processName} | version=${e.versionName}/${e.versionCode} | component=${e.component} | sourceDir=${e.sourceDir}")
                }
                status = if (entries.isEmpty()) "LauncherApps не вернул доступных точек запуска WhatsApp."
                else "Найдено ${entries.size} точек запуска. UID/serial различают записи профилей, но не удостоверяют источник Accessibility-события."
                refresh()
            } catch (e: Exception) {
                auditDone = true
                status = "Ошибка публичного API: ${e.javaClass.simpleName}: ${e.message ?: "без подробностей"}"
                DiagnosticStore.add(this@MainActivity, "${stamp()} | PROFILE_API_AUDIT_ERROR | $status")
                refresh()
            }
        }
        fun startBinding(entry: ProfileAudit.Entry) {
            try {
                val component = ComponentName.unflattenFromString(entry.component)
                    ?: throw IllegalStateException("Некорректный компонент запуска")
                val user = launcherApps.profiles.firstOrNull { it.toString() == entry.user }
                    ?: throw IllegalStateException("Профиль больше не доступен; обнови аудит")
                val startedAt = System.currentTimeMillis()
                ProfileBindingStore.begin(this@MainActivity, ProfileBindingStore.Session(entry.user, entry.serial, entry.uid, entry.component, startedAt))
                launcherApps.startMainActivity(component, user, null, Bundle())
                Toast.makeText(this@MainActivity, "WhatsApp запущен. Открой нужный чат, затем вернись сюда.", Toast.LENGTH_LONG).show()
                refresh()
            } catch (e: Exception) {
                ProfileBindingStore.cancel(this@MainActivity)
                Toast.makeText(this@MainActivity, "Не удалось запустить: ${e.message}", Toast.LENGTH_LONG).show()
                refresh()
            }
        }
        fun confirmBinding() {
            val ok = ProfileBindingStore.confirm(this@MainActivity, label)
            status = if (ok) "Запись сохранена и проверена повторным чтением. Это не доказательство источника профиля." else "Не удалось подтвердить сохранение. Проверь журнал и повтори привязку только после нового запуска."
            if (ok) label = ""
            refresh()
        }

        MaterialTheme {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("TS AutoReport", style = MaterialTheme.typography.headlineLarge)
                Text("Версия 0.9.1 — контроль сборки и сохранения", style = MaterialTheme.typography.titleMedium)
                Text("BUILD ID: TS-BIND-091 · versionCode 10", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                Text("Этап проверяет последовательность: выбранный профиль → запуск его WhatsApp → событие экрана переписки → ручное подтверждение метки чата. Сообщения не отправляются.")
                Text(if (enabled) "Accessibility включена" else "Accessibility выключена", color = if (enabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                Button(onClick = { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }) { Text("Открыть специальные возможности") }
                Button(onClick = { refresh() }) { Text("Обновить статус и журнал") }
                HorizontalDivider()
                Text("1. Найти экземпляры", style = MaterialTheme.typography.titleLarge)
                Button(onClick = { audit() }) { Text("Провести аудит профилей и UID") }
                Text(status, style = MaterialTheme.typography.bodySmall)
                if (auditDone && entries.isEmpty()) Text("Экземпляры не обнаружены.", color = MaterialTheme.colorScheme.error)
                entries.forEachIndexed { index, e ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Text("Экземпляр ${index + 1}", style = MaterialTheme.typography.titleMedium)
                            Text("UserHandle: ${e.user} · Serial: ${e.serial} · UID: ${e.uid}")
                            Text("${e.packageName} · ${e.versionName} · ${e.component}", style = MaterialTheme.typography.bodySmall)
                            Button(onClick = { startBinding(e) }) { Text("Начать привязку чата в этом экземпляре") }
                        }
                    }
                }
                HorizontalDivider()
                Text("2. Подтвердить открытый чат", style = MaterialTheme.typography.titleLarge)
                Text("После нажатия кнопки запуска открой в WhatsApp нужную переписку. Затем вернись в TS AutoReport и нажми «Обновить статус и журнал».")
                val obs = observation
                if (pending != null) {
                    Text("Сессия ожидает подтверждения: ${pending!!.user} (UID ${pending!!.uid})")
                    if (obs != null && obs.eventAt >= pending!!.startedAt) {
                        Text("Найдено событие экрана Conversation · windowId=${obs.windowId} · ${Date(obs.eventAt)}", color = MaterialTheme.colorScheme.primary)
                    } else {
                        Text("Событие экрана переписки после запуска пока не обнаружено.", color = MaterialTheme.colorScheme.error)
                    }
                    OutlinedTextField(value = label, onValueChange = { label = it.take(80) }, label = { Text("Метка чата (введи сам)") }, placeholder = { Text("Например: Рабочая смена") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    Button(onClick = { confirmBinding() }, enabled = obs != null && obs.eventAt >= pending!!.startedAt && label.isNotBlank()) { Text("Подтвердить привязку") }
                    TextButton(onClick = { ProfileBindingStore.cancel(this@MainActivity); refresh() }) { Text("Отменить сессию") }
                } else {
                    Text("Активной сессии привязки нет.")
                }
                HorizontalDivider()
                Text("3. Сохранённые привязки", style = MaterialTheme.typography.titleLarge)
                if (bindings.isEmpty()) Text("Пока нет подтверждённых привязок.")
                bindings.forEach { row ->
                    val p = row.split('\t')
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(10.dp)) {
                            Text(p.getOrNull(0) ?: "Чат", style = MaterialTheme.typography.titleMedium)
                            Text("Профиль ${p.getOrNull(1)} · serial ${p.getOrNull(2)} · UID ${p.getOrNull(3)}")
                            Text("Окно переписки ${p.getOrNull(5)} · время ${p.getOrNull(6)}", style = MaterialTheme.typography.bodySmall)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                TextButton(onClick = { editingRow = row; editingLabel = p.getOrNull(0).orEmpty() }) { Text("Изменить метку") }
                                TextButton(onClick = {
                                    val ok = ProfileBindingStore.deleteBinding(this@MainActivity, row)
                                    status = if (ok) "Запись удалена и проверена." else "Не удалось проверить удаление."
                                    refresh()
                                }) { Text("Удалить") }
                            }
                        }
                    }
                }
                if (editingRow != null) {
                    AlertDialog(
                        onDismissRequest = { editingRow = null },
                        title = { Text("Изменить метку чата") },
                        text = { OutlinedTextField(value = editingLabel, onValueChange = { editingLabel = it.take(80) }, label = { Text("Новая метка") }, singleLine = true) },
                        confirmButton = { TextButton(onClick = {
                            val ok = ProfileBindingStore.updateLabel(this@MainActivity, editingRow!!, editingLabel)
                            status = if (ok) "Метка изменена, запись проверена." else "Не удалось сохранить изменение."
                            editingRow = null
                            refresh()
                        }) { Text("Сохранить") } },
                        dismissButton = { TextButton(onClick = { editingRow = null }) { Text("Отмена") } }
                    )
                }
                Text("Ограничение: метка чата вводится оператором; приложение не читает название чата. Событие Conversation после контролируемого запуска — полезный сигнал последовательности, но AccessibilityEvent не содержит UserHandle. Поэтому это ручная привязка, не независимое доказательство источника события и не разрешение на автоматическую отправку.", color = MaterialTheme.colorScheme.error)
                HorizontalDivider()
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Журнал", style = MaterialTheme.typography.titleLarge)
                    Row {
                        TextButton(onClick = { copyEntireLog() }) { Text("Копировать") }
                        TextButton(onClick = { DiagnosticStore.clear(this@MainActivity); refresh() }) { Text("Очистить") }
                    }
                }
                Text("Событий: ${logs.size}. Текст переписки не считывается.", style = MaterialTheme.typography.bodySmall)
                logs.forEach { Text(it, style = MaterialTheme.typography.bodySmall) }
            }
        }
    }

    private fun copyEntireLog() {
        val all = DiagnosticStore.readAllChronological(this)
        val header = buildString {
            appendLine("TS AutoReport — контролируемая привязка чатов")
            appendLine("Версия приложения: 0.9.1-ts-bind-091")
            appendLine("BUILD ID: TS-BIND-091")
            appendLine("versionCode: 10")
            appendLine("Устройство: ${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}")
            appendLine("Android: ${android.os.Build.VERSION.RELEASE} (API ${android.os.Build.VERSION.SDK_INT})")
            appendLine("Событий: ${all.size}")
            appendLine("ОГРАНИЧЕНИЕ: метка чата ручная; AccessibilityEvent не предоставляет UserHandle источника. Привязка не включает автоматическую отправку.")
            appendLine("Сохранение привязки проверяется commit() и повторным чтением SharedPreferences; это подтверждает запись, но не происхождение Accessibility-события.")
            appendLine("----------------------------------------")
        }
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("TS AutoReport binding", header + all.joinToString("\n")))
        Toast.makeText(this, "Журнал скопирован: ${all.size} событий", Toast.LENGTH_LONG).show()
    }

    private fun stamp() = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault()).format(Date())

    private fun isServiceEnabled(): Boolean {
        val manager = getSystemService(ACCESSIBILITY_SERVICE) as AccessibilityManager
        val expected = ComponentName(this, WhatsAppAccessibilityService::class.java)
        return manager.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            .any { it.resolveInfo.serviceInfo.let { info -> ComponentName(info.packageName, info.name) == expected } }
    }
}
