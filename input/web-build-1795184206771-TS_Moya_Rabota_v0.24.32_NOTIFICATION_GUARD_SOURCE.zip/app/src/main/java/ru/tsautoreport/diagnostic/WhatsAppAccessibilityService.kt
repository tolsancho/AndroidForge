package ru.tsautoreport.diagnostic

import android.accessibilityservice.AccessibilityService
import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.app.KeyguardManager
import android.os.Bundle
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityWindowInfo
import android.view.accessibility.AccessibilityNodeInfo
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Scheduled WhatsApp automation for the user-confirmed Dual Messenger shortcut. */
class WhatsAppAccessibilityService : AccessibilityService() {
    private val lastLogged = mutableMapOf<String, Long>()
    private var homeClickAttempted = false
    @Volatile private var homeNavigationStartedAt = 0L
    private val mainHandler = Handler(Looper.getMainLooper())
    @Volatile private var scheduledDraftRunning = false
    @Volatile private var scheduledInputAttempted = false
    @Volatile private var originalScreenWasOn = true
    private var scheduledWakeLock: PowerManager.WakeLock? = null
    @Volatile private var scheduledMessage: String = "проверка"
    @Volatile private var scheduledSlot: Int = 0
    @Volatile private var scheduledChatId: String = ""
    @Volatile private var scheduledBehavior: String = "SEND"

    override fun onServiceConnected() {
        super.onServiceConnected()
        activeService = this
        DiagnosticStore.add(this, "${stamp()} | ACCESSIBILITY_SERVICE_CONNECTED | homeNavigation=available")
    }

    override fun onDestroy() {
        if (activeService === this) activeService = null
        super.onDestroy()
    }

    /** Starts the scheduled send sequence for the user-confirmed clone shortcut. */
    private fun beginDraftTest(message: String = "проверка", slot: Int = 0, chatId: String = "", behavior: String = "SEND") {
        if (scheduledDraftRunning) {
            DiagnosticStore.add(this, "${stamp()} | DRAFT_TEST_ABORTED | reason=ANOTHER_TEST_ALREADY_RUNNING")
            return
        }
        val chat = ChatScheduleStore.chat(this, chatId)
        if (chat == null || !chat.confirmed || chat.launcherLabel.length < 3) {
            DiagnosticStore.add(this, "${stamp()} | DRAFT_TEST_ABORTED | reason=CLONE_SHORTCUT_NOT_CONFIRMED")
            return
        }
        scheduledDraftRunning = true
        scheduledInputAttempted = false
        scheduledMessage = message.take(3000)
        scheduledBehavior = behavior
        scheduledSlot = slot
        scheduledChatId = chatId
        ChatScheduleStore.setPending(this, chatId)
        val power = getSystemService(Context.POWER_SERVICE) as PowerManager
        originalScreenWasOn = power.isInteractive
        DiagnosticStore.add(this, "${stamp()} | DRAFT_TEST_STARTED | screenWasOn=$originalScreenWasOn | chatLabel=${chat.launcherLabel} | slot=${slot + 1} | textLength=${scheduledMessage.length} | behavior=$scheduledBehavior | sendEnabled=${scheduledBehavior == "SEND"}")
        if (!originalScreenWasOn) {
            try {
                scheduledWakeLock = power.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP or PowerManager.ON_AFTER_RELEASE, "TSAutoReport:DraftTest")
                scheduledWakeLock?.acquire(25_000L)
                // AccessibilityService has no GLOBAL_ACTION_WAKE_UP constant.
                // The timed SCREEN_BRIGHT_WAKE_LOCK above is the supported wake attempt.
                val wakeLockHeld = scheduledWakeLock?.isHeld == true
                DiagnosticStore.add(this, "${stamp()} | DRAFT_TEST_WAKE_SCREEN | wakeLockAcquired=$wakeLockHeld | mechanism=SCREEN_BRIGHT_WAKE_LOCK | accessibilityWakeAction=NOT_AVAILABLE")
            } catch (e: Exception) {
                abortDraftTest("WAKE_FAILED_${e.javaClass.simpleName}")
                return
            }
            mainHandler.postDelayed({ handleKeyguardBeforeLaunch() }, 1400L)
        } else {
            DiagnosticStore.add(this, "${stamp()} | DRAFT_TEST_SCREEN_STATE | interactive=true | keyguard=${isKeyguardLocked()}")
            handleKeyguardBeforeLaunch()
        }
    }

    private fun handleKeyguardBeforeLaunch() {
        if (!scheduledDraftRunning) return
        if (isKeyguardLocked()) {
            DiagnosticStore.add(this, "${stamp()} | DRAFT_TEST_KEYGUARD_DETECTED | action=TRY_SIMPLE_SWIPE_ONLY")
            trySimpleSwipeUnlock()
            return
        }
        launchScheduledCloneShortcut()
    }

    private fun trySimpleSwipeUnlock() {
        val metrics = resources.displayMetrics
        val x = metrics.widthPixels / 2f
        val startY = metrics.heightPixels * 0.88f
        val endY = metrics.heightPixels * 0.18f
        val path = Path().apply { moveTo(x, startY); lineTo(x, endY) }
        val gesture = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 550)).build()
        val dispatched = try { dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                DiagnosticStore.add(this@WhatsAppAccessibilityService, "${stamp()} | DRAFT_TEST_SWIPE_GESTURE | completed=true")
                mainHandler.postDelayed({
                    if (isKeyguardLocked()) abortDraftTest("KEYGUARD_STILL_LOCKED_AFTER_SWIPE")
                    else launchScheduledCloneShortcut()
                }, 1300L)
            }
            override fun onCancelled(gestureDescription: GestureDescription?) {
                abortDraftTest("SWIPE_GESTURE_CANCELLED")
            }
        }, mainHandler) } catch (_: Exception) { false }
        DiagnosticStore.add(this, "${stamp()} | DRAFT_TEST_SWIPE_DISPATCH | accepted=$dispatched")
        if (!dispatched) abortDraftTest("SWIPE_GESTURE_NOT_ACCEPTED")
    }

    private fun isKeyguardLocked(): Boolean = try {
        (getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager).isKeyguardLocked
    } catch (_: Exception) { true }

    private fun launchScheduledCloneShortcut() {
        if (!scheduledDraftRunning) return
        if (isKeyguardLocked()) { abortDraftTest("KEYGUARD_LOCKED_BEFORE_LAUNCH"); return }
        val requested = ChatScheduleStore.pending(this) != null
        DiagnosticStore.add(this, "${stamp()} | DRAFT_TEST_HOME_SHORTCUT_REQUEST | requested=$requested | chatId=$scheduledChatId")
        if (!requested) { abortDraftTest("HOME_SHORTCUT_REQUEST_REJECTED"); return }
        val accepted = navigateHomeAndScan()
        DiagnosticStore.add(this, "${stamp()} | DRAFT_TEST_HOME_NAVIGATION | accepted=$accepted")
        if (!accepted) abortDraftTest("HOME_NAVIGATION_UNAVAILABLE")
        else mainHandler.postDelayed({ if (scheduledDraftRunning && !scheduledInputAttempted) abortDraftTest("TIMEOUT_WAITING_FOR_CHAT_CONVERSATION") }, 35_000L)
    }

    private fun handleScheduledConversation() {
        if (!scheduledDraftRunning || scheduledInputAttempted) return
        scheduledInputAttempted = true
        if (scheduledBehavior == "READ") {
            // Reading must not treat any Conversation activity as the requested chat.
            // Validate the actual foreground WhatsApp tree after the required 3-second wait.
            mainHandler.postDelayed({
                if (!scheduledDraftRunning) return@postDelayed
                val readRoot = try { rootInActiveWindow } catch (_: Exception) { null }
                if (readRoot == null || readRoot.packageName?.toString() != "com.whatsapp") {
                    try { readRoot?.recycle() } catch (_: Exception) {}
                    abortDraftTest("READ_ABORT_WHATSAPP_ROOT_NOT_AVAILABLE")
                    return@postDelayed
                }
                try {
                    val expectedChat = ChatScheduleStore.chat(this, scheduledChatId)?.launcherLabel.orEmpty()
                    if (!conversationContainsExactLabel(readRoot, expectedChat)) {
                        DiagnosticStore.add(this, "${stamp()} | READ_MODE_TARGET_VERIFY | verified=false | expected=$expectedChat | noInput=true | noSend=true")
                        abortDraftTest("READ_ABORT_TARGET_CHAT_TITLE_MISMATCH")
                        return@postDelayed
                    }
                    DiagnosticStore.add(this, "${stamp()} | READ_MODE_TARGET_VERIFY | verified=true | expected=$expectedChat | durationMs=3000 | noInput=true | noSend=true")
                    DiagnosticStore.add(this, "${stamp()} | READ_MODE_WAIT_COMPLETE | durationMs=3000 | noInput=true | noSend=true")
                    finishDraftTestAfterInput()
                } finally { try { readRoot.recycle() } catch (_: Exception) {} }
            }, 3000L)
            return
        }
        // SEND gets a full 3-second settling window AFTER the target conversation
        // is reported foreground, before touching the message field. CHECK keeps
        // its previous 2-second timing; READ has its own 3-second no-input wait.
        val beforeInputDelayMs = if (scheduledBehavior == "SEND") 3000L else 2000L
        DiagnosticStore.add(this, "${stamp()} | ${scheduledBehavior}_WAIT_BEFORE_INPUT | durationMs=$beforeInputDelayMs | anchor=target_conversation_foreground | slot=${scheduledSlot + 1}")
        mainHandler.postDelayed({
            if (!scheduledDraftRunning) return@postDelayed
            val root = try { rootInActiveWindow } catch (_: Exception) { null }
            if (root == null || root.packageName?.toString() != "com.whatsapp") {
                try { root?.recycle() } catch (_: Exception) {}
                abortDraftTest("WHATSAPP_CONVERSATION_ROOT_NOT_AVAILABLE")
                return@postDelayed
            }
            try {
                val expectedChat = ChatScheduleStore.chat(this, scheduledChatId)?.launcherLabel.orEmpty()
                if (!conversationContainsExactLabel(root, expectedChat)) {
                    abortDraftTest("TARGET_CHAT_TITLE_NOT_VERIFIED")
                    return@postDelayed
                }
                val fields = mutableListOf<AccessibilityNodeInfo>()
                collectEditableFields(root, fields, 0)
                val visible = fields.filter { it.isVisibleToUser && it.isEnabled && it.isEditable }
                if (visible.size != 1) {
                    DiagnosticStore.add(this, "${stamp()} | DRAFT_TEST_INPUT_FIELD_CHECK | editableVisibleCount=${visible.size}")
                    fields.forEach { try { it.recycle() } catch (_: Exception) {} }
                    abortDraftTest("EDITABLE_FIELD_NOT_UNIQUE")
                    return@postDelayed
                }
                val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, scheduledMessage) }
                val set = try { visible.single().performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args) } catch (_: Exception) { false }
                DiagnosticStore.add(this, "${stamp()} | DRAFT_TEST_TEXT_INSERT | actionSetTextAccepted=$set | textLength=${scheduledMessage.length} | slot=${scheduledSlot + 1} | behavior=$scheduledBehavior | sendInvoked=false")
                fields.forEach { try { it.recycle() } catch (_: Exception) {} }
                if (!set) { abortDraftTest("ACTION_SET_TEXT_REJECTED"); return@postDelayed }
                DiagnosticStore.add(this, "${stamp()} | SEND_SEQUENCE_WAIT_AFTER_INSERT | durationMs=2000 | slot=${scheduledSlot + 1}")
                if (scheduledBehavior == "CHECK") mainHandler.postDelayed({ clearCheckTextWithoutSending() }, 2000L) else mainHandler.postDelayed({ sendAfterExactVerification() }, 2000L)
            } finally { try { root.recycle() } catch (_: Exception) {} }
        }, beforeInputDelayMs)
    }

    private fun conversationContainsExactLabel(root: AccessibilityNodeInfo, expected: String): Boolean {
        if (expected.isBlank()) return false
        val wanted = expected.trim().lowercase(Locale.ROOT).replace(Regex("\\s+"), " ")
        val found = mutableListOf<String>()
        fun walk(node: AccessibilityNodeInfo, depth: Int) {
            if (depth > 22 || found.size > 250) return
            node.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let { found.add(it.lowercase(Locale.ROOT).replace(Regex("\\s+"), " ")) }
            node.contentDescription?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let { found.add(it.lowercase(Locale.ROOT).replace(Regex("\\s+"), " ")) }
            for (i in 0 until node.childCount) { val child = try { node.getChild(i) } catch (_: Exception) { null } ?: continue; try { walk(child, depth + 1) } finally { try { child.recycle() } catch (_: Exception) {} } }
        }
        walk(root, 0)
        return found.any { it == wanted }
    }

    private fun collectEditableFields(node: AccessibilityNodeInfo, out: MutableList<AccessibilityNodeInfo>, depth: Int) {
        if (depth > 20 || out.size > 10) return
        if (node.isEditable) out.add(AccessibilityNodeInfo.obtain(node))
        for (i in 0 until node.childCount) {
            val child = try { node.getChild(i) } catch (_: Exception) { null } ?: continue
            try { collectEditableFields(child, out, depth + 1) } finally { try { child.recycle() } catch (_: Exception) {} }
        }
    }

    /** CHECK mode: verify exact draft text, clear it, never invoke WhatsApp send. */
    private fun clearCheckTextWithoutSending() {
        if (!scheduledDraftRunning) return
        val root = try { rootInActiveWindow } catch (_: Exception) { null }
        if (root == null || root.packageName?.toString() != "com.whatsapp") {
            try { root?.recycle() } catch (_: Exception) {}
            abortDraftTest("CHECK_ABORT_WHATSAPP_ROOT_NOT_AVAILABLE")
            return
        }
        try {
            val expectedChat = ChatScheduleStore.chat(this, scheduledChatId)?.launcherLabel.orEmpty()
            if (!conversationContainsExactLabel(root, expectedChat)) { abortDraftTest("CHECK_ABORT_TARGET_CHAT_TITLE_MISMATCH"); return }
            val fields = mutableListOf<AccessibilityNodeInfo>()
            collectEditableFields(root, fields, 0)
            val visible = fields.filter { it.isVisibleToUser && it.isEnabled && it.isEditable }
            if (visible.size != 1) {
                fields.forEach { try { it.recycle() } catch (_: Exception) {} }
                abortDraftTest("CHECK_ABORT_EDITABLE_FIELD_NOT_UNIQUE")
                return
            }
            val field = visible.single()
            if (field.text?.toString().orEmpty() != scheduledMessage) {
                fields.forEach { try { it.recycle() } catch (_: Exception) {} }
                abortDraftTest("CHECK_ABORT_EXACT_TEXT_MISMATCH")
                return
            }
            val cleared = try { field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, "") }) } catch (_: Exception) { false }
            fields.forEach { try { it.recycle() } catch (_: Exception) {} }
            DiagnosticStore.add(this, "${stamp()} | CHECK_MODE_CLEAR_DRAFT | accepted=$cleared | sendInvoked=false")
            if (!cleared) { abortDraftTest("CHECK_ABORT_CLEAR_REJECTED"); return }
            mainHandler.postDelayed({ if (scheduledDraftRunning) verifyCheckDraftCleared() }, 2000L)
        } finally { try { root.recycle() } catch (_: Exception) {} }
    }

    private fun verifyCheckDraftCleared() {
        if (!scheduledDraftRunning) return
        val root = try { rootInActiveWindow } catch (_: Exception) { null }
        if (root == null || root.packageName?.toString() != "com.whatsapp") {
            try { root?.recycle() } catch (_: Exception) {}
            abortDraftTest("CHECK_ABORT_WHATSAPP_ROOT_LOST_AFTER_CLEAR")
            return
        }
        try {
            val expectedChat = ChatScheduleStore.chat(this, scheduledChatId)?.launcherLabel.orEmpty()
            if (!conversationContainsExactLabel(root, expectedChat)) { abortDraftTest("CHECK_ABORT_TARGET_CHAT_CHANGED_AFTER_CLEAR"); return }
            val fields = mutableListOf<AccessibilityNodeInfo>()
            collectEditableFields(root, fields, 0)
            val visible = fields.filter { it.isVisibleToUser && it.isEnabled && it.isEditable }
            val empty = visible.size == 1 && visible.single().text?.toString().orEmpty().isBlank()
            fields.forEach { try { it.recycle() } catch (_: Exception) {} }
            DiagnosticStore.add(this, "${stamp()} | CHECK_MODE_CLEAR_VERIFY | empty=$empty | sendInvoked=false")
            if (!empty) { abortDraftTest("CHECK_ABORT_DRAFT_NOT_EMPTY_AFTER_CLEAR"); return }
            finishDraftTestAfterInput()
        } finally { try { root.recycle() } catch (_: Exception) {} }
    }

    /** Sends once only when WhatsApp, the unique editable field, exact text and unique send control all verify. */
    private fun sendAfterExactVerification() {
        if (!scheduledDraftRunning) return
        val root = try { rootInActiveWindow } catch (_: Exception) { null }
        if (root == null || root.packageName?.toString() != "com.whatsapp") {
            try { root?.recycle() } catch (_: Exception) {}
            abortDraftTest("SEND_ABORT_WHATSAPP_ROOT_NOT_AVAILABLE")
            return
        }
        try {
            val expectedChat = ChatScheduleStore.chat(this, scheduledChatId)?.launcherLabel.orEmpty()
            if (!conversationContainsExactLabel(root, expectedChat)) {
                abortDraftTest("SEND_ABORT_TARGET_CHAT_TITLE_MISMATCH")
                return
            }
            val fields = mutableListOf<AccessibilityNodeInfo>()
            collectEditableFields(root, fields, 0)
            val visibleFields = fields.filter { it.isVisibleToUser && it.isEnabled && it.isEditable }
            if (visibleFields.size != 1) {
                fields.forEach { try { it.recycle() } catch (_: Exception) {} }
                abortDraftTest("SEND_ABORT_EDITABLE_FIELD_NOT_UNIQUE")
                return
            }
            val actualText = visibleFields.single().text?.toString().orEmpty()
            fields.forEach { try { it.recycle() } catch (_: Exception) {} }
            if (actualText != scheduledMessage) {
                abortDraftTest("SEND_ABORT_EXACT_TEXT_MISMATCH")
                return
            }

            val candidates = mutableListOf<AccessibilityNodeInfo>()
            collectSendControls(root, candidates, 0)
            if (candidates.size != 1) {
                candidates.forEach { try { it.recycle() } catch (_: Exception) {} }
                abortDraftTest("SEND_ABORT_SEND_CONTROL_NOT_UNIQUE_${candidates.size}")
                return
            }
            val control = candidates.single()
            val clicked = try { control.performAction(AccessibilityNodeInfo.ACTION_CLICK) } catch (_: Exception) { false }
            DiagnosticStore.add(this, "${stamp()} | SEND_CONTROL_CLICK | accepted=$clicked | candidateCount=1 | exactTextVerified=true | slot=${scheduledSlot + 1}")
            candidates.forEach { try { it.recycle() } catch (_: Exception) {} }
            if (!clicked) {
                abortDraftTest("SEND_ABORT_CLICK_REJECTED")
                return
            }
            if (scheduledBehavior == "SEND") {
                // Record the accepted WhatsApp send-control action; WhatsApp delivery/read receipt is not independently exposed here.
                NotificationScheduleInfoStore.recordSendAction(this, scheduledChatId)
                ScheduleKeepAliveService.refresh(this)
                DiagnosticStore.add(this, "${stamp()} | NOTIFICATION_LAST_SEND_RECORDED | chatId=$scheduledChatId | evidence=send_control_click_accepted")
            }
            mainHandler.postDelayed({
                if (!scheduledDraftRunning) return@postDelayed
                val verifyRoot = try { rootInActiveWindow } catch (_: Exception) { null }
                val stillWhatsApp = verifyRoot?.packageName?.toString() == "com.whatsapp"
                try { verifyRoot?.recycle() } catch (_: Exception) {}
                DiagnosticStore.add(this, "${stamp()} | SEND_SEQUENCE_POST_WAIT | durationMs=2000 | whatsappForeground=$stillWhatsApp | clickAccepted=true | deliveryNotIndependentlyVerified=true")
                finishDraftTestAfterInput()
            }, 2000L)
        } finally { try { root.recycle() } catch (_: Exception) {} }
    }

    private fun collectSendControls(node: AccessibilityNodeInfo, out: MutableList<AccessibilityNodeInfo>, depth: Int) {
        if (depth > 24 || out.size > 8) return
        val viewId = try { node.viewIdResourceName.orEmpty().lowercase(Locale.ROOT) } catch (_: Exception) { "" }
        val desc = node.contentDescription?.toString()?.lowercase(Locale.ROOT).orEmpty()
        val label = node.text?.toString()?.lowercase(Locale.ROOT).orEmpty()
        val semanticMatch = viewId.contains("send") || desc in setOf("send", "отправить", "отправка", "send message", "отправить сообщение") || label in setOf("send", "отправить")
        if (semanticMatch && node.isVisibleToUser && node.isEnabled) {
            var target = AccessibilityNodeInfo.obtain(node)
            if (!target.isClickable) {
                var parent = target.parent
                target.recycle()
                target = parent ?: return
                var hops = 0
                while (!target.isClickable && hops++ < 5) {
                    val next = target.parent
                    target.recycle()
                    target = next ?: return
                }
            }
            if (target.isVisibleToUser && target.isEnabled && target.isClickable) out.add(target) else target.recycle()
        }
        for (i in 0 until node.childCount) {
            val child = try { node.getChild(i) } catch (_: Exception) { null } ?: continue
            try { collectSendControls(child, out, depth + 1) } finally { try { child.recycle() } catch (_: Exception) {} }
        }
    }

    private fun finishDraftTestAfterInput() {
        if (!scheduledDraftRunning) return
        ChatScheduleStore.clearPending(this)
        DiagnosticStore.add(this, "${stamp()} | DRAFT_TEST_KEYBOARD_DISMISS_REQUEST | method=GLOBAL_ACTION_BACK | behavior=$scheduledBehavior | sendInvoked=${scheduledBehavior == "SEND"}")
        val back = try { performGlobalAction(GLOBAL_ACTION_BACK) } catch (_: Exception) { false }
        DiagnosticStore.add(this, "${stamp()} | DRAFT_TEST_KEYBOARD_DISMISS_RESULT | accepted=$back")
        mainHandler.postDelayed({
            if (!scheduledDraftRunning) return@postDelayed
            DiagnosticStore.add(this, "${stamp()} | DRAFT_TEST_HOME_AFTER_INPUT | requested=true | behavior=$scheduledBehavior | sendInvoked=${scheduledBehavior == "SEND"}")
            val home = try { performGlobalAction(GLOBAL_ACTION_HOME) } catch (_: Exception) { false }
            DiagnosticStore.add(this, "${stamp()} | DRAFT_TEST_HOME_AFTER_INPUT_RESULT | accepted=$home")
            if (!home) { abortDraftTest("HOME_AFTER_INPUT_REJECTED"); return@postDelayed }
            mainHandler.postDelayed({
            if (!scheduledDraftRunning) return@postDelayed
            if (!originalScreenWasOn) {
                val locked = try { performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN) } catch (_: Exception) { false }
                DiagnosticStore.add(this, "${stamp()} | DRAFT_TEST_LOCK_SCREEN | accepted=$locked")
            }
            DiagnosticStore.add(this, "${stamp()} | DRAFT_TEST_FINISHED | behavior=$scheduledBehavior | sendControlClicked=${scheduledBehavior == "SEND"} | deliveryNotVerified=true | originalScreenWasOn=$originalScreenWasOn")
            cleanupDraftTest()
            }, 1300L)
        }, 500L)
    }

    private fun abortDraftTest(reason: String) {
        ChatScheduleStore.clearPending(this)
        DiagnosticStore.add(this, "${stamp()} | DRAFT_TEST_ABORTED | reason=$reason | sendInvoked=false")
        cleanupDraftTest()
    }

    private fun cleanupDraftTest() {
        scheduledDraftRunning = false
        scheduledInputAttempted = false
        try { scheduledWakeLock?.let { if (it.isHeld) it.release() } } catch (_: Exception) {}
        scheduledWakeLock = null
    }

    /** Called by the exact-alarm receiver. */
    private fun startScheduledDraftTestInternal(message: String, slot: Int, chatId: String, behavior: String) = beginDraftTest(message, slot, chatId, behavior)

    /** One-button sequence: HOME once, wait for the actual launcher, then click the unique saved clone icon. */
    fun navigateHomeAndScan(): Boolean {
        homeClickAttempted = false
        homeNavigationStartedAt = System.currentTimeMillis()
        DiagnosticStore.add(this, "${stamp()} | HOME_SEQUENCE_STARTED | label=${ChatScheduleStore.pending(this)?.launcherLabel.orEmpty()} | chatId=$scheduledChatId")
        val accepted = try { performGlobalAction(GLOBAL_ACTION_HOME) } catch (_: Exception) { false }
        DiagnosticStore.add(this, "${stamp()} | HOME_GLOBAL_ACTION | attempt=1 | accepted=$accepted")
        if (!accepted) {
            DiagnosticStore.add(this, "${stamp()} | HOME_SEQUENCE_ABORTED | reason=GLOBAL_ACTION_HOME_REJECTED")
            return false
        }
        // Poll the launcher after navigation. Never issue HOME again after the icon click.
        val delays = longArrayOf(650L, 1100L, 1700L, 2500L, 3800L, 5500L, 8000L)
        delays.forEachIndexed { index, delay ->
            mainHandler.postDelayed({ scanActiveLauncher("home_poll_${index + 1}_${delay}ms") }, delay)
        }
        return true
    }

    private fun scanActiveLauncher(source: String) {
        if (ChatScheduleStore.pending(this)?.launcherLabel == null || homeClickAttempted || ShortcutCaptureStore.isCapturing(this)) return
        val elapsed = System.currentTimeMillis() - homeNavigationStartedAt
        if (homeNavigationStartedAt <= 0L || elapsed < 1100L) {
            DiagnosticStore.add(this, "${stamp()} | HOME_SCAN_DEFERRED | source=$source | elapsedMs=$elapsed | reason=WAIT_FOR_HOME_SCREEN")
            return
        }
        val root = try { rootInActiveWindow } catch (_: Exception) { null } ?: return
        val pkg = root.packageName?.toString().orEmpty()
        try {
            if (pkg in launcherPackages) {
                DiagnosticStore.add(this, "${stamp()} | HOME_LAUNCHER_SCAN_TRIGGER | source=$source | launcher=$pkg")
                inspectHomeShortcut(pkg)
            } else {
                DiagnosticStore.add(this, "${stamp()} | HOME_LAUNCHER_NOT_FOREGROUND | source=$source | foreground=$pkg")
            }
        } finally { try { root.recycle() } catch (_: Exception) {} }
    }

    companion object {
        @Volatile private var activeService: WhatsAppAccessibilityService? = null
        private val launcherPackages = setOf(
            "com.sec.android.app.launcher", "com.android.launcher3",
            "com.google.android.apps.nexuslauncher", "com.miui.home",
            "com.oppo.launcher", "com.oplus.launcher", "com.oneplus.launcher", "com.huawei.android.launcher",
            "com.vivo.launcher", "com.motorola.launcher3", "com.hihonor.android.launcher"
        )
        fun requestHomeNavigation(): Boolean = activeService?.navigateHomeAndScan() ?: false
        fun beginScheduledDraftTest(message: String = "проверка", slot: Int = 0, chatId: String, behavior: String = "SEND"): Boolean {
            val service = activeService ?: return false
            service.startScheduledDraftTestInternal(message, slot, chatId, behavior)
            return true
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString() ?: return
        if (ChatScheduleStore.pending(this)?.launcherLabel == null) homeClickAttempted = false
        if (pkg != "com.whatsapp") {
            val elapsed = System.currentTimeMillis() - homeNavigationStartedAt
            if (ShortcutCaptureStore.isCapturing(this) && pkg in launcherPackages) {
                ShortcutCaptureStore.observeLauncher(this, pkg)
                // Capture the exact visible label while the launcher is still foreground.
                // TYPE_VIEW_CLICKED may arrive after WhatsApp has already replaced the root,
                // so waiting for the click event alone can lose the icon's accessibility node.
                if (!ShortcutCaptureStore.hasVisibleCapture(this)) {
                    val liveRoot = try { rootInActiveWindow } catch (_: Exception) { null }
                    if (liveRoot != null) {
                        val liveMatches = mutableListOf<AccessibilityNodeInfo>()
                        try {
                            val wanted = ChatScheduleStore.pending(this)?.launcherLabel.orEmpty()
                            if (liveRoot.packageName?.toString() == pkg && wanted.isNotBlank()) {
                                collectMatchingNodes(liveRoot, wanted, liveMatches, 0)
                            }
                            val uniqueLive = liveMatches.distinctBy { node ->
                                val rect = android.graphics.Rect(); node.getBoundsInScreen(rect); rect.flattenToString()
                            }
                            if (uniqueLive.size == 1) {
                                val saved = ShortcutCaptureStore.capture(this, pkg, uniqueLive.first())
                                DiagnosticStore.add(this, "${stamp()} | SHORTCUT_CAPTURE_PRECLICK_LABEL | launcher=$pkg | label=$wanted | unique=${uniqueLive.size} | saved=$saved")
                            }
                        } finally {
                            liveMatches.forEach { try { it.recycle() } catch (_: Exception) {} }
                            try { liveRoot.recycle() } catch (_: Exception) {}
                        }
                    }
                }
                if (event.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED && elapsed >= 300L) {
                    val source = try { event.source } catch (_: Exception) { null }
                    if (source != null) {
                        val labelNodes = mutableListOf<AccessibilityNodeInfo>()
                        val homeRoot = try { rootInActiveWindow } catch (_: Exception) { null }
                        val expectedLabel = ChatScheduleStore.pending(this)?.launcherLabel.orEmpty()
                        try {
                            if (homeRoot?.packageName?.toString() == pkg && expectedLabel.isNotBlank()) {
                                collectMatchingNodes(homeRoot, expectedLabel, labelNodes, 0)
                            }
                            val uniqueLabels = labelNodes.distinctBy { node ->
                                val r = android.graphics.Rect(); node.getBoundsInScreen(r)
                                "${node.viewIdResourceName}|${r.flattenToString()}"
                            }
                            // Preserve the actual node reported by TYPE_VIEW_CLICKED.
                            // A separately found caption node may be a sibling and must
                            // never replace the clicked node as the identity evidence.
                            val sourcePackage = source.packageName?.toString().orEmpty()
                            if(sourcePackage.isBlank() || sourcePackage == pkg) {
                                val saved = ShortcutCaptureStore.capture(this, pkg, source, clicked=true)
                                DiagnosticStore.add(this, "${stamp()} | SHORTCUT_CAPTURE_LAUNCHER_TAP | launcher=$pkg | eventClass=${event.className} | typedLabel=$expectedLabel | exactLabelNodes=${uniqueLabels.size} | storedSource=actual_event_source | sourcePackage=$sourcePackage | saved=$saved")
                            } else {
                                DiagnosticStore.add(this, "${stamp()} | SHORTCUT_CAPTURE_TAP_REJECTED | reason=SOURCE_PACKAGE_MISMATCH | launcher=$pkg | sourcePackage=$sourcePackage")
                            }
                        } finally {
                            labelNodes.forEach { try { it.recycle() } catch (_: Exception) {} }
                            try { homeRoot?.recycle() } catch (_: Exception) {}
                            try { source.recycle() } catch (_: Exception) {}
                        }
                    } else DiagnosticStore.add(this, "${stamp()} | SHORTCUT_CAPTURE_TAP_WITHOUT_SOURCE | launcher=$pkg | eventClass=${event.className} | retry=next_launcher_accessibility_event | confirmation_blocked=true")
                }
                return
            }
            if (ShortcutCaptureStore.isCapturing(this)) return
            if (ChatScheduleStore.pending(this)?.launcherLabel != null && pkg in launcherPackages && homeNavigationStartedAt > 0L && elapsed >= 1100L && !homeClickAttempted) {
                DiagnosticStore.add(this, "${stamp()} | HOME_LAUNCHER_EVENT_AFTER_HOME | launcher=$pkg | elapsedMs=$elapsed")
                inspectHomeShortcut(pkg)
            }
            return
        }

        val type = when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> "WINDOW_STATE_CHANGED"
            AccessibilityEvent.TYPE_WINDOWS_CHANGED -> "WINDOWS_CHANGED"
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED -> "WINDOW_CONTENT_CHANGED"
            AccessibilityEvent.TYPE_VIEW_FOCUSED -> "VIEW_FOCUSED"
            else -> "EVENT_${event.eventType}"
        }
        val cls = event.className?.toString() ?: "(class-not-provided)"
        val winId = event.windowId
        if ((ShortcutCaptureStore.isCapturing(this) || ShortcutCaptureStore.isVerifying(this)) && pkg == "com.whatsapp") {
            // Do not depend on WhatsApp exposing a particular Conversation activity/class.
            // Some OEM/WhatsApp builds report only the package/window transition. The user
            // manually tapped the launcher icon and must visually verify the exact chat/profile.
            val elapsedSinceHome = System.currentTimeMillis() - homeNavigationStartedAt
            val foregroundEvent = event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
                event.eventType == AccessibilityEvent.TYPE_WINDOWS_CHANGED ||
                event.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
            if (homeNavigationStartedAt > 0L && elapsedSinceHome >= 500L && foregroundEvent) {
                val root = try { rootInActiveWindow } catch (_: Exception) { null }
                var evidence = "WhatsApp_foreground_after_manual_launcher_tap"
                if (root != null) {
                    try {
                        val rootClass = root.className?.toString().orEmpty()
                        val targetLabel = ChatScheduleStore.pending(this)?.launcherLabel.orEmpty()
                        val titleEvidence = targetLabel.isNotBlank() && accessibilityTreeContainsExactText(root, targetLabel)
                        evidence = when {
                            titleEvidence -> "exact_chat_title:$targetLabel"
                            cls.contains("Conversation", true) || rootClass.contains("Conversation", true) -> "conversation_window:$rootClass"
                            else -> "WhatsApp_foreground:$rootClass"
                        }
                    } finally { try { root.recycle() } catch (_: Exception) {} }
                }
                ShortcutCaptureStore.markConversation(this, "", evidence)
                ShortcutCaptureStore.markVerificationForeground(this, evidence)
                DiagnosticStore.add(this, "${stamp()} | SHORTCUT_CAPTURE_WHATSAPP_FOREGROUND | elapsedMs=$elapsedSinceHome | event=$type | class=$cls | evidence=$evidence | user_confirmation_required=true")
            }
        }
        if (pkg == "com.whatsapp" && (cls.contains("Conversation", true) || try { rootInActiveWindow?.className?.toString()?.contains("Conversation", true) == true } catch (_: Exception) { false })) {
            ProfileBindingStore.observeConversation(this, winId, cls, System.currentTimeMillis())
            HomeShortcutStore.markConversationObserved(this, winId)
            handleScheduledConversation()
        }
        val displayId = if (Build.VERSION.SDK_INT >= 30) event.displayId else -1
        val now = System.currentTimeMillis()
        val fingerprint = "$type|$pkg|$cls|$winId|$displayId"
        val throttleMs = if (event.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) 900L else 250L
        val previous = lastLogged[fingerprint] ?: 0L
        if (now - previous < throttleMs) return
        lastLogged[fingerprint] = now
        if (lastLogged.size > 100) lastLogged.clear()

        val sourceInfo = try {
            event.source?.let { node ->
                val result = "source=${node.packageName}/${node.className}#${node.windowId}"
                node.recycle()
                result
            } ?: "source=null"
        } catch (_: Exception) { "source=unavailable" }
        val activeRoot = try {
            rootInActiveWindow?.let { root ->
                val result = "root=${root.packageName}/${root.className}#${root.windowId}"
                root.recycle()
                result
            } ?: "root=null"
        } catch (_: Exception) { "root=unavailable" }
        val windows = try { describeWindows() } catch (_: Exception) { "windows=unavailable" }
        val processReport = try { runningProcessReport() } catch (_: Exception) { "runningProcesses=unavailable" }
        val time = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault()).format(Date(now))
        DiagnosticStore.add(this, "$time | $type | pkg=$pkg | class=$cls | eventWindow=$winId | display=$displayId | $sourceInfo | $activeRoot | $windows | $processReport | originUserHandle=NOT_EXPOSED_BY_ACCESSIBILITY_EVENT")
    }


    /**
     * Assisted launcher-icon method: after the user requests a clone-only test, inspect only
     * launcher accessibility nodes for the exact user-entered home-screen shortcut label.
     * It never reads WhatsApp conversation UI or message contents.
     */
    private fun inspectHomeShortcut(launcherPackage: String) {
        if (homeClickAttempted) return
        val pending = ChatScheduleStore.pending(this) ?: return
        val target = pending.launcherLabel.trim()
        if (target.length < 3) return
        val root = try { rootInActiveWindow } catch (_: Exception) { null } ?: return
        if (root.packageName?.toString() != launcherPackage) {
            try { root.recycle() } catch (_: Exception) {}
            return
        }
        val selector = ShortcutCaptureStore.selector(this, pending.id)
        val candidates = mutableListOf<AccessibilityNodeInfo>()
        try {
            // The trained selector is authoritative. It is matched against the actual
            // visible text/contentDescription captured when the user manually tapped the
            // desired home-screen icon. A generic view ID or old screen coordinates must
            // never identify a shortcut by themselves.
            val savedName = selector?.text?.takeIf { it.isNotBlank() }
                ?: selector?.description?.takeIf { it.isNotBlank() }
            if (selector != null && selector.launcher == launcherPackage && savedName != null) {
                // Use the actual captured launcher caption, which may be ellipsized by the
                // home screen and intentionally differs from the full name typed in the app.
                collectSelectorNodes(root, selector, candidates, 0)
            }

            var matchSource = "saved_selector_text_or_description"
            if (candidates.isEmpty()) {
                // Fallback for launchers that did not expose useful text at capture time:
                // only a unique exact visible match of the user's entered name is allowed.
                matchSource = "unique_exact_entered_label_fallback"
                collectMatchingNodes(root, target, candidates, 0)
            }

            val unique = candidates.distinctBy { node ->
                val r = android.graphics.Rect(); node.getBoundsInScreen(r)
                r.flattenToString()
            }
            DiagnosticStore.add(this, "${stamp()} | HOME_SHORTCUT_SELECTOR_AUDIT | launcher=$launcherPackage | entered=$target | savedLauncher=${selector?.launcher.orEmpty()} | capturedText=${selector?.text.orEmpty()} | capturedDescription=${selector?.description.orEmpty()} | capturedViewId=${selector?.viewId.orEmpty()} | matchSource=$matchSource | candidates=${unique.size} | policy=clicked_launcher_selector_then_unique_exact_label_fallback")

            if (unique.size == 1) {
                val clickable = findClickableAncestor(unique.first())
                if (clickable != null) {
                    homeClickAttempted = true
                    val clicked = try { clickable.performAction(AccessibilityNodeInfo.ACTION_CLICK) } catch (_: Exception) { false }
                    val bounds = android.graphics.Rect(); runCatching { clickable.getBoundsInScreen(bounds) }
                    try { clickable.recycle() } catch (_: Exception) {}
                    HomeShortcutStore.finish(this, if (clicked) "TRAINED_SHORTCUT_CLICK_ACCEPTED" else "TRAINED_SHORTCUT_CLICK_REJECTED", unique.size, clicked)
                    DiagnosticStore.add(this, "${stamp()} | TRAINED_SHORTCUT_CLICK | label=$target | source=$matchSource | bounds=${bounds.flattenToString()} | accepted=$clicked | verify_whatsapp_foreground_required=true")
                } else {
                    homeClickAttempted = true
                    HomeShortcutStore.finish(this, "MATCH_FOUND_BUT_NO_CLICKABLE_ANCESTOR", unique.size, false)
                }
            } else if (unique.size > 1) {
                homeClickAttempted = true
                HomeShortcutStore.finish(this, "AMBIGUOUS_MATCH_NO_CLICK", unique.size, false)
                DiagnosticStore.add(this, "${stamp()} | TRAINED_SHORTCUT_ABORTED | reason=AMBIGUOUS_MATCH | count=${unique.size} | no_click=true")
            } else {
                // Do not silently accept a different WhatsApp icon. Keep scanning while
                // the launcher populates its accessibility tree.
                DiagnosticStore.add(this, "${stamp()} | HOME_SHORTCUT_SCAN | launcher=$launcherPackage | label=$target | savedSelectorMatched=false | matches=0 | retry_on_next_launcher_event=true")
            }
        } finally {
            candidates.forEach { try { it.recycle() } catch (_: Exception) {} }
            try { root.recycle() } catch (_: Exception) {}
        }
    }

    private fun collectSelectorNodes(node: AccessibilityNodeInfo, selector: ShortcutCaptureStore.Selector, out: MutableList<AccessibilityNodeInfo>, depth: Int) {
        if (depth > 20 || out.size > 16) return
        val text = node.text?.toString().orEmpty().trim()
        val desc = node.contentDescription?.toString().orEmpty().trim()
        val savedText = selector.text.trim()
        val savedDesc = selector.description.trim()
        val exactVisibleIdentity = (savedText.isNotBlank() && normalizeShortcutLabel(text) == normalizeShortcutLabel(savedText)) ||
            (savedDesc.isNotBlank() && normalizeShortcutLabel(desc) == normalizeShortcutLabel(savedDesc))
        // The click event can originate from an icon ImageView while the visible caption
        // is a sibling/ancestor TextView. Class names are therefore diagnostic only, not
        // an identity constraint; launcher package + captured visible caption identify it.
        if (exactVisibleIdentity) out.add(AccessibilityNodeInfo.obtain(node))
        for (i in 0 until node.childCount) {
            val child = try { node.getChild(i) } catch (_: Exception) { null } ?: continue
            try { collectSelectorNodes(child, selector, out, depth + 1) } finally { try { child.recycle() } catch (_: Exception) {} }
        }
    }

    private fun collectMatchingNodes(node: AccessibilityNodeInfo, target: String, out: MutableList<AccessibilityNodeInfo>, depth: Int) {
        if (depth > 18 || out.size > 12) return
        val text = node.text?.toString().orEmpty().trim()
        val desc = node.contentDescription?.toString().orEmpty().trim()
        fun matches(value: String): Boolean = normalizeShortcutLabel(value) == normalizeShortcutLabel(target) && value.trim().length >= 3
        if (matches(text) || matches(desc)) out.add(AccessibilityNodeInfo.obtain(node))
        for (i in 0 until node.childCount) {
            val child = try { node.getChild(i) } catch (_: Exception) { null } ?: continue
            try { collectMatchingNodes(child, target, out, depth + 1) } finally { try { child.recycle() } catch (_: Exception) {} }
        }
    }

    private fun normalizeShortcutLabel(value:String):String = value.trim().lowercase(Locale.ROOT)
        .replace("…", "").replace("...", "").replace(Regex("\\s+"), " ")

    private fun accessibilityTreeContainsExactText(root: AccessibilityNodeInfo, expected: String): Boolean {
        if (expected.isBlank()) return false
        val wanted = expected.trim().lowercase(Locale.ROOT).replace(Regex("\\s+"), " ")
        var matched = false
        fun walk(node: AccessibilityNodeInfo, depth: Int) {
            if (matched || depth > 18) return
            val values = listOf(node.text?.toString().orEmpty(), node.contentDescription?.toString().orEmpty())
            if (values.any { it.trim().lowercase(Locale.ROOT).replace(Regex("\\s+"), " ") == wanted }) { matched = true; return }
            for (i in 0 until node.childCount) {
                val child = try { node.getChild(i) } catch (_: Exception) { null } ?: continue
                try { walk(child, depth + 1) } finally { try { child.recycle() } catch (_: Exception) {} }
            }
        }
        walk(root, 0)
        return matched
    }

    private fun findClickableAncestor(start: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var node: AccessibilityNodeInfo? = AccessibilityNodeInfo.obtain(start)
        repeat(6) {
            val current = node ?: return null
            if (current.isClickable) return current
            val parent = try { current.parent } catch (_: Exception) { null }
            try { current.recycle() } catch (_: Exception) {}
            node = parent
        }
        node?.let { try { it.recycle() } catch (_: Exception) {} }
        return null
    }

    private fun runningProcessReport(): String {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val running = am.runningAppProcesses.orEmpty()
        if (running.isEmpty()) return "runningProcesses=not_visible_or_empty"
        val whatsapp = running.filter { it.processName.contains("com.whatsapp") }
        return if (whatsapp.isEmpty()) "runningProcesses=WhatsApp_process_not_exposed (visible=${running.size})"
        else "runningProcesses=" + whatsapp.joinToString(";") { "${it.processName}:uid=${it.uid}:importance=${it.importance}" }
    }

    private fun describeWindows(): String {
        val entries = windows.orEmpty().take(8).map { w: AccessibilityWindowInfo ->
            val root = try { w.root } catch (_: Exception) { null }
            val rootPkg = root?.packageName?.toString() ?: "?"
            val rootClass = root?.className?.toString() ?: "?"
            val display = if (Build.VERSION.SDK_INT >= 30) w.displayId else -1
            val description = "${w.id}:${w.type}:active=${w.isActive}:focused=${w.isFocused}:display=$display:$rootPkg/$rootClass"
            root?.recycle()
            description
        }
        return "windows=[${entries.joinToString(";")}]"
    }

    /** Local timestamp helper for automatic diagnostic journal entries. */
    private fun stamp(): String = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault()).format(Date())

    override fun onInterrupt() = Unit
}
