package ru.tsautoreport.diagnostic

import android.accessibilityservice.AccessibilityService
import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.app.KeyguardManager
import android.os.Bundle
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityWindowInfo
import android.view.accessibility.AccessibilityNodeInfo
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Records technical metadata; reads only the user-specified launcher icon label during the explicit home-shortcut test. */
class WhatsAppAccessibilityService : AccessibilityService() {
    private val lastLogged = mutableMapOf<String, Long>()
    private var homeClickAttempted = false
    @Volatile private var homeNavigationStartedAt = 0L
    private val mainHandler = Handler(Looper.getMainLooper())
    @Volatile private var scheduledDraftRunning = false
    @Volatile private var scheduledInputAttempted = false
    @Volatile private var originalScreenWasOn = true
    private var scheduledWakeLock: PowerManager.WakeLock? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        activeService = this
        DiagnosticStore.add(this, "${stamp()} | ACCESSIBILITY_SERVICE_CONNECTED | homeNavigation=available")
    }

    override fun onDestroy() {
        if (activeService === this) activeService = null
        super.onDestroy()
    }

    /** Starts the scheduled, clone-only draft test. It never invokes a send action. */
    private fun beginDraftTest() {
        if (scheduledDraftRunning) {
            DiagnosticStore.add(this, "${stamp()} | DRAFT_TEST_ABORTED | reason=ANOTHER_TEST_ALREADY_RUNNING")
            return
        }
        val saved = HomeShortcutStore.state(this)
        if (!saved.cloneConfirmed || saved.label.length < 3) {
            DiagnosticStore.add(this, "${stamp()} | DRAFT_TEST_ABORTED | reason=CLONE_SHORTCUT_NOT_CONFIRMED")
            return
        }
        scheduledDraftRunning = true
        scheduledInputAttempted = false
        val power = getSystemService(Context.POWER_SERVICE) as PowerManager
        originalScreenWasOn = power.isInteractive
        DiagnosticStore.add(this, "${stamp()} | DRAFT_TEST_STARTED | screenWasOn=$originalScreenWasOn | cloneLabel=${saved.label} | text=проверка | send=false")
        if (!originalScreenWasOn) {
            try {
                scheduledWakeLock = power.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP or PowerManager.ON_AFTER_RELEASE, "TSAutoReport:DraftTest")
                scheduledWakeLock?.acquire(25_000L)
                val wakeAccepted = performGlobalAction(GLOBAL_ACTION_WAKE_UP)
                DiagnosticStore.add(this, "${stamp()} | DRAFT_TEST_WAKE_SCREEN | wakeActionAccepted=$wakeAccepted")
            } catch (e: Exception) {
                abortDraftTest("WAKE_FAILED_${e.javaClass.simpleName}")
                return
            }
            mainHandler.postDelayed({ handleKeyguardBeforeLaunch() }, 1400L)
        } else {
            DiagnosticStore.add(this, "${stamp()} | DRAFT_TEST_SCREEN_STATE | interactive=true | keyguard=${isKeyguardLocked()}")
            handleKeyguardBeforeLaunch()
        }
    }

    private fun handleKeyguardBeforeLaunch() {
        if (!scheduledDraftRunning) return
        if (isKeyguardLocked()) {
            DiagnosticStore.add(this, "${stamp()} | DRAFT_TEST_KEYGUARD_DETECTED | action=TRY_SIMPLE_SWIPE_ONLY")
            trySimpleSwipeUnlock()
            return
        }
        launchScheduledCloneShortcut()
    }

    private fun trySimpleSwipeUnlock() {
        val metrics = resources.displayMetrics
        val x = metrics.widthPixels / 2f
        val startY = metrics.heightPixels * 0.88f
        val endY = metrics.heightPixels * 0.18f
        val path = Path().apply { moveTo(x, startY); lineTo(x, endY) }
        val gesture = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 550)).build()
        val dispatched = try { dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                DiagnosticStore.add(this@WhatsAppAccessibilityService, "${stamp()} | DRAFT_TEST_SWIPE_GESTURE | completed=true")
                mainHandler.postDelayed({
                    if (isKeyguardLocked()) abortDraftTest("KEYGUARD_STILL_LOCKED_AFTER_SWIPE")
                    else launchScheduledCloneShortcut()
                }, 1300L)
            }
            override fun onCancelled(gestureDescription: GestureDescription?) {
                abortDraftTest("SWIPE_GESTURE_CANCELLED")
            }
        }, mainHandler) } catch (_: Exception) { false }
        DiagnosticStore.add(this, "${stamp()} | DRAFT_TEST_SWIPE_DISPATCH | accepted=$dispatched")
        if (!dispatched) abortDraftTest("SWIPE_GESTURE_NOT_ACCEPTED")
    }

    private fun isKeyguardLocked(): Boolean = try {
        (getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager).isKeyguardLocked
    } catch (_: Exception) { true }

    private fun launchScheduledCloneShortcut() {
        if (!scheduledDraftRunning) return
        if (isKeyguardLocked()) { abortDraftTest("KEYGUARD_LOCKED_BEFORE_LAUNCH"); return }
        val requested = HomeShortcutStore.request(this)
        DiagnosticStore.add(this, "${stamp()} | DRAFT_TEST_HOME_SHORTCUT_REQUEST | requested=$requested | cloneOnly=true")
        if (!requested) { abortDraftTest("HOME_SHORTCUT_REQUEST_REJECTED"); return }
        val accepted = navigateHomeAndScan()
        DiagnosticStore.add(this, "${stamp()} | DRAFT_TEST_HOME_NAVIGATION | accepted=$accepted")
        if (!accepted) abortDraftTest("HOME_NAVIGATION_UNAVAILABLE")
        else mainHandler.postDelayed({ if (scheduledDraftRunning && !scheduledInputAttempted) abortDraftTest("TIMEOUT_WAITING_FOR_CHAT_CONVERSATION") }, 35_000L)
    }

    private fun handleScheduledConversation() {
        if (!scheduledDraftRunning || scheduledInputAttempted) return
        scheduledInputAttempted = true
        mainHandler.postDelayed({
            if (!scheduledDraftRunning) return@postDelayed
            val root = try { rootInActiveWindow } catch (_: Exception) { null }
            if (root == null || root.packageName?.toString() != "com.whatsapp") {
                try { root?.recycle() } catch (_: Exception) {}
                abortDraftTest("WHATSAPP_CONVERSATION_ROOT_NOT_AVAILABLE")
                return@postDelayed
            }
            try {
                val fields = mutableListOf<AccessibilityNodeInfo>()
                collectEditableFields(root, fields, 0)
                val visible = fields.filter { it.isVisibleToUser && it.isEnabled && it.isEditable }
                if (visible.size != 1) {
                    DiagnosticStore.add(this, "${stamp()} | DRAFT_TEST_INPUT_FIELD_CHECK | editableVisibleCount=${visible.size}")
                    fields.forEach { try { it.recycle() } catch (_: Exception) {} }
                    abortDraftTest("EDITABLE_FIELD_NOT_UNIQUE")
                    return@postDelayed
                }
                val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, "проверка") }
                val set = try { visible.single().performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args) } catch (_: Exception) { false }
                DiagnosticStore.add(this, "${stamp()} | DRAFT_TEST_TEXT_INSERT | actionSetTextAccepted=$set | textLength=8 | sendInvoked=false")
                fields.forEach { try { it.recycle() } catch (_: Exception) {} }
                if (!set) { abortDraftTest("ACTION_SET_TEXT_REJECTED"); return@postDelayed }
                mainHandler.postDelayed({ finishDraftTestAfterInput() }, 1800L)
            } finally { try { root.recycle() } catch (_: Exception) {} }
        }, 900L)
    }

    private fun collectEditableFields(node: AccessibilityNodeInfo, out: MutableList<AccessibilityNodeInfo>, depth: Int) {
        if (depth > 20 || out.size > 10) return
        if (node.isEditable) out.add(AccessibilityNodeInfo.obtain(node))
        for (i in 0 until node.childCount) {
            val child = try { node.getChild(i) } catch (_: Exception) { null } ?: continue
            try { collectEditableFields(child, out, depth + 1) } finally { try { child.recycle() } catch (_: Exception) {} }
        }
    }

    private fun finishDraftTestAfterInput() {
        if (!scheduledDraftRunning) return
        DiagnosticStore.add(this, "${stamp()} | DRAFT_TEST_HOME_AFTER_INPUT | requested=true | sendInvoked=false")
        val home = try { performGlobalAction(GLOBAL_ACTION_HOME) } catch (_: Exception) { false }
        DiagnosticStore.add(this, "${stamp()} | DRAFT_TEST_HOME_AFTER_INPUT_RESULT | accepted=$home")
        if (!home) { abortDraftTest("HOME_AFTER_INPUT_REJECTED"); return }
        mainHandler.postDelayed({
            if (!scheduledDraftRunning) return@postDelayed
            if (!originalScreenWasOn) {
                val locked = try { performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN) } catch (_: Exception) { false }
                DiagnosticStore.add(this, "${stamp()} | DRAFT_TEST_LOCK_SCREEN | accepted=$locked")
            }
            DiagnosticStore.add(this, "${stamp()} | DRAFT_TEST_FINISHED | textInserted=true | sendInvoked=false | originalScreenWasOn=$originalScreenWasOn")
            cleanupDraftTest()
        }, 1300L)
    }

    private fun abortDraftTest(reason: String) {
        DiagnosticStore.add(this, "${stamp()} | DRAFT_TEST_ABORTED | reason=$reason | sendInvoked=false")
        cleanupDraftTest()
    }

    private fun cleanupDraftTest() {
        scheduledDraftRunning = false
        scheduledInputAttempted = false
        try { scheduledWakeLock?.let { if (it.isHeld) it.release() } } catch (_: Exception) {}
        scheduledWakeLock = null
    }

    /** Called by the exact-alarm receiver. */
    private fun startScheduledDraftTestInternal() = beginDraftTest()

    /** One-button sequence: HOME once, wait for the actual launcher, then click the unique saved clone icon. */
    fun navigateHomeAndScan(): Boolean {
        homeClickAttempted = false
        homeNavigationStartedAt = System.currentTimeMillis()
        DiagnosticStore.add(this, "${stamp()} | HOME_SEQUENCE_STARTED | label=${HomeShortcutStore.pendingLabel(this).orEmpty()} | cloneOnly=true")
        val accepted = try { performGlobalAction(GLOBAL_ACTION_HOME) } catch (_: Exception) { false }
        DiagnosticStore.add(this, "${stamp()} | HOME_GLOBAL_ACTION | attempt=1 | accepted=$accepted")
        if (!accepted) {
            DiagnosticStore.add(this, "${stamp()} | HOME_SEQUENCE_ABORTED | reason=GLOBAL_ACTION_HOME_REJECTED")
            return false
        }
        // Poll the launcher after navigation. Never issue HOME again after the icon click.
        val delays = longArrayOf(650L, 1100L, 1700L, 2500L, 3800L, 5500L, 8000L)
        delays.forEachIndexed { index, delay ->
            mainHandler.postDelayed({ scanActiveLauncher("home_poll_${index + 1}_${delay}ms") }, delay)
        }
        return true
    }

    private fun scanActiveLauncher(source: String) {
        if (HomeShortcutStore.pendingLabel(this) == null || homeClickAttempted) return
        val elapsed = System.currentTimeMillis() - homeNavigationStartedAt
        if (homeNavigationStartedAt <= 0L || elapsed < 1100L) {
            DiagnosticStore.add(this, "${stamp()} | HOME_SCAN_DEFERRED | source=$source | elapsedMs=$elapsed | reason=WAIT_FOR_HOME_SCREEN")
            return
        }
        val root = try { rootInActiveWindow } catch (_: Exception) { null } ?: return
        val pkg = root.packageName?.toString().orEmpty()
        try {
            if (pkg in launcherPackages) {
                DiagnosticStore.add(this, "${stamp()} | HOME_LAUNCHER_SCAN_TRIGGER | source=$source | launcher=$pkg")
                inspectHomeShortcut(pkg)
            } else {
                DiagnosticStore.add(this, "${stamp()} | HOME_LAUNCHER_NOT_FOREGROUND | source=$source | foreground=$pkg")
            }
        } finally { try { root.recycle() } catch (_: Exception) {} }
    }

    companion object {
        @Volatile private var activeService: WhatsAppAccessibilityService? = null
        private val launcherPackages = setOf(
            "com.sec.android.app.launcher", "com.android.launcher3",
            "com.google.android.apps.nexuslauncher", "com.miui.home",
            "com.oppo.launcher", "com.oneplus.launcher", "com.huawei.android.launcher"
        )
        fun requestHomeNavigation(): Boolean = activeService?.navigateHomeAndScan() ?: false
        fun beginScheduledDraftTest(): Boolean {
            val service = activeService ?: return false
            service.startScheduledDraftTestInternal()
            return true
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString() ?: return
        if (HomeShortcutStore.pendingLabel(this) == null) homeClickAttempted = false
        if (pkg != "com.whatsapp") {
            val elapsed = System.currentTimeMillis() - homeNavigationStartedAt
            if (HomeShortcutStore.pendingLabel(this) != null && pkg in launcherPackages && homeNavigationStartedAt > 0L && elapsed >= 1100L && !homeClickAttempted) {
                DiagnosticStore.add(this, "${stamp()} | HOME_LAUNCHER_EVENT_AFTER_HOME | launcher=$pkg | elapsedMs=$elapsed")
                inspectHomeShortcut(pkg)
            }
            return
        }

        val type = when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> "WINDOW_STATE_CHANGED"
            AccessibilityEvent.TYPE_WINDOWS_CHANGED -> "WINDOWS_CHANGED"
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED -> "WINDOW_CONTENT_CHANGED"
            AccessibilityEvent.TYPE_VIEW_FOCUSED -> "VIEW_FOCUSED"
            else -> "EVENT_${event.eventType}"
        }
        val cls = event.className?.toString() ?: "(class-not-provided)"
        val winId = event.windowId
        if (cls == "com.whatsapp.Conversation") {
            ProfileBindingStore.observeConversation(this, winId, cls, System.currentTimeMillis())
            HomeShortcutStore.markConversationObserved(this, winId)
            handleScheduledConversation()
        }
        val displayId = if (Build.VERSION.SDK_INT >= 30) event.displayId else -1
        val now = System.currentTimeMillis()
        val fingerprint = "$type|$pkg|$cls|$winId|$displayId"
        val throttleMs = if (event.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) 900L else 250L
        val previous = lastLogged[fingerprint] ?: 0L
        if (now - previous < throttleMs) return
        lastLogged[fingerprint] = now
        if (lastLogged.size > 100) lastLogged.clear()

        val sourceInfo = try {
            event.source?.let { node ->
                val result = "source=${node.packageName}/${node.className}#${node.windowId}"
                node.recycle()
                result
            } ?: "source=null"
        } catch (_: Exception) { "source=unavailable" }
        val activeRoot = try {
            rootInActiveWindow?.let { root ->
                val result = "root=${root.packageName}/${root.className}#${root.windowId}"
                root.recycle()
                result
            } ?: "root=null"
        } catch (_: Exception) { "root=unavailable" }
        val windows = try { describeWindows() } catch (_: Exception) { "windows=unavailable" }
        val processReport = try { runningProcessReport() } catch (_: Exception) { "runningProcesses=unavailable" }
        val time = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault()).format(Date(now))
        DiagnosticStore.add(this, "$time | $type | pkg=$pkg | class=$cls | eventWindow=$winId | display=$displayId | $sourceInfo | $activeRoot | $windows | $processReport | originUserHandle=NOT_EXPOSED_BY_ACCESSIBILITY_EVENT")
    }


    /**
     * Assisted launcher-icon method: after the user requests a clone-only test, inspect only
     * launcher accessibility nodes for the exact user-entered home-screen shortcut label.
     * It never reads WhatsApp conversation UI or message contents.
     */
    private fun inspectHomeShortcut(launcherPackage: String) {
        if (homeClickAttempted) return
        val target = HomeShortcutStore.pendingLabel(this) ?: return
        val root = try { rootInActiveWindow } catch (_: Exception) { null } ?: return
        if (root.packageName?.toString() != launcherPackage) {
            try { root.recycle() } catch (_: Exception) {}
            return
        }
        val candidates = mutableListOf<AccessibilityNodeInfo>()
        try {
            collectMatchingNodes(root, target, candidates, 0)
            val unique = candidates.distinctBy { node ->
                val r = android.graphics.Rect(); node.getBoundsInScreen(r)
                "${node.viewIdResourceName}|${r.flattenToString()}"
            }
            if (unique.size == 1) {
                val clickable = findClickableAncestor(unique.first())
                if (clickable != null) {
                    homeClickAttempted = true
                    val clicked = try { clickable.performAction(AccessibilityNodeInfo.ACTION_CLICK) } catch (_: Exception) { false }
                    try { clickable.recycle() } catch (_: Exception) {}
                    HomeShortcutStore.finish(this, if (clicked) "LAUNCHER_ICON_CLICK_ACTION_ACCEPTED" else "LAUNCHER_ICON_CLICK_REJECTED", unique.size, clicked)
                } else {
                    HomeShortcutStore.finish(this, "MATCH_FOUND_BUT_NO_CLICKABLE_ANCESTOR", unique.size, false)
                }
            } else if (unique.size > 1) {
                HomeShortcutStore.finish(this, "AMBIGUOUS_MULTIPLE_MATCHES_NO_CLICK", unique.size, false)
            } else {
                // Keep the request pending while the home screen is still populating.
                DiagnosticStore.add(this, "${stamp()} | HOME_SHORTCUT_SCAN | launcher=$launcherPackage | label=$target | matches=0 | retry_on_next_launcher_event=true")
            }
        } finally {
            candidates.forEach { try { it.recycle() } catch (_: Exception) {} }
            try { root.recycle() } catch (_: Exception) {}
        }
    }

    private fun collectMatchingNodes(node: AccessibilityNodeInfo, target: String, out: MutableList<AccessibilityNodeInfo>, depth: Int) {
        if (depth > 18 || out.size > 12) return
        val text = node.text?.toString().orEmpty().trim()
        val desc = node.contentDescription?.toString().orEmpty().trim()
        fun matches(value: String): Boolean {
            if (value.length < 3) return false
            val a = value.lowercase(Locale.ROOT).replace("…", "").replace("...", "").trim()
            val b = target.trim().lowercase(Locale.ROOT).replace("…", "").replace("...", "").trim()
            return a == b || (a.startsWith(b) && b.length >= 4) || (b.startsWith(a) && a.length >= 5)
        }
        if (matches(text) || matches(desc)) out.add(AccessibilityNodeInfo.obtain(node))
        for (i in 0 until node.childCount) {
            val child = try { node.getChild(i) } catch (_: Exception) { null } ?: continue
            try { collectMatchingNodes(child, target, out, depth + 1) } finally { try { child.recycle() } catch (_: Exception) {} }
        }
    }

    private fun findClickableAncestor(start: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var node: AccessibilityNodeInfo? = AccessibilityNodeInfo.obtain(start)
        repeat(6) {
            val current = node ?: return null
            if (current.isClickable) return current
            val parent = try { current.parent } catch (_: Exception) { null }
            try { current.recycle() } catch (_: Exception) {}
            node = parent
        }
        node?.let { try { it.recycle() } catch (_: Exception) {} }
        return null
    }

    private fun runningProcessReport(): String {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val running = am.runningAppProcesses.orEmpty()
        if (running.isEmpty()) return "runningProcesses=not_visible_or_empty"
        val whatsapp = running.filter { it.processName.contains("com.whatsapp") }
        return if (whatsapp.isEmpty()) "runningProcesses=WhatsApp_process_not_exposed (visible=${running.size})"
        else "runningProcesses=" + whatsapp.joinToString(";") { "${it.processName}:uid=${it.uid}:importance=${it.importance}" }
    }

    private fun describeWindows(): String {
        val entries = windows.orEmpty().take(8).map { w: AccessibilityWindowInfo ->
            val root = try { w.root } catch (_: Exception) { null }
            val rootPkg = root?.packageName?.toString() ?: "?"
            val rootClass = root?.className?.toString() ?: "?"
            val display = if (Build.VERSION.SDK_INT >= 30) w.displayId else -1
            val description = "${w.id}:${w.type}:active=${w.isActive}:focused=${w.isFocused}:display=$display:$rootPkg/$rootClass"
            root?.recycle()
            description
        }
        return "windows=[${entries.joinToString(";")}]"
    }

    /** Local timestamp helper for automatic diagnostic journal entries. */
    private fun stamp(): String = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault()).format(Date())

    override fun onInterrupt() = Unit
}
