package ru.tsautoreport.diagnostic

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.ComponentName
import android.content.ClipboardManager
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.content.pm.LauncherApps
import android.content.pm.ShortcutInfo
import android.os.Bundle
import android.app.AlarmManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import android.view.accessibility.AccessibilityManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    private val launcherApps by lazy { getSystemService(Context.LAUNCHER_APPS_SERVICE) as LauncherApps }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DiagnosticStore.add(this, "${stamp()} | APP_BUILD_ID | id=TS-BIND-019 | version=0.19-ts-scheduled-draft-test | versionCode=21")
        recordBootAndPersistenceCheck()
        val savedHome = HomeShortcutStore.state(this)
        DiagnosticStore.add(this, "${stamp()} | HOME_SHORTCUT_CONFIG_LOADED | label=${savedHome.label} | cloneConfirmed=${savedHome.cloneConfirmed} | pending=${savedHome.pending} | lastResult=${savedHome.lastResult}")
        ProfileBindingStore.verifyLoaded(this)
        setContent { Screen() }
    }

    override fun onResume() {
        super.onResume()
        DiagnosticStore.add(this, "${stamp()} | APP_RESUMED | bootCount=${currentBootCount()}")
    }

    /** The first app launch after a device reboot compares Android's BOOT_COUNT with the prior launch. */
    private fun recordBootAndPersistenceCheck() {
        val bootCount = currentBootCount()
        val prefs = getSharedPreferences("boot_audit_store", Context.MODE_PRIVATE)
        val previous = prefs.getInt("last_boot_count", -1)
        when {
            bootCount < 0 -> DiagnosticStore.add(this, "${stamp()} | BOOT_COUNT_UNAVAILABLE | reboot_test_cannot_be_verified")
            previous < 0 -> DiagnosticStore.add(this, "${stamp()} | BOOT_BASELINE_SET | bootCount=$bootCount | next_launch_after_reboot_will_be_checked=true")
            previous != bootCount -> {
                DiagnosticStore.add(this, "${stamp()} | DEVICE_REBOOT_DETECTED | previousBootCount=$previous | currentBootCount=$bootCount")
                val result = ProfileBindingStore.verifyLoaded(this)
                DiagnosticStore.add(this, "${stamp()} | BIND_LOAD_AFTER_REBOOT_${if (result.first) "VERIFIED" else "FAILED"} | count=${result.second} | bootCount=$bootCount")
            }
            else -> DiagnosticStore.add(this, "${stamp()} | SAME_BOOT_SESSION | bootCount=$bootCount | previousBootCount=$previous")
        }
        if (bootCount >= 0) prefs.edit().putInt("last_boot_count", bootCount).commit()
    }

    private fun currentBootCount(): Int = try {
        Settings.Global.getInt(contentResolver, Settings.Global.BOOT_COUNT, -1)
    } catch (_: Exception) { -1 }

    @Composable private fun Screen() {
        var enabled by remember { mutableStateOf(isServiceEnabled()) }
        var logs by remember { mutableStateOf(DiagnosticStore.read(this@MainActivity)) }
        var entries by remember { mutableStateOf<List<ProfileAudit.Entry>>(emptyList()) }
        var status by remember { mutableStateOf("Сначала проведи аудит профилей, затем привяжи тестовый чат.") }
        var auditDone by remember { mutableStateOf(false) }
        var label by remember { mutableStateOf("") }
        var observation by remember { mutableStateOf(ProfileBindingStore.observation(this@MainActivity)) }
        var bindings by remember { mutableStateOf(ProfileBindingStore.bindings(this@MainActivity)) }
        var bindingsLoaded by remember { mutableStateOf(ProfileBindingStore.verifyLoaded(this@MainActivity)) }
        var pending by remember { mutableStateOf(ProfileBindingStore.pending(this@MainActivity)) }
        var editingRow by remember { mutableStateOf<String?>(null) }
        var editingLabel by remember { mutableStateOf("") }
        var shortcutResults by remember { mutableStateOf<Map<String, List<ShortcutInfo>>>(emptyMap()) }
        var shortcutStatus by remember { mutableStateOf("Для точного запуска чата нужны ярлыки переписок WhatsApp. Сначала создай ярлык нужного чата в самом WhatsApp.") }
        var shortcutBindings by remember { mutableStateOf(ShortcutBindingStore.bindings(this@MainActivity)) }
        var shortcutHostPermission by remember { mutableStateOf(launcherApps.hasShortcutHostPermission()) }
        var methodRows by remember { mutableStateOf(ShortcutMethodAudit.load(this@MainActivity)) }
        var homeShortcutLabel by remember { mutableStateOf(HomeShortcutStore.state(this@MainActivity).label.ifBlank { "Я Билайн Нов" }) }
        var homeShortcutResult by remember { mutableStateOf(HomeShortcutStore.state(this@MainActivity).lastResult) }
        var cloneIconConfirmed by remember { mutableStateOf(HomeShortcutStore.state(this@MainActivity).cloneConfirmed) }
        var methodStatus by remember { mutableStateOf(if (ShortcutMethodAudit.load(this@MainActivity).isEmpty()) "Проверка методов ещё не запускалась." else "Загружены результаты предыдущей проверки. После закрытия приложения/перезагрузки они сохранены.") }
        var draftTestTime by remember { mutableStateOf("12:30") }
        var draftTestStatus by remember { mutableStateOf(if (ScheduledTestStore.active(this@MainActivity)) "Запланирован запуск: ${Date(ScheduledTestStore.scheduledAt(this@MainActivity))}" else "Тест не запланирован.") }

        fun refresh() {
            enabled = isServiceEnabled()
            logs = DiagnosticStore.read(this@MainActivity)
            observation = ProfileBindingStore.observation(this@MainActivity)
            bindings = ProfileBindingStore.bindings(this@MainActivity)
            bindingsLoaded = ProfileBindingStore.verifyLoaded(this@MainActivity)
            pending = ProfileBindingStore.pending(this@MainActivity)
            shortcutBindings = ShortcutBindingStore.bindings(this@MainActivity)
            shortcutHostPermission = launcherApps.hasShortcutHostPermission()
            methodRows = ShortcutMethodAudit.load(this@MainActivity)
            homeShortcutResult = HomeShortcutStore.state(this@MainActivity).lastResult
            homeShortcutLabel = HomeShortcutStore.state(this@MainActivity).label.ifBlank { homeShortcutLabel }
            cloneIconConfirmed = HomeShortcutStore.state(this@MainActivity).cloneConfirmed
        }
        fun launchSavedCloneChat() {
            val saved = HomeShortcutStore.state(this@MainActivity)
            if (!saved.cloneConfirmed || saved.label.length < 3) {
                homeShortcutResult = "Сначала сохрани подпись и подтверди, что иконка относится к клону с синей меткой."
                DiagnosticStore.add(this@MainActivity, "${stamp()} | HOME_SHORTCUT_RELAUNCH_BLOCKED | cloneConfirmed=${saved.cloneConfirmed} | labelLength=${saved.label.length}")
                refresh()
                return
            }
            val requested = HomeShortcutStore.request(this@MainActivity)
            DiagnosticStore.add(this@MainActivity, "${stamp()} | HOME_SHORTCUT_RELAUNCH_FROM_APP | label=${saved.label} | cloneOnly=true | requested=$requested")
            if (requested) {
                homeShortcutResult = "Открываем главный экран и ищем сохранённую иконку клона: ${saved.label}"
                try {
                    val navigated = WhatsAppAccessibilityService.requestHomeNavigation()
                    DiagnosticStore.add(this@MainActivity, "${stamp()} | HOME_NAVIGATION_REQUEST | accessibilityServiceAvailable=$navigated | method=GLOBAL_ACTION_HOME")
                    if (!navigated) {
                        HomeShortcutStore.finish(this@MainActivity, "ACCESSIBILITY_HOME_ACTION_UNAVAILABLE", 0, false)
                        homeShortcutResult = "Служба специальных возможностей недоступна. Включи TS AutoReport в настройках Accessibility и повтори запуск."
                    } else {
                        homeShortcutResult = "Закрываем меню и возвращаемся на рабочий стол. Ищем иконку клона до 45 секунд."
                    }
                } catch (e: Exception) {
                    HomeShortcutStore.finish(this@MainActivity, "HOME_LAUNCH_FAILED_${e.javaClass.simpleName}")
                    homeShortcutResult = "Не удалось открыть главный экран: ${e.message}"
                }
            } else homeShortcutResult = "Не удалось создать запрос запуска. Проверь сохранённую подпись и подтверждение клона."
            refresh()
        }

        fun audit() {
            try {
                entries = ProfileAudit.discover(this@MainActivity)
                auditDone = true
                val processReport = ProfileAudit.runningProcessReport(this@MainActivity, entries)
                val now = stamp()
                DiagnosticStore.add(this@MainActivity, "$now | PROFILE_API_AUDIT | count=${entries.size} | $processReport")
                entries.forEach { e ->
                    DiagnosticStore.add(this@MainActivity, "$now | PROFILE_ENTRY | user=${e.user} | serial=${e.serial} | uid=${e.uid} | pkg=${e.packageName} | process=${e.processName} | version=${e.versionName}/${e.versionCode} | component=${e.component} | sourceDir=${e.sourceDir}")
                }
                status = if (entries.isEmpty()) "LauncherApps не вернул доступных точек запуска WhatsApp."
                else "Найдено ${entries.size} точек запуска. UID/serial различают записи профилей, но не удостоверяют источник Accessibility-события."
                refresh()
            } catch (e: Exception) {
                auditDone = true
                status = "Ошибка публичного API: ${e.javaClass.simpleName}: ${e.message ?: "без подробностей"}"
                DiagnosticStore.add(this@MainActivity, "${stamp()} | PROFILE_API_AUDIT_ERROR | $status")
                refresh()
            }
        }
        fun startBinding(entry: ProfileAudit.Entry) {
            try {
                val component = ComponentName.unflattenFromString(entry.component)
                    ?: throw IllegalStateException("Некорректный компонент запуска")
                val user = launcherApps.profiles.firstOrNull { it.toString() == entry.user }
                    ?: throw IllegalStateException("Профиль больше не доступен; обнови аудит")
                val startedAt = System.currentTimeMillis()
                ProfileBindingStore.begin(this@MainActivity, ProfileBindingStore.Session(entry.user, entry.serial, entry.uid, entry.component, startedAt))
                launcherApps.startMainActivity(component, user, null, Bundle())
                Toast.makeText(this@MainActivity, "WhatsApp запущен. Открой нужный чат, затем вернись сюда.", Toast.LENGTH_LONG).show()
                refresh()
            } catch (e: Exception) {
                ProfileBindingStore.cancel(this@MainActivity)
                Toast.makeText(this@MainActivity, "Не удалось запустить: ${e.message}", Toast.LENGTH_LONG).show()
                refresh()
            }
        }
        fun discoverChatShortcuts(entry: ProfileAudit.Entry) {
            DiagnosticStore.add(this@MainActivity, "${stamp()} | ACTION_SHORTCUT_DISCOVERY_REQUESTED | user=${entry.user} | serial=${entry.serial} | uid=${entry.uid}")
            try {
                shortcutHostPermission = launcherApps.hasShortcutHostPermission()
                if (!shortcutHostPermission) {
                    shortcutResults = shortcutResults + (entry.user to emptyList())
                    shortcutStatus = "Поиск недоступен: Android разрешает читать ярлыки только приложению-лаунчеру по умолчанию или активному голосовому помощнику. TS AutoReport не является лаунчером, поэтому Android блокирует LauncherApps.getShortcuts. Это системное ограничение, а не ошибка привязки или WhatsApp. Не меняй лаунчер телефона ради этого теста."
                    DiagnosticStore.add(this@MainActivity, "${stamp()} | SHORTCUT_HOST_PERMISSION_DENIED | hasShortcutHostPermission=false | user=${entry.user} | action=QUERY_SKIPPED")
                    refresh()
                    return
                }
                val user = launcherApps.profiles.firstOrNull { it.toString() == entry.user }
                    ?: throw IllegalStateException("Профиль больше не доступен")
                val query = LauncherApps.ShortcutQuery()
                    .setPackage("com.whatsapp")
                    .setQueryFlags(LauncherApps.ShortcutQuery.FLAG_MATCH_DYNAMIC or LauncherApps.ShortcutQuery.FLAG_MATCH_PINNED or LauncherApps.ShortcutQuery.FLAG_MATCH_MANIFEST)
                val found = launcherApps.getShortcuts(query, user).orEmpty()
                shortcutResults = shortcutResults + (entry.user to found)
                shortcutStatus = if (found.isEmpty()) "Доступ к ярлыкам разрешён, но WhatsApp не вернул ярлыки для ${entry.user}." else "Найдено ярлыков в ${entry.user}: ${found.size}. Выбери нужную переписку ниже."
                DiagnosticStore.add(this@MainActivity, "${stamp()} | CHAT_SHORTCUT_DISCOVERY | user=${entry.user} | count=${found.size} | ids=${found.joinToString(",") { it.id }}")
            } catch (e: Exception) {
                shortcutStatus = "Ошибка чтения ярлыков: ${e.javaClass.simpleName}: ${e.message}"
                DiagnosticStore.add(this@MainActivity, "${stamp()} | CHAT_SHORTCUT_DISCOVERY_FAILED | user=${entry.user} | error=${e.javaClass.simpleName}:${e.message}")
            }
            refresh()
        }

        fun copyFullReport() {
            DiagnosticStore.add(this@MainActivity, "${stamp()} | ACTION_COPY_FULL_REPORT | requested=true")
            val report = buildString {
                appendLine("TS AutoReport — полный диагностический отчёт")
                appendLine("BUILD ID: TS-BIND-019")
                appendLine("Версия: 0.19-ts-scheduled-draft-test · versionCode=21")
                appendLine("Тест черновика запланирован: ${ScheduledTestStore.active(this@MainActivity)} · время=${ScheduledTestStore.scheduledAt(this@MainActivity)}")
                appendLine("Устройство: ${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}")
                appendLine("Android API: ${android.os.Build.VERSION.SDK_INT} · release=${android.os.Build.VERSION.RELEASE}")
                appendLine("Accessibility включена: ${isServiceEnabled()}")
                appendLine("LauncherApps.hasShortcutHostPermission: ${launcherApps.hasShortcutHostPermission()}")
                appendLine("BOOT_COUNT: ${currentBootCount()}")
                appendLine("\nНайденные экземпляры WhatsApp:")
                if (entries.isEmpty()) appendLine("Аудит в этой сессии ещё не выполнен.")
                entries.forEach { e -> appendLine("${e.user} | serial=${e.serial} | uid=${e.uid} | package=${e.packageName} | version=${e.versionName}/${e.versionCode} | component=${e.component}") }
                appendLine("\nСтатус аудита: $status")
                appendLine("Статус ярлыков: $shortcutStatus")
                appendLine("\nЯрлык главного экрана: label=${HomeShortcutStore.state(this@MainActivity).label} | pending=${HomeShortcutStore.state(this@MainActivity).pending} | result=${HomeShortcutStore.state(this@MainActivity).lastResult}")
                appendLine("\nМатрица методов поиска/запуска:")
                appendLine("$methodStatus")
                methodRows.forEach { appendLine("${it.title} | ${it.status} | ${it.detail} | exactChatLaunch=${it.exactChatLaunch}") }
                appendLine("\nРезультаты поиска ярлыков:")
                if (shortcutResults.isEmpty()) appendLine("Поиск ещё не выполнялся.")
                shortcutResults.forEach { (user, items) -> appendLine("$user: ${items.size} ярлыков") ; items.forEach { appendLine("  label=${it.shortLabel} | id=${it.id} | package=${it.`package`}") } }
                appendLine("\nРучные привязки:")
                if (bindings.isEmpty()) appendLine("Нет сохранённых ручных привязок.")
                bindings.forEach { row -> appendLine(row.replace('\t', '|')) }
                appendLine("\nКнопки ярлыков:")
                if (shortcutBindings.isEmpty()) appendLine("Нет сохранённых Android shortcut bindings.")
                shortcutBindings.forEach { row -> appendLine(row.replace('\t', '|')) }
                appendLine("\nПроверка загрузки привязок: success=${bindingsLoaded.first} · count=${bindingsLoaded.second}")
                appendLine("\nВнутренний журнал (старые → новые):")
                DiagnosticStore.readAllChronological(this@MainActivity).forEach { appendLine(it) }
                appendLine("\nПримечание: содержимое переписок и сообщения не считываются и в отчёт не включаются.")
            }
            val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("TS AutoReport diagnostics", report))
            Toast.makeText(this@MainActivity, "Полный отчёт скопирован. Вставь его сюда.", Toast.LENGTH_LONG).show()
            logs = DiagnosticStore.read(this@MainActivity)
        }
        fun saveChatShortcut(entry: ProfileAudit.Entry, shortcut: ShortcutInfo) {
            val ok = ShortcutBindingStore.save(this@MainActivity, entry.user, entry.serial, entry.uid, shortcut.id, shortcut.shortLabel?.toString() ?: shortcut.id)
            shortcutStatus = if (ok) "Кнопка привязана к ярлыку «${shortcut.shortLabel}» для ${entry.user}." else "Не удалось сохранить привязку ярлыка."
            refresh()
        }
        fun launchSavedShortcut(row: String) {
            try {
                val b = ShortcutBindingStore.parse(row) ?: throw IllegalStateException("Повреждена запись кнопки")
                if (!launcherApps.hasShortcutHostPermission()) throw SecurityException("Android не разрешает этому приложению запускать чужие ярлыки: нет права хоста shortcuts")
                val user = launcherApps.profiles.firstOrNull { it.toString() == b.user } ?: throw IllegalStateException("Профиль WhatsApp недоступен")
                launcherApps.startShortcut("com.whatsapp", b.shortcutId, null, Bundle(), user)
                DiagnosticStore.add(this@MainActivity, "${stamp()} | CHAT_SHORTCUT_LAUNCHED | label=${b.label} | user=${b.user} | shortcutId=${b.shortcutId}")
                shortcutStatus = "Команда запуска ярлыка «${b.label}» передана Android для ${b.user}. Проверь, открылся ли нужный чат."
            } catch (e: Exception) {
                shortcutStatus = "Не удалось открыть чат: ${e.javaClass.simpleName}: ${e.message}"
                DiagnosticStore.add(this@MainActivity, "${stamp()} | CHAT_SHORTCUT_LAUNCH_FAILED | error=$shortcutStatus")
            }
            refresh()
        }
        fun confirmBinding() {
            DiagnosticStore.add(this@MainActivity, "${stamp()} | ACTION_CONFIRM_MANUAL_BINDING | label=${label.replace('\n', ' ').replace('\t', ' ')} | pressed=true")
            val ok = ProfileBindingStore.confirm(this@MainActivity, label)
            status = if (ok) "Запись сохранена и проверена повторным чтением. Это не доказательство источника профиля." else "Не удалось подтвердить сохранение. Проверь журнал и повтори привязку только после нового запуска."
            if (ok) label = ""
            refresh()
        }

        MaterialTheme {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("TS AutoReport", style = MaterialTheme.typography.headlineLarge)
                Text("Версия 0.19 — тест запуска по времени и ввода черновика", style = MaterialTheme.typography.titleMedium)
                Text("BUILD ID: TS-BIND-019 · versionCode 21", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                Text("Проверка v0.12 выявила системное ограничение Android: читать ярлыки приложений через LauncherApps может только лаунчер по умолчанию или активный голосовой помощник. TS AutoReport не запрашивает и не может самостоятельно получить это право. Поэтому приложение теперь проверяет разрешение заранее, не вызывает API при запрете и показывает точную причину. Не меняй домашний лаунчер телефона ради этого теста.")
                Text("Доступ к ярлыкам Android: ${if (shortcutHostPermission) "разрешён" else "запрещён для обычного приложения"}", color = if (shortcutHostPermission) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                Button(onClick = { copyFullReport() }) { Text("Скопировать весь текст приложения") }
                Text(if (enabled) "Accessibility включена" else "Accessibility выключена", color = if (enabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                Button(onClick = { DiagnosticStore.add(this@MainActivity, "${stamp()} | ACTION_OPEN_ACCESSIBILITY_SETTINGS | pressed=true"); startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }) { Text("Открыть специальные возможности") }
                Button(onClick = { DiagnosticStore.add(this@MainActivity, "${stamp()} | ACTION_REFRESH_STATUS | pressed=true"); refresh() }) { Text("Обновить статус и журнал") }
                HorizontalDivider()
                Text("1. Найти экземпляры", style = MaterialTheme.typography.titleLarge)
                Button(onClick = { DiagnosticStore.add(this@MainActivity, "${stamp()} | ACTION_PROFILE_AUDIT | pressed=true"); audit() }) { Text("Провести аудит профилей и UID") }
                Text(status, style = MaterialTheme.typography.bodySmall)
                if (auditDone && entries.isEmpty()) Text("Экземпляры не обнаружены.", color = MaterialTheme.colorScheme.error)
                entries.forEachIndexed { index, e ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                            Text("Экземпляр ${index + 1}", style = MaterialTheme.typography.titleMedium)
                            Text("UserHandle: ${e.user} · Serial: ${e.serial} · UID: ${e.uid}")
                            Text("${e.packageName} · ${e.versionName} · ${e.component}", style = MaterialTheme.typography.bodySmall)
                            Button(
                                onClick = { DiagnosticStore.add(this@MainActivity, "${stamp()} | ACTION_OPEN_WHATSAPP_INSTANCE | user=${e.user} | pressed=true"); startBinding(e) },
                                enabled = e.user == "UserHandle{95}"
                            ) { Text(if (e.user == "UserHandle{95}") "Открыть клон WhatsApp для теста" else "Основной WhatsApp отключён для тестов") }
                            OutlinedButton(onClick = { discoverChatShortcuts(e) }, enabled = shortcutHostPermission) { Text("Найти ярлыки чатов этого WhatsApp") }
                            shortcutResults[e.user].orEmpty().forEach { shortcut ->
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(shortcut.shortLabel?.toString() ?: shortcut.id, modifier = Modifier.weight(1f))
                                    TextButton(onClick = { saveChatShortcut(e, shortcut) }) { Text("Привязать к кнопке") }
                                }
                            }
                        }
                    }
                }
                Text(shortcutStatus, style = MaterialTheme.typography.bodySmall)
                HorizontalDivider()
                Text("2. Матрица методов поиска и запуска ярлыка", style = MaterialTheme.typography.titleLarge)
                Text("Проверяются независимые публичные механизмы. Приложение не назначает себя лаунчером, не меняет профиль по умолчанию и не трогает основной WhatsApp.")
                Button(onClick = {
                    DiagnosticStore.add(this@MainActivity, "${stamp()} | ACTION_RUN_SHORTCUT_METHOD_MATRIX | cloneOnly=true")
                    val clone = launcherApps.profiles.firstOrNull { it.toString() == "UserHandle{95}" }
                    if (clone == null) {
                        methodStatus = "Профиль клона UserHandle{95} не найден. Проверки чтения ярлыков не запускались."
                        DiagnosticStore.add(this@MainActivity, "${stamp()} | METHOD_MATRIX_ABORTED | reason=clone_profile_missing")
                    } else {
                        methodRows = ShortcutMethodAudit.run(this@MainActivity, launcherApps, clone)
                        if (launcherApps.hasShortcutHostPermission()) {
                            try {
                                val query = LauncherApps.ShortcutQuery().setPackage("com.whatsapp")
                                    .setQueryFlags(LauncherApps.ShortcutQuery.FLAG_MATCH_DYNAMIC or LauncherApps.ShortcutQuery.FLAG_MATCH_PINNED or LauncherApps.ShortcutQuery.FLAG_MATCH_MANIFEST)
                                val discovered = launcherApps.getShortcuts(query, clone).orEmpty()
                                shortcutResults = shortcutResults + (clone.toString() to discovered)
                                DiagnosticStore.add(this@MainActivity, "${stamp()} | MATRIX_SHORTCUTS_READY_FOR_MANUAL_BIND | clone=$clone | count=${discovered.size}")
                            } catch (e: Exception) {
                                DiagnosticStore.add(this@MainActivity, "${stamp()} | MATRIX_SHORTCUTS_UI_LOAD_FAILED | ${e.javaClass.simpleName}:${e.message}")
                            }
                        }
                        methodStatus = "Проверено методов: ${methodRows.size}. Результаты сохранены и переживут закрытие приложения и перезагрузку. Если найден WhatsApp shortcut, выбери его в списке выше и привяжи к кнопке."
                    }
                    refresh()
                }) { Text("Проверить все методы для клона") }
                Text(methodStatus, style = MaterialTheme.typography.bodySmall)
                methodRows.forEach { row ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(row.title, style = MaterialTheme.typography.titleSmall)
                            Text(row.status, color = when { row.exactChatLaunch -> MaterialTheme.colorScheme.primary; row.status.startsWith("ОШИБКА") || row.status.startsWith("ЗАБЛОКИРОВАНО") -> MaterialTheme.colorScheme.error; else -> MaterialTheme.colorScheme.onSurfaceVariant })
                            Text(row.detail, style = MaterialTheme.typography.bodySmall)
                            Text(if (row.exactChatLaunch) "Может открыть конкретный чат" else "Не подтверждает запуск конкретного чата", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
                Text("Результаты матрицы сохраняются локально. После закрытия приложения и перезагрузки повторный отчёт покажет те же результаты и события повторного запуска.", style = MaterialTheme.typography.bodySmall)
                HorizontalDivider()
                Text("3. Запуск уже созданной иконки чата с главного экрана", style = MaterialTheme.typography.titleLarge)
                Text("Новый метод не извлекает закрытый shortcutId. Он использует Accessibility для поиска видимой подписи ярлыка на домашнем экране и нажатия по ней. Сначала убедись, что на рабочем столе находится именно иконка клона WhatsApp (с синей меткой Dual Messenger), а не основного WhatsApp. При нескольких совпадениях приложение ничего не нажмёт.", style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(value = homeShortcutLabel, onValueChange = { homeShortcutLabel = it.take(80) }, label = { Text("Подпись иконки на рабочем столе") }, placeholder = { Text("Например: Я Билайн Нов") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Checkbox(checked = cloneIconConfirmed, onCheckedChange = { cloneIconConfirmed = it })
                    Text("Подтверждаю: совпадающая иконка — именно клон с синей меткой Dual Messenger")
                }
                Button(onClick = {
                    DiagnosticStore.add(this@MainActivity, "${stamp()} | HOME_SHORTCUT_CLONE_CONFIRMATION | confirmed=$cloneIconConfirmed")
                    val confirmedSaved = HomeShortcutStore.setCloneConfirmed(this@MainActivity, cloneIconConfirmed)
                    val saved = HomeShortcutStore.setLabel(this@MainActivity, homeShortcutLabel)
                    val requested = confirmedSaved && saved && HomeShortcutStore.request(this@MainActivity)
                    if (requested) {
                        homeShortcutResult = "Сохранено. Запускаю единую последовательность: закрыть меню → дождаться рабочего стола → нажать ярлык клона."
                        val navigated = WhatsAppAccessibilityService.requestHomeNavigation()
                        DiagnosticStore.add(this@MainActivity, "${stamp()} | HOME_NAVIGATION_REQUEST | accessibilityServiceAvailable=$navigated | method=GLOBAL_ACTION_HOME_THEN_UNIQUE_ICON_SCAN")
                        if (!navigated) {
                            HomeShortcutStore.finish(this@MainActivity, "ACCESSIBILITY_HOME_ACTION_UNAVAILABLE", 0, false)
                            homeShortcutResult = "Служба специальных возможностей недоступна. Включи TS AutoReport в настройках Accessibility."
                        }
                    } else homeShortcutResult = "Не удалось сохранить подпись или подтверждение клона"
                    refresh()
                }, enabled = enabled && cloneIconConfirmed && homeShortcutLabel.trim().length >= 3) { Text("Открыть главный экран и нажать ярлык клона") }
                Text("Последний результат: $homeShortcutResult", style = MaterialTheme.typography.bodySmall)
                Text("Защита: кнопка неактивна, пока ты не подтвердишь синюю метку клона. Программа не может прочитать Android UserHandle из иконки домашнего экрана. Успешный ACTION_CLICK ещё не доказывает правильный профиль или чат — обязательно проверь открывшуюся переписку глазами. Если ярлык не найден, проверь подпись и пришли полный отчёт.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                HorizontalDivider()
                Text("Быстрый запуск сохранённого чата клона", style = MaterialTheme.typography.titleLarge)
                val savedHome = HomeShortcutStore.state(this@MainActivity)
                if (savedHome.label.isNotBlank() && savedHome.cloneConfirmed) {
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(savedHome.label, style = MaterialTheme.typography.titleMedium)
                            Text("WhatsApp Dual Messenger · запуск через сохранённую иконку Samsung", style = MaterialTheme.typography.bodySmall)
                            Text("Подтверждение клона сохранено. После перезапуска телефона достаточно открыть TS AutoReport и нажать кнопку ниже.", style = MaterialTheme.typography.bodySmall)
                            Button(onClick = { launchSavedCloneChat() }, enabled = enabled, modifier = Modifier.fillMaxWidth()) {
                                Text("Открыть сохранённый чат")
                            }
                            Text("Последний результат: ${savedHome.lastResult}", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                } else {
                    Text("Сначала один раз сохрани подпись и подтверди синюю метку клона в разделе выше. После этого здесь появится постоянная кнопка запуска.", style = MaterialTheme.typography.bodySmall)
                }
                HorizontalDivider()
                Text("ТЕСТ ПО РАСПИСАНИЮ — ТОЛЬКО ЧЕРНОВИК", style = MaterialTheme.typography.titleLarge)
                Text("В выбранное время приложение проверит экран, разбудит его при необходимости, попробует убрать только свайп-блокировку, откроет сохранённый ярлык клона и введёт «проверка». Отправка сообщения запрещена. При PIN/пароле/графическом ключе тест остановится. При включённом изначально экране он останется включённым; при выключенном — после ввода приложение попробует заблокировать экран.", style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(value = draftTestTime, onValueChange = { draftTestTime = it.filter { ch -> ch.isDigit() || ch == ':' }.take(5) }, label = { Text("Время запуска (ЧЧ:ММ, местное)") }, placeholder = { Text("Например: 12:45") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Button(onClick = {
                    try {
                        val alarm = getSystemService(Context.ALARM_SERVICE) as AlarmManager
                        if (Build.VERSION.SDK_INT >= 31 && !alarm.canScheduleExactAlarms()) {
                            DiagnosticStore.add(this@MainActivity, "${stamp()} | ACTION_REQUEST_EXACT_ALARM_PERMISSION | requested=true")
                            startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
                            draftTestStatus = "Разреши точные будильники для TS AutoReport, вернись и нажми запланировать ещё раз."
                        } else {
                            val at = ScheduledTestStore.schedule(this@MainActivity, draftTestTime)
                            draftTestStatus = "Запланировано на ${SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date(at))}"
                        }
                    } catch (e: Exception) {
                        draftTestStatus = "Не удалось запланировать: ${e.javaClass.simpleName}: ${e.message}"
                        DiagnosticStore.add(this@MainActivity, "${stamp()} | DRAFT_TEST_SCHEDULE_FAILED | error=${e.javaClass.simpleName}:${e.message}")
                    }
                    refresh()
                }, enabled = enabled && cloneIconConfirmed && homeShortcutLabel.trim().length >= 3, modifier = Modifier.fillMaxWidth()) { Text("Запланировать тест «проверка»") }
                OutlinedButton(onClick = { ScheduledTestStore.cancel(this@MainActivity); draftTestStatus = "Тест отменён."; refresh() }, modifier = Modifier.fillMaxWidth()) { Text("Отменить запланированный тест") }
                Text(draftTestStatus, style = MaterialTheme.typography.bodySmall)
                Text("Перед первым запуском проверь, что сохранённый ярлык всё ещё ведёт именно в тестовый чат клона. Для двух проверок назначай два разных времени: сначала с включённым экраном, затем с выключенным. После каждого запуска смотри журнал и сам чат. Приложение не подтверждает доставку и не читает текст переписки.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                HorizontalDivider()
                Text("Кнопки запуска сохранённых Android shortcuts", style = MaterialTheme.typography.titleLarge)
                if (shortcutBindings.isEmpty()) Text("Пока нет привязанных ярлыков чатов.")
                shortcutBindings.forEach { saved ->
                    val b = ShortcutBindingStore.parse(saved)
                    if (b != null) Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(b.label, style = MaterialTheme.typography.titleMedium)
                            Text(if (b.user == "UserHandle{0}") "Основной WhatsApp" else if (b.user == "UserHandle{95}") "WhatsApp Dual Messenger (клон)" else b.user)
                            Button(onClick = { launchSavedShortcut(saved) }) { Text("Открыть этот чат") }
                            TextButton(onClick = { ShortcutBindingStore.delete(this@MainActivity, saved); refresh() }) { Text("Удалить кнопку") }
                        }
                    }
                }
                HorizontalDivider()
                Text("Диагностика ручной привязки (старый тест)", style = MaterialTheme.typography.titleLarge)
                Text("Секция ниже оставлена для диагностики Accessibility; для открытия конкретного чата используй ярлык и кнопку выше.")
                Text("2. Подтвердить именно открытый чат", style = MaterialTheme.typography.titleLarge)
                Text("После запуска WhatsApp найди нужного человека/группу и открой сам экран переписки. Не оставайся на списке чатов. Затем вернись сюда и нажми кнопку проверки.")
                val obs = observation
                if (pending != null) {
                    Text("Сессия ожидает подтверждения: ${pending!!.user} (UID ${pending!!.uid})")
                    Button(onClick = { DiagnosticStore.add(this@MainActivity, "${stamp()} | ACTION_VERIFY_OPEN_CHAT | user=${pending!!.user} | pressed=true"); refresh() }) { Text("2. Проверить, что нужная переписка открыта") }
                    if (obs != null && obs.eventAt >= pending!!.startedAt) {
                        Text("Экран переписки обнаружен. Теперь введи свою метку и подтверди привязку.", color = MaterialTheme.colorScheme.primary)
                        Text("Техническая запись: windowId=${obs.windowId} · ${Date(obs.eventAt)}", style = MaterialTheme.typography.bodySmall)
                    } else {
                        Text("Пока не обнаружен экран переписки. Вернись в WhatsApp, открой нужный чат и повтори проверку.", color = MaterialTheme.colorScheme.error)
                    }
                    OutlinedTextField(value = label, onValueChange = { label = it.take(80) }, label = { Text("Метка чата (введи сам)") }, placeholder = { Text("Например: Рабочая смена") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    Button(onClick = { confirmBinding() }, enabled = obs != null && obs.eventAt >= pending!!.startedAt && label.isNotBlank()) { Text("3. Сохранить этот чат") }
                    TextButton(onClick = { ProfileBindingStore.cancel(this@MainActivity); refresh() }) { Text("Отменить сессию") }
                } else {
                    Text("Активной сессии привязки нет.")
                }
                HorizontalDivider()
                Text("3. Мои сохранённые чаты", style = MaterialTheme.typography.titleLarge)
                val loadOk = bindingsLoaded.first
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Сохранено: ${bindings.size}", style = MaterialTheme.typography.titleMedium)
                    Text(if (loadOk) "Загрузка проверена" else "Проверка загрузки не пройдена", color = if (loadOk) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                }
                if (bindings.isEmpty()) Text("Пока нет подтверждённых привязок.")
                bindings.forEach { row ->
                    val p = row.split('\t')
                    val profileTitle = when (p.getOrNull(1)) {
                        "UserHandle{0}" -> "Основной WhatsApp"
                        "UserHandle{95}" -> "WhatsApp Dual Messenger (клон)"
                        else -> "WhatsApp — профиль не распознан"
                    }
                    val profileShort = when (p.getOrNull(1)) {
                        "UserHandle{0}" -> "Основной профиль Android"
                        "UserHandle{95}" -> "Профиль клона Samsung Dual Messenger"
                        else -> "Профиль Android: ${p.getOrNull(1) ?: "неизвестен"}"
                    }
                    val savedAt = p.getOrNull(6)?.toLongOrNull()?.let { SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date(it)) } ?: "неизвестно"
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(p.getOrNull(0) ?: "Чат без названия", style = MaterialTheme.typography.titleMedium)
                                Text("Сохранено", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelLarge)
                            }
                            Text(profileTitle, style = MaterialTheme.typography.bodyLarge)
                            Text(profileShort, style = MaterialTheme.typography.bodySmall)
                            Text("UID: ${p.getOrNull(3) ?: "—"} · Serial: ${p.getOrNull(2) ?: "—"}", style = MaterialTheme.typography.bodySmall)
                            Text("Время подтверждения: $savedAt", style = MaterialTheme.typography.bodySmall)
                            Text("Метка введена вручную; имя контакта WhatsApp не считывается.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                TextButton(onClick = { editingRow = row; editingLabel = p.getOrNull(0).orEmpty() }) { Text("Изменить название") }
                                TextButton(onClick = {
                                    val ok = ProfileBindingStore.deleteBinding(this@MainActivity, row)
                                    status = if (ok) "Привязка удалена и проверена." else "Не удалось проверить удаление."
                                    refresh()
                                }) { Text("Удалить") }
                            }
                        }
                    }
                }
                if (editingRow != null) {
                    AlertDialog(
                        onDismissRequest = { editingRow = null },
                        title = { Text("Изменить метку чата") },
                        text = { OutlinedTextField(value = editingLabel, onValueChange = { editingLabel = it.take(80) }, label = { Text("Новая метка") }, singleLine = true) },
                        confirmButton = { TextButton(onClick = {
                            val ok = ProfileBindingStore.updateLabel(this@MainActivity, editingRow!!, editingLabel)
                            status = if (ok) "Метка изменена, запись проверена." else "Не удалось сохранить изменение."
                            editingRow = null
                            refresh()
                        }) { Text("Сохранить") } },
                        dismissButton = { TextButton(onClick = { editingRow = null }) { Text("Отмена") } }
                    )
                }
                Text("Ограничение: метка чата вводится оператором; приложение не читает название чата. Событие Conversation после контролируемого запуска — полезный сигнал последовательности, но AccessibilityEvent не содержит UserHandle. Поэтому это ручная привязка, не независимое доказательство источника события и не разрешение на автоматическую отправку.", color = MaterialTheme.colorScheme.error)
                HorizontalDivider()
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Журнал", style = MaterialTheme.typography.titleLarge)
                    TextButton(onClick = { DiagnosticStore.clear(this@MainActivity); refresh() }) { Text("Очистить журнал") }
                }
                Text("Событий: ${logs.size}. Журнал хранится локально. Кнопка «Скопировать весь текст приложения» собирает состояние экранов и журнал в буфер обмена по твоему нажатию. Содержимое переписки не считывается.", style = MaterialTheme.typography.bodySmall)
                logs.forEach { Text(it, style = MaterialTheme.typography.bodySmall) }
            }
        }
    }

    private fun stamp() = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault()).format(Date())

    private fun isServiceEnabled(): Boolean {
        val manager = getSystemService(ACCESSIBILITY_SERVICE) as AccessibilityManager
        val expected = ComponentName(this, WhatsAppAccessibilityService::class.java)
        return manager.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            .any { it.resolveInfo.serviceInfo.let { info -> ComponentName(info.packageName, info.name) == expected } }
    }
}
