TS AutoReport v0.24.53
BUILD ID: TS-SEQUENTIAL-CHAT-SETUP-EDIT-02453
versionCode: 84

Setup order:
1. Add a chat with its exact desktop shortcut label.
2. Bind the chosen WhatsApp shortcut and confirm the opened conversation.
3. Press «Проверить ярлык», open the saved shortcut, and confirm the correct conversation again.
4. Select and save READ, SEND, or CHECK.
5. Add a time. SEND/CHECK then ask for a message; READ does not require one.

The «Ред.» action is visible immediately after chat creation and reopens the full setup. Changing the label invalidates the old binding and verification. Existing intervals/messages are retained.

Scheduling and runtime require both initial binding confirmation and separate shortcut verification.

This archive has only received static source review. No Gradle build, APK build, or physical-device test was performed.
