TS AutoReport v0.24.54
BUILD ID: TS-STATUS-PRESERVE-CHAT-UI-02454
versionCode: 85

This version preserves per-interval red/green status when chat selection is toggled, when schedules are stopped/restarted, and on unchanged saves. A fired interval becomes green again only when its own time or message text is edited and the changes are saved. The schedule reconciler still updates alarms for enabled/disabled chats.

The chat card disclosure control uses a circular background and in-place rotation. The interval row has a smaller circular chevron; its status dot remains at the same visual anchor for both green and red states and is shifted left to make room.

All prior v0.24.53 setup flow and shortcut verification steps are retained. Static review only; no Gradle build, APK build, or physical-device test was performed.
