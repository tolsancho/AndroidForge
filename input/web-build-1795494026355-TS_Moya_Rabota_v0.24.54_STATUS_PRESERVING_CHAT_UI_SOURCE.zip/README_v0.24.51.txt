TS Моя работа — исходники v0.24.51
BUILD ID: TS-MAIN-WHATSAPP-SHORTCUT-ANALOGY-02451
versionCode: 82
versionName: 0.24.51-main-whatsapp-shortcut-analogy

Основа — v0.24.49. Исправление касается только привязки ярлыка основного WhatsApp при отсутствии event.source у события клика. Для main допускается fallback на уникальную видимую плитку, захваченную в том же launcher-сеансе. Для clone прежняя схема с реальным event.source не менялась.

Полная append-only история: TS_Moya_Rabota_HISTORY_v0.24.51.txt и HISTORY_APPEND_ONLY.txt.
Сборка Gradle и проверка на устройстве не выполнялись.
