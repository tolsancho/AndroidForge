package ru.tsautoreport.diagnostic

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootRestoreReceiver:BroadcastReceiver(){ override fun onReceive(context:Context,intent:Intent?){ if(intent?.action==Intent.ACTION_BOOT_COMPLETED){ try{ if(ChatScheduleStore.all(context).any{it.enabled && it.confirmed && it.verified && it.behavior in setOf("READ","SEND","CHECK") && it.intervals.isNotEmpty()}) ScheduledTestStore.scheduleAll(context) }catch(e:Exception){ DiagnosticStore.add(context,"${java.util.Date()} | BOOT_RESTORE_FAILED | ${e.javaClass.simpleName}:${e.message}") } } } }
