package ru.tsautoreport.diagnostic

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log

/** Keeps the scheduled workflow visible to Android while a one-shot test is pending/running. */
class ScheduleKeepAliveService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private val stopRunnable = Runnable { stopWithStoppedStatus() }
    // Reassert the foreground notification once per minute while the workflow is active.
    // This is deliberately independent from the alarm-permission monitor: one-shot runs
    // can have no pending alarms while their Accessibility action is still executing.
    private var notificationGuardActive = false
    private val notificationGuard = object : Runnable {
        override fun run() {
            if (!notificationGuardActive) return
            try {
                val manager = getSystemService(NotificationManager::class.java)
                val notificationVisible = manager.activeNotifications.any { it.id == NOTIFICATION_ID }
                if (!notificationVisible) {
                    // Re-enter foreground with the same ID so Android restores the persistent
                    // service notification instead of creating a second notification.
                    startForeground(NOTIFICATION_ID, buildNotification(running = true))
                    DiagnosticStore.add(this@ScheduleKeepAliveService, "${stamp()} | NOTIFICATION_GUARD_RESTORED | id=$NOTIFICATION_ID")
                }
            } catch (e: Exception) {
                DiagnosticStore.add(this@ScheduleKeepAliveService, "${stamp()} | NOTIFICATION_GUARD_CHECK_FAILED | ${e.javaClass.simpleName}: ${e.message}")
            }
            if (notificationGuardActive) handler.postDelayed(this, NOTIFICATION_GUARD_INTERVAL_MS)
        }
    }
    private val permissionMonitor = object : Runnable {
        override fun run() {
            if (!ScheduledTestStore.active(this@ScheduleKeepAliveService)) return
            val problems = PermissionGate.status(this@ScheduleKeepAliveService).problems()
            if (problems.isNotEmpty()) {
                DiagnosticStore.add(this@ScheduleKeepAliveService, "${stamp()} | PERMISSION_GATE_RUNTIME_STOP | ${problems.joinToString(";")}")
                ScheduledTestStore.cancel(this@ScheduleKeepAliveService)
                PermissionGate.notifyBlocked(this@ScheduleKeepAliveService, problems)
                stopWithStoppedStatus()
                return
            }
            handler.postDelayed(this, 15_000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        // Remove a previously posted notification before reposting it on the no-badge channel.
        // This clears a stale launcher badge left by the legacy notification channel.
        getSystemService(NotificationManager::class.java).cancel(NOTIFICATION_ID)
        startForeground(NOTIFICATION_ID, buildNotification(running = true))
        DiagnosticStore.add(this, "${stamp()} | SCHEDULE_FOREGROUND_SERVICE_CREATED | foreground=true")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_RUN -> {
                DiagnosticStore.add(this, "${stamp()} | SCHEDULE_FOREGROUND_SERVICE_RUN | action=RUN | interval=${intent.getStringExtra(ScheduledTestStore.EXTRA_INTERVAL_ID).orEmpty()} chat=${intent.getStringExtra(ScheduledTestStore.EXTRA_CHAT_ID).orEmpty()}")
                handler.removeCallbacks(stopRunnable)
                handler.removeCallbacks(permissionMonitor)
                startNotificationGuard()
                handler.postDelayed(permissionMonitor, 15_000L)
                // Keep the notification state synchronized with the actual scheduler state.
                getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, buildNotification(running = true))
                val message = intent.getStringExtra(ScheduledTestStore.EXTRA_MESSAGE).orEmpty()
                val slot = intent.getStringExtra(ScheduledTestStore.EXTRA_INTERVAL_ID).orEmpty()
                val chatId = intent.getStringExtra(ScheduledTestStore.EXTRA_CHAT_ID).orEmpty()
                val behavior = intent.getStringExtra(ScheduledTestStore.EXTRA_BEHAVIOR).orEmpty().ifBlank { "SEND" }
                val dispatched = WhatsAppAccessibilityService.beginScheduledDraftTest(message, slot.hashCode(), chatId, behavior, slot)
                DiagnosticStore.add(this, "${stamp()} | SCHEDULE_FOREGROUND_SERVICE_ACCESSIBILITY_DISPATCH | available=$dispatched")
                if (!dispatched) DiagnosticStore.add(this, "${stamp()} | DRAFT_TEST_ABORTED | reason=ACCESSIBILITY_SERVICE_NOT_RUNNING")
                if (ScheduledTestStore.pendingCount(this) == 0) handler.postDelayed(stopRunnable, 60_000L)
            }
            ACTION_MONITOR -> {
                DiagnosticStore.add(this, "${stamp()} | SCHEDULE_FOREGROUND_SERVICE_MONITOR | scheduledAt=${ScheduledTestStore.scheduledAt(this)}")
                handler.removeCallbacks(stopRunnable)
                handler.removeCallbacks(permissionMonitor)
                val scheduleActive = ScheduledTestStore.active(this)
                if (scheduleActive) startNotificationGuard()
                handler.post(permissionMonitor)
                // Refresh the visible status after the scheduler has restored/confirmed
                // its active state. This also covers an already-existing service instance.
                getSystemService(NotificationManager::class.java)
                    .notify(NOTIFICATION_ID, buildNotification(running = scheduleActive))
            }
            ACTION_REFRESH -> {
                getSystemService(NotificationManager::class.java)
                    .notify(NOTIFICATION_ID, buildNotification(running = ScheduledTestStore.active(this)))
            }
            ACTION_STOP -> {
                handler.removeCallbacks(stopRunnable)
                handler.removeCallbacks(permissionMonitor)
                stopWithStoppedStatus()
            }
        }
        return START_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        // START_STICKY is the recovery hint; Android/OEM policy still controls process restart.
        DiagnosticStore.add(this, "${stamp()} | SCHEDULE_FOREGROUND_TASK_REMOVED | sticky_restart_requested=true")
        super.onTaskRemoved(rootIntent)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        notificationGuardActive = false
        handler.removeCallbacks(notificationGuard)
        handler.removeCallbacks(permissionMonitor)
        handler.removeCallbacks(stopRunnable)
        super.onDestroy()
    }

    private fun startNotificationGuard() {
        notificationGuardActive = true
        handler.removeCallbacks(notificationGuard)
        // First check is also delayed by one minute, as requested. The notification
        // is posted immediately by startForeground()/notify() in the normal start path.
        handler.postDelayed(notificationGuard, NOTIFICATION_GUARD_INTERVAL_MS)
        DiagnosticStore.add(this, "${stamp()} | NOTIFICATION_GUARD_STARTED | intervalMs=$NOTIFICATION_GUARD_INTERVAL_MS")
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(NotificationChannel(CHANNEL_ID, "TS Моя работа", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Статус работы приложения TS Моя работа"
                // Keep the notification visible in the shade, but never add a launcher icon badge.
                setShowBadge(false)
            })
        }
    }

    private fun buildNotification(running: Boolean): Notification {
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
        // The overall status reflects whether the user has an active schedule,
        // not whether WhatsApp is being tapped at this exact second. A future alarm
        // means the workflow is running and waiting for its next scheduled time.
        // During a one-shot Accessibility execution, keep the status active as well.
        val workflowActive = ScheduledTestStore.active(this) ||
            WhatsAppAccessibilityService.isScheduledExecutionActive()
        val overallStatus = if (workflowActive) "Работает" else "Не работает"
        val overallStatusColor = if (workflowActive) android.graphics.Color.rgb(46, 190, 95) else android.graphics.Color.rgb(239, 68, 68)
        val collapsed = android.widget.RemoteViews(packageName, R.layout.notification_ts_status).apply {
            setTextViewText(R.id.notification_title, "TS Моя работа")
            setTextViewText(R.id.notification_subtitle, overallStatus)
            setTextColor(R.id.notification_subtitle, overallStatusColor)
            setViewVisibility(R.id.notification_activity, android.view.View.GONE)
        }
        val expanded = android.widget.RemoteViews(packageName, R.layout.notification_ts_expanded).apply {
            setTextViewText(R.id.notification_title, "TS Моя работа")
            setTextViewText(R.id.notification_subtitle, overallStatus)
            setTextColor(R.id.notification_subtitle, overallStatusColor)
            setViewVisibility(R.id.notification_activity, android.view.View.GONE)

            // Preserve the exact top-to-bottom order from the app; only the first five chats are shown.
            val topChats = ChatScheduleStore.all(this@ScheduleKeepAliveService).take(5)
            val titleIds = intArrayOf(R.id.chat_title_1, R.id.chat_title_2, R.id.chat_title_3, R.id.chat_title_4, R.id.chat_title_5)
            val detailIds = intArrayOf(R.id.chat_detail_1, R.id.chat_detail_2, R.id.chat_detail_3, R.id.chat_detail_4, R.id.chat_detail_5)
            for (index in 0 until 5) {
                val chat = topChats.getOrNull(index)
                val titleId = titleIds[index]
                val detailId = detailIds[index]
                if (chat == null) {
                    setViewVisibility(titleId, android.view.View.GONE)
                    setViewVisibility(detailId, android.view.View.GONE)
                } else {
                    setViewVisibility(titleId, android.view.View.VISIBLE)
                    setViewVisibility(detailId, android.view.View.VISIBLE)
                    setTextViewText(titleId, chat.launcherLabel.ifBlank { "Чат ${index + 1}" })
                    val nextAt = ScheduledTestStore.nextAtForChat(this@ScheduleKeepAliveService, chat.id)
                    val detail = if (nextAt == null) {
                        "Остановлено"
                    } else {
                        val lastAt = NotificationScheduleInfoStore.lastSendAt(this@ScheduleKeepAliveService, chat.id)
                        val nextText = timeText(nextAt)
                        if (lastAt > 0L) "Отправлено в ${timeText(lastAt)}. Следующее в $nextText"
                        else "Следующее в $nextText"
                    }
                    setTextViewText(detailId, detail)
                    setTextColor(detailId, if (nextAt == null) android.graphics.Color.rgb(239, 68, 68) else android.graphics.Color.rgb(220, 215, 222))
                }
            }
        }

        // Open the main screen when the user taps the notification body.
        // Reuse the same PendingIntent when the notification is refreshed/restored.
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        }
        val openAppPendingIntent = PendingIntent.getActivity(
            this,
            NOTIFICATION_OPEN_APP_REQUEST_CODE,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or
                (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        )

        return builder
            .setContentIntent(openAppPendingIntent)
            .setCustomContentView(collapsed)
            .setSmallIcon(R.drawable.ic_notification_ts)
            .setLargeIcon(android.graphics.BitmapFactory.decodeResource(resources, R.mipmap.ic_launcher))
            .setContentTitle("TS Моя работа")
            // This is intentionally standard content so Android shows the status even when collapsed.
            .setContentText(overallStatus)
            .setCustomBigContentView(expanded)
            .setOngoing(running)
            .setAutoCancel(!running)
            .setOnlyAlertOnce(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .build()
    }

    private fun timeText(timestamp: Long): String =
        java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(java.util.Date(timestamp))

    private fun stopWithStoppedStatus() {
        notificationGuardActive = false
        handler.removeCallbacks(notificationGuard)
        handler.removeCallbacks(stopRunnable)
        handler.removeCallbacks(permissionMonitor)
        // Detach first, then retain a clear, non-technical status notification.
        stopForeground(STOP_FOREGROUND_DETACH)
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIFICATION_ID, buildNotification(running = false))
        stopSelf()
    }

    private fun stamp() = java.text.SimpleDateFormat("HH:mm:ss.SSS", java.util.Locale.getDefault()).format(java.util.Date())

    companion object {
        const val ACTION_MONITOR = "ru.tsautoreport.diagnostic.SCHEDULE_MONITOR"
        const val ACTION_RUN = "ru.tsautoreport.diagnostic.SCHEDULE_RUN"
        const val ACTION_STOP = "ru.tsautoreport.diagnostic.SCHEDULE_STOP"
        const val ACTION_REFRESH = "ru.tsautoreport.diagnostic.SCHEDULE_REFRESH"
        private const val CHANNEL_ID = "ts_autoreport_schedule_v2_no_badge"
        private const val NOTIFICATION_ID = 19020
        private const val NOTIFICATION_OPEN_APP_REQUEST_CODE = 19021
        private const val NOTIFICATION_GUARD_INTERVAL_MS = 60_000L

        fun isRunning(context: Context): Boolean = try {
            val manager = context.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
            manager.getRunningServices(Int.MAX_VALUE).any { it.service.className == ScheduleKeepAliveService::class.java.name }
        } catch (_: Exception) { false }

        fun refresh(context: Context) {
            start(context, ACTION_REFRESH)
        }

        fun start(context: Context, action: String) {
            val intent = Intent(context, ScheduleKeepAliveService::class.java).setAction(action)
            try {
                if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(intent) else context.startService(intent)
                DiagnosticStore.add(context, "${java.text.SimpleDateFormat("HH:mm:ss.SSS", java.util.Locale.getDefault()).format(java.util.Date())} | SCHEDULE_FOREGROUND_START_REQUESTED | action=$action")
            } catch (e: Exception) {
                DiagnosticStore.add(context, "${java.text.SimpleDateFormat("HH:mm:ss.SSS", java.util.Locale.getDefault()).format(java.util.Date())} | SCHEDULE_FOREGROUND_START_FAILED | action=$action | error=${e.javaClass.simpleName}")
            }
        }
    }
}
