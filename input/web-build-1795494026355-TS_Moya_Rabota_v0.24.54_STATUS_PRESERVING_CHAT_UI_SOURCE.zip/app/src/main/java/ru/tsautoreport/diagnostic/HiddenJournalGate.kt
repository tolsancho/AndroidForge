package ru.tsautoreport.diagnostic

import android.content.Context
import android.os.SystemClock

/** Independent five-second, ten-tap gate; deliberately excluded from the app's factory-reset preferences. */
object HiddenJournalGate {
    private const val PREFS = "ts_hidden_journal_gate"
    private const val KEY_COUNT = "tap_count"
    private const val KEY_STARTED = "window_started_elapsed"
    private const val WINDOW_MS = 5_000L
    private const val REQUIRED_TAPS = 10

    @Synchronized fun registerResetTap(context: Context): Boolean {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val now = SystemClock.elapsedRealtime()
        val started = prefs.getLong(KEY_STARTED, 0L)
        val oldCount = prefs.getInt(KEY_COUNT, 0)
        val valid = oldCount > 0 && now >= started && now - started <= WINDOW_MS
        val count = if (valid) oldCount + 1 else 1
        if (count >= REQUIRED_TAPS) {
            prefs.edit().remove(KEY_COUNT).remove(KEY_STARTED).commit()
            return true
        }
        prefs.edit().putInt(KEY_COUNT, count).putLong(KEY_STARTED, if (valid) started else now).commit()
        return false
    }

    @Synchronized fun expireIfNeeded(context: Context) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val count = prefs.getInt(KEY_COUNT, 0)
        val started = prefs.getLong(KEY_STARTED, 0L)
        val now = SystemClock.elapsedRealtime()
        if (count > 0 && (now < started || now - started > WINDOW_MS)) {
            prefs.edit().remove(KEY_COUNT).remove(KEY_STARTED).commit()
        }
    }
}
