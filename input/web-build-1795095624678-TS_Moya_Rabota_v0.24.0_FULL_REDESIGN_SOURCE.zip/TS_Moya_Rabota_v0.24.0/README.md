# TS Моя работа v0.24.0

Полный новый интерфейс и отдельная модель до 10 чатов × 24 интервала на чат. Подробности, ограничения и сборка — в `README_RU.txt` и `CHANGELOG_v0.24.0.txt`.

- BUILD ID: `TS-BIND-0240`
- versionCode: `31`
- Android: minSdk 26, compileSdk 36, targetSdk 35
- Сборка Debug: https://professional-x.github.io/AndroidForge/

Важно: исходники прошли статическую проверку, но APK не компилировался и не тестировался на устройстве. Начинайте с собственного второго WhatsApp-аккаунта.
