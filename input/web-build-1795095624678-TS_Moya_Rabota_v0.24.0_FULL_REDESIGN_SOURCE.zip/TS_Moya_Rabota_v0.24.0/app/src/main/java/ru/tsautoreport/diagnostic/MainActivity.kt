package ru.tsautoreport.diagnostic

import android.app.Activity
import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.accessibilityservice.AccessibilityServiceInfo
import android.view.accessibility.AccessibilityManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import java.util.Calendar

class MainActivity : ComponentActivity() {
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState); val p=getSharedPreferences("ts_activation",0); if(!p.getBoolean("activated",false)){setContent{ActivationScreen{p.edit().putBoolean("activated",true).commit(); recreate() }};return}; setContent{ WorkApp() } }
}

@Composable private fun ActivationScreen(done:()->Unit){ var pass by remember{mutableStateOf("")}; MaterialTheme { Surface(Modifier.fillMaxSize()){ Column(Modifier.fillMaxSize().padding(28.dp),verticalArrangement=Arrangement.Center){Text("Пароль ка черкани или не видать тебе чёткой смены.",style=MaterialTheme.typography.titleLarge); Spacer(Modifier.height(18.dp)); OutlinedTextField(pass,{pass=it},label={Text("Пароль")},visualTransformation=PasswordVisualTransformation(),singleLine=true); Spacer(Modifier.height(12.dp)); Button(onClick={if(pass=="TolSancho")done()}){Text("Продолжить")} } } } }

@Composable private fun WorkApp(){
 val ctx= LocalContext.current; val prefs= remember{ctx.getSharedPreferences("ts_ui",0)}
 val availableProfiles= remember { detectWhatsAppProfiles(ctx) }; var chats by remember { mutableStateOf(ChatScheduleStore.all(ctx)) }; var active by remember{mutableStateOf(ScheduledTestStore.active(ctx))}; var stateKnown by remember{mutableStateOf(ctx.getSharedPreferences("ts_ui",0).getBoolean("state_known",false))}; var permissionTick by remember{mutableIntStateOf(0)}
 var drawer by remember{mutableStateOf(false)}; var instruction by remember{mutableStateOf(false)}; var section by remember{mutableStateOf(prefs.getString("guide_section","Назначение")?:"Назначение")}; var scale by remember{mutableFloatStateOf(prefs.getInt("scale",0).toFloat())}; var theme by remember{mutableStateOf(prefs.getString("theme","system")?:"system")}; var ownerPassword by remember{mutableStateOf(prefs.getString("owner_password","").orEmpty())}; var ownerGate by remember{mutableStateOf(ownerPassword.isNotBlank())}; var showPasswordDialog by remember{mutableStateOf(false)}; var passDraft by remember{mutableStateOf("")}; var expandedChat by remember{mutableStateOf("")}; var expandedInterval by remember{mutableStateOf("")}; var showTimeFor by remember{mutableStateOf("")}; var showMessageFor by remember{mutableStateOf("")}; var draftMessage by remember{mutableStateOf("")}; var draftTime by remember{mutableStateOf("09:00")}; var showAddChat by remember{mutableStateOf(false)}; var newLabel by remember{mutableStateOf("")}; var newProfile by remember{mutableStateOf(if("clone" in availableProfiles)"clone" else "main")}; var pendingConfirm by remember{mutableStateOf("")}; var guideScroll by remember{mutableIntStateOf(prefs.getInt("guide_scroll",0))}
 val dark = when(theme){"dark"->true;"light"->false;else-> androidx.compose.foundation.isSystemInDarkTheme()}
 val cs= if(dark) darkColorScheme(primary=Color(0xFF78D69A),secondary=Color(0xFFB98A61)) else lightColorScheme(primary=Color(0xFF237A48),secondary=Color(0xFF86552F))
 fun refresh(){chats=ChatScheduleStore.all(ctx);active=ScheduledTestStore.active(ctx)}
 LaunchedEffect(Unit){while(true){active=ScheduledTestStore.active(ctx);permissionTick++;delay(1000)}}
 fun persist(list:List<WorkChat>){ChatScheduleStore.save(ctx,list);chats=list}
 BackHandler(drawer||instruction||ownerGate){ if(ownerGate) Unit else if(instruction) instruction=false else drawer=false }
 val baseDensity=LocalDensity.current
 CompositionLocalProvider(LocalDensity provides androidx.compose.ui.unit.Density(baseDensity.density*(1f+scale/100f).coerceAtLeast(0.5f), baseDensity.fontScale*(1f+scale/100f).coerceAtLeast(0.5f))){ MaterialTheme(colorScheme=cs){
  Box(Modifier.fillMaxSize()){
   Column(Modifier.fillMaxSize().padding(start=34.dp,bottom=84.dp).verticalScroll(rememberScrollState()).padding(horizontal=14.dp, vertical=12.dp)){
    Text("TS Моя работа",style=MaterialTheme.typography.headlineMedium)
    Spacer(Modifier.height(12.dp)); Text(if(permissionTick<0)"Разрешения" else "Разрешения",style=MaterialTheme.typography.titleMedium)
    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
     PermissionPill("Accessibility",accessibilityEnabled(ctx) || permissionTick == -1){ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))}
     PermissionPill("Батарея",batteryExempt(ctx) || permissionTick == -1){try{ctx.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,Uri.parse("package:${ctx.packageName}")))}catch(_:Exception){ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))}}
     PermissionPill("Будильники",exactAllowed(ctx) || permissionTick == -1){if(Build.VERSION.SDK_INT>=31)ctx.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,Uri.parse("package:${ctx.packageName}")))}
    }
    if(Build.VERSION.SDK_INT>=33){Spacer(Modifier.height(6.dp));PermissionPill("Уведомления",ctx.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)==android.content.pm.PackageManager.PERMISSION_GRANTED){ctx.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE,ctx.packageName))}}
    Spacer(Modifier.height(18.dp)); Row(verticalAlignment=Alignment.CenterVertically){Text("Чаты",style=MaterialTheme.typography.titleLarge); Spacer(Modifier.weight(1f));Text("${chats.size}/10",style=MaterialTheme.typography.labelLarge)}
    Text("Введите точное название ярлыка переписки на рабочем столе. Проверка откроет именно этот ярлык; вернитесь сюда и подтвердите результат.",style=MaterialTheme.typography.bodySmall)
    chats.forEach { chat ->
     Card(Modifier.fillMaxWidth().padding(vertical=5.dp),shape=RoundedCornerShape(16.dp)){
      Column(Modifier.padding(12.dp)){
       Row(verticalAlignment=Alignment.CenterVertically,modifier=Modifier.fillMaxWidth().clickable{expandedChat=if(expandedChat==chat.id)"" else chat.id;expandedInterval=""}){Column(Modifier.weight(1f)){Text(chat.launcherLabel.ifBlank{"Новый чат"},style=MaterialTheme.typography.titleMedium);Text("${chat.profile.uppercase()} · ${chat.intervals.size}/24 интервалов",style=MaterialTheme.typography.bodySmall)};Text(if(expandedChat==chat.id)"⌃" else "⌄")}
       AnimatedVisibility(expandedChat==chat.id,enter=androidx.compose.animation.expandVertically(tween(220)),exit=androidx.compose.animation.shrinkVertically(tween(180))){
        Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
         Text("Ярлык рабочего стола",style=MaterialTheme.typography.labelLarge)
         OutlinedTextField(chat.launcherLabel,{v->persist(chats.map{if(it.id==chat.id)it.copy(launcherLabel=v.take(100),confirmed=false) else it})},modifier=Modifier.fillMaxWidth(),singleLine=true)
         Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){if("main" in availableProfiles)FilterChip(selected=chat.profile=="main",onClick={persist(chats.map{if(it.id==chat.id)it.copy(profile="main",confirmed=false)else it})},label={Text("Основной WhatsApp")});if("clone" in availableProfiles)FilterChip(selected=chat.profile=="clone",onClick={persist(chats.map{if(it.id==chat.id)it.copy(profile="clone",confirmed=false)else it})},label={Text("Клон WhatsApp")})}
         OutlinedButton(onClick={pendingConfirm=chat.id; launchShortcutCheck(ctx,chat.id,chat.profile,chat.launcherLabel) },modifier=Modifier.fillMaxWidth(),enabled=chat.launcherLabel.isNotBlank()){Text("Проверить ярлык — открыть чат")}
         if(pendingConfirm==chat.id){Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Button(onClick={persist(chats.map{if(it.id==chat.id)it.copy(confirmed=true)else it});pendingConfirm=""}){Text("Верно")};OutlinedButton(onClick={pendingConfirm=""}){Text("Не верно")}}}
         Text(if(chat.confirmed)"Ярлык подтверждён" else "Ярлык ещё не подтверждён",color=if(chat.confirmed)Color(0xFF23834B) else MaterialTheme.colorScheme.error,style=MaterialTheme.typography.bodySmall)
         HorizontalDivider()
         chat.intervals.forEach { slot ->
          Column(Modifier.fillMaxWidth().border(1.dp,MaterialTheme.colorScheme.outlineVariant,RoundedCornerShape(12.dp)).padding(9.dp)){
           Row(Modifier.fillMaxWidth().clickable{expandedInterval=if(expandedInterval==slot.id)"" else slot.id},verticalAlignment=Alignment.CenterVertically){Text(slot.time,style=MaterialTheme.typography.titleMedium);Spacer(Modifier.width(10.dp));Text(slot.message.take(42),Modifier.weight(1f),style=MaterialTheme.typography.bodySmall);Text(if(expandedInterval==slot.id)"⌃" else "⌄")}
           if(expandedInterval==slot.id){Row(verticalAlignment=Alignment.CenterVertically){Text("Время: ${slot.time}");Spacer(Modifier.width(8.dp));TextButton(onClick={draftTime=slot.time;showTimeFor="edit:${chat.id}:${slot.id}"}){Text("Изменить")};Spacer(Modifier.weight(1f));TextButton(onClick={persist(chats.map{c->if(c.id==chat.id)c.copy(intervals=c.intervals.filterNot{it.id==slot.id})else c})}){Text("Удалить")}}
            Text("Сообщение: ${slot.message.take(120)}",style=MaterialTheme.typography.bodySmall); OutlinedButton(onClick={draftMessage=slot.message;showMessageFor="edit:${chat.id}:${slot.id}"},modifier=Modifier.fillMaxWidth()){Text("Изменить сообщение") }
            Text("Повторение",style=MaterialTheme.typography.labelLarge);Row(horizontalArrangement=Arrangement.spacedBy(3.dp)){listOf("ONCE" to "Один раз","DAILY" to "Ежедневно","WEEKDAYS" to "Будни","DATES" to "Даты").forEach{(mode,title)->FilterChip(selected=slot.mode==mode,onClick={persist(chats.map{c->if(c.id==chat.id)c.copy(intervals=c.intervals.map{if(it.id==slot.id)it.copy(mode=mode)else it})else c})},label={Text(title,style=MaterialTheme.typography.labelSmall)})}}
            if(slot.mode=="DATES") OutlinedTextField(slot.dates,{v->persist(chats.map{c->if(c.id==chat.id)c.copy(intervals=c.intervals.map{if(it.id==slot.id)it.copy(dates=v)else it})else c})},modifier=Modifier.fillMaxWidth(),label={Text("Даты через запятую: 2026-12-01, 2026-12-05")})
           }
          }
         }
         OutlinedButton(onClick={if(chat.intervals.size<24){draftTime="09:00";draftMessage="";showTimeFor=chat.id}},enabled=chat.intervals.size<24,modifier=Modifier.fillMaxWidth()){Text("＋ Добавить время")}
         TextButton(onClick={persist(chats.filterNot{it.id==chat.id});expandedChat=""}){Text("Удалить чат")}
        }
       }
      }
     }
    }
    OutlinedButton(onClick={showAddChat=true},enabled=chats.size<10,modifier=Modifier.fillMaxWidth()){Text("＋ Добавить чат")}
   }
   // fixed footer
   Surface(Modifier.align(Alignment.BottomCenter).fillMaxWidth(),shadowElevation=8.dp,color=MaterialTheme.colorScheme.surface){Row(Modifier.navigationBarsPadding().padding(10.dp),horizontalArrangement=Arrangement.spacedBy(10.dp)){
    Button(onClick={try{val count=ScheduledTestStore.scheduleAll(ctx);stateKnown=true;ctx.getSharedPreferences("ts_ui",0).edit().putBoolean("state_known",true).apply();refresh();Toast.makeText(ctx,"Запущено заданий: $count",Toast.LENGTH_LONG).show()}catch(e:Exception){Toast.makeText(ctx,e.message?:"Не удалось запустить",Toast.LENGTH_LONG).show()}},modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=if(active)Color(0xFF238447) else Color.Gray)){Text("Сохранить и запустить")}
    Button(onClick={ScheduledTestStore.cancel(ctx);stateKnown=true;ctx.getSharedPreferences("ts_ui",0).edit().putBoolean("state_known",true).apply();refresh()},modifier=Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=if(!active && stateKnown)Color(0xFFC62828) else Color.Gray)){Text("Отменить и остановить")}
   }}
   // persistent drag handle
   Surface(Modifier.align(Alignment.TopStart).fillMaxHeight().width(30.dp).pointerInput(Unit){var dx=0f;detectHorizontalDragGestures(onHorizontalDrag={_,d->dx+=d},onDragEnd={if(dx>20)drawer=true else if(dx< -20)drawer=false;dx=0f})},color=MaterialTheme.colorScheme.surfaceVariant,shape=RoundedCornerShape(topEnd=14.dp,bottomEnd=14.dp)) {Box(Modifier.fillMaxSize(),contentAlignment=Alignment.TopCenter){Icon(Icons.Default.Menu,null,Modifier.padding(top=16.dp).size(24.dp))}}
   AnimatedVisibility(drawer,enter=androidx.compose.animation.slideInHorizontally(tween(240)){-it},exit=androidx.compose.animation.slideOutHorizontally(tween(200))){
    Surface(Modifier.fillMaxHeight().width(290.dp).align(Alignment.CenterStart),shadowElevation=16.dp,color=MaterialTheme.colorScheme.surface){Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
     Row(verticalAlignment=Alignment.CenterVertically){Text("Настройки",style=MaterialTheme.typography.titleLarge,modifier=Modifier.weight(1f));IconButton(onClick={drawer=false}){Icon(Icons.Default.Close,"Закрыть", tint=Color.Red)}}
     Text("Тема",style=MaterialTheme.typography.titleMedium);Row(horizontalArrangement=Arrangement.spacedBy(4.dp)){listOf("system" to "Как в телефоне","light" to "Светлая","dark" to "Тёмная").forEach{(v,l)->FilterChip(theme==v,{theme=v;prefs.edit().putString("theme",v).apply()},label={Text(l)})}}
     Text("Шрифт и масштаб: ${scale.toInt()}%",style=MaterialTheme.typography.titleMedium);Slider(value=scale,onValueChange={scale=it.toInt().toFloat();prefs.edit().putInt("scale",scale.toInt()).apply()},valueRange=-50f..200f,steps=249);Text("От −50% до +200%. Меняются размеры текста и элементов.",style=MaterialTheme.typography.bodySmall)
     Button(onClick={instruction=true;drawer=false},modifier=Modifier.fillMaxWidth()){Text("Инструкция")}
     Button(onClick={showPasswordDialog=true},modifier=Modifier.fillMaxWidth()){Text("Пароль владельца")};if(ownerPassword.isNotBlank())TextButton(onClick={ownerPassword="";prefs.edit().remove("owner_password").apply()}){Text("Сбросить пароль")}
     Button(onClick={Toast.makeText(ctx,"Рахмет Толясику скажи, не будь козлом. Зря он прогу писал эту? Старался же.",Toast.LENGTH_LONG).show()},modifier=Modifier.fillMaxWidth()){Text("Благодарности")}
     Spacer(Modifier.weight(1f));OutlinedButton(onClick={ScheduledTestStore.cancel(ctx);ctx.getSharedPreferences("ts_ui",0).edit().clear().apply();ctx.getSharedPreferences("ts_work_model",0).edit().clear().apply();chats=emptyList();active=false;stateKnown=false;theme="system";scale=0f;ownerPassword="";ownerGate=false;drawer=false;Toast.makeText(ctx,"Настройки приложения сброшены. Разрешения Android сохранены.",Toast.LENGTH_LONG).show()},modifier=Modifier.fillMaxWidth()){Text("Сбросить приложение до заводских настроек")}
    }}
   }
   if(drawer) Surface(Modifier.align(Alignment.CenterStart).offset(x=290.dp).fillMaxHeight().width(30.dp).pointerInput(Unit){var dx=0f;detectHorizontalDragGestures(onHorizontalDrag={_,d->dx+=d},onDragEnd={if(dx < -20)drawer=false;dx=0f})},color=MaterialTheme.colorScheme.surfaceVariant,shape=RoundedCornerShape(topEnd=14.dp,bottomEnd=14.dp)){Box(Modifier.fillMaxSize(),contentAlignment=Alignment.TopCenter){Icon(Icons.Default.Menu,null,Modifier.padding(top=16.dp).size(22.dp))}}
   if(showAddChat) AlertDialog(onDismissRequest={showAddChat=false},title={Text("Новый чат")},text={Column{OutlinedTextField(newLabel,{newLabel=it},label={Text("Точное имя ярлыка на рабочем столе")});Spacer(Modifier.height(8.dp));Text("Обнаруженные экземпляры WhatsApp");Row{if("main" in availableProfiles)FilterChip(newProfile=="main",{newProfile="main"},label={Text("Основной")});if("clone" in availableProfiles)FilterChip(newProfile=="clone",{newProfile="clone"},label={Text("Клон")})}}},confirmButton={TextButton(onClick={if(newLabel.isNotBlank()){val ch=WorkChat(launcherLabel=newLabel.trim(),profile=newProfile);persist(chats+ch);expandedChat=ch.id;newLabel="";showAddChat=false}}){Text("Добавить")}},dismissButton={TextButton(onClick={showAddChat=false}){Text("Отмена")}})
   if(showTimeFor.isNotBlank()) AlertDialog(onDismissRequest={showTimeFor=""},title={Text("Время запуска")},text={Column{val hp=draftTime.substringBefore(":").toIntOrNull()?:9;val mp=draftTime.substringAfter(":","00").toIntOrNull()?:0;Row(horizontalArrangement=Arrangement.Center,verticalAlignment=Alignment.CenterVertically){androidx.compose.ui.viewinterop.AndroidView(factory={android.widget.NumberPicker(it).apply{minValue=0;maxValue=23;value=hp;setFormatter{v->"%02d".format(v)};setOnValueChangedListener{_,_,v->draftTime="%02d:%02d".format(v,mp)}}},modifier=Modifier.width(90.dp).height(150.dp));Text(":",style=MaterialTheme.typography.headlineMedium);androidx.compose.ui.viewinterop.AndroidView(factory={android.widget.NumberPicker(it).apply{minValue=0;maxValue=59;value=mp;setFormatter{v->"%02d".format(v)};setOnValueChangedListener{_,_,v->draftTime="%02d:%02d".format(hp,v)}}},modifier=Modifier.width(90.dp).height(150.dp))}}},confirmButton={TextButton(onClick={if(draftTime.matches(Regex("([01]\\d|2[0-3]):[0-5]\\d"))){if(showTimeFor.startsWith("edit:")){val parts=showTimeFor.split(":");val cid=parts[1];val iid=parts[2];persist(chats.map{c->if(c.id==cid)c.copy(intervals=c.intervals.map{if(it.id==iid)it.copy(time=draftTime)else it})else c});showTimeFor=""}else{showMessageFor=showTimeFor;showTimeFor=""}}}){Text("Готово")}},dismissButton={TextButton(onClick={showTimeFor=""}){Text("Отмена")}})
   if(showMessageFor.isNotBlank()) AlertDialog(onDismissRequest={showMessageFor=""},title={Text("Сообщение")},text={OutlinedTextField(draftMessage,{draftMessage=it.take(3000)},modifier=Modifier.fillMaxWidth(),minLines=4,label={Text("До 3000 символов")})},confirmButton={TextButton(onClick={if(draftMessage.isNotBlank()){if(showMessageFor.startsWith("edit:")){val parts=showMessageFor.split(":");val cid=parts[1];val iid=parts[2];persist(chats.map{c->if(c.id==cid)c.copy(intervals=c.intervals.map{if(it.id==iid)it.copy(message=draftMessage)else it})else c});expandedChat=cid}else{val ch=chats.first{it.id==showMessageFor};persist(chats.map{if(it.id==ch.id)it.copy(intervals=it.intervals+WorkInterval(time=draftTime,message=draftMessage))else it});expandedChat=ch.id};showMessageFor="";draftMessage=""}}){Text("Сохранить")}},dismissButton={TextButton(onClick={showMessageFor=""}){Text("Отмена")}})
   if(showPasswordDialog) AlertDialog(onDismissRequest={showPasswordDialog=false;passDraft=""},title={Text("Пароль владельца")},text={OutlinedTextField(passDraft,{passDraft=it},visualTransformation=PasswordVisualTransformation(),label={Text("Новый пароль")})},confirmButton={TextButton(onClick={if(passDraft.isNotBlank()){ownerPassword=passDraft;prefs.edit().putString("owner_password",ownerPassword).apply();passDraft="";showPasswordDialog=false}}){Text("Сохранить")}},dismissButton={TextButton(onClick={showPasswordDialog=false}){Text("Отмена")}})
   if(instruction) GuideDialog(section,{section=it;prefs.edit().putString("guide_section",it).apply()},guideScroll,{guideScroll=it;prefs.edit().putInt("guide_scroll",it).apply()},{instruction=false})
   if(ownerGate && ownerPassword.isNotBlank()) { var entered by remember{mutableStateOf("")}; AlertDialog(onDismissRequest={},title={Text("Введите пароль")},text={OutlinedTextField(entered,{entered=it},visualTransformation=PasswordVisualTransformation())},confirmButton={TextButton(onClick={if(entered==ownerPassword)ownerGate=false}){Text("Войти")}}) }
  }
 }}
}

@Composable private fun PermissionPill(label:String,ok:Boolean,onClick:()->Unit){Surface(onClick=onClick,color=if(ok)Color(0xFFDDF2E3) else Color(0xFFFFE0E0),shape=RoundedCornerShape(20.dp),modifier=Modifier.width(100.dp)){Text("● $label",Modifier.padding(horizontal=8.dp,vertical=10.dp),color=if(ok)Color(0xFF176B37)else Color(0xFFB3261E),style=MaterialTheme.typography.labelSmall)}}
private fun detectWhatsAppProfiles(c:Context):Set<String> = try { val launcher=c.getSystemService(Context.LAUNCHER_APPS_SERVICE) as android.content.pm.LauncherApps; launcher.profiles.mapNotNull { user -> runCatching { launcher.getActivityList("com.whatsapp",user) }.getOrNull()?.takeIf{it.isNotEmpty()}?.let { if(user.identifier==0) "main" else "clone" } }.toSet() } catch (_:Exception) { if(runCatching{c.packageManager.getPackageInfo("com.whatsapp",0)}.isSuccess) setOf("main") else emptySet() }
private fun accessibilityEnabled(c:Context)=try{val m=c.getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager;m.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK).any{it.resolveInfo.serviceInfo.packageName==c.packageName}}catch(_:Exception){false}
private fun batteryExempt(c:Context)= (c.getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(c.packageName)
private fun exactAllowed(c:Context)=Build.VERSION.SDK_INT<31 || (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).canScheduleExactAlarms()
private fun launchShortcutCheck(c:Context,chatId:String,profile:String,label:String){ChatScheduleStore.setPending(c,chatId); val ok=WhatsAppAccessibilityService.requestHomeNavigation(); if(!ok) Toast.makeText(c,"Включи Специальные возможности для TS Моя работа, затем повтори проверку ярлыка.",Toast.LENGTH_LONG).show() else Toast.makeText(c,"Открываю ярлык «$label». Проверь аккаунт $profile и вернись для подтверждения.",Toast.LENGTH_LONG).show()}

@Composable private fun GuideDialog(section:String,onSection:(String)->Unit,scroll:Int,onScroll:(Int)->Unit,onClose:()->Unit){val items=listOf("Назначение","Общие настройки","WhatsApp","Чаты и ярлыки","Разрешения","Samsung","Xiaomi / Redmi / POCO","Huawei / Honor","OPPO / Realme","Vivo","OnePlus","Motorola","Google Pixel","Другие Android");Dialog(onDismissRequest={},properties=DialogProperties(usePlatformDefaultWidth=false)){Surface(Modifier.fillMaxWidth(.96f).fillMaxHeight(.92f),shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(12.dp)){Row(verticalAlignment=Alignment.CenterVertically){Text("Инструкция",style=MaterialTheme.typography.titleLarge,modifier=Modifier.weight(1f));IconButton(onClick=onClose){Icon(Icons.Default.Close,"Закрыть", tint=Color.Red)}};Row(Modifier.weight(1f)){Column(Modifier.width(130.dp).verticalScroll(rememberScrollState())){items.forEach{TextButton(onClick={onSection(it)},modifier=Modifier.fillMaxWidth()){Text(it,style=MaterialTheme.typography.labelSmall)}}};Divider(Modifier.fillMaxHeight().width(1.dp));val state= rememberScrollState(scroll);LaunchedEffect(state.value){onScroll(state.value)};Column(Modifier.weight(1f).verticalScroll(state).padding(10.dp)){Text(section,style=MaterialTheme.typography.titleMedium);Spacer(Modifier.height(8.dp));Text(guideText(section),style=MaterialTheme.typography.bodyMedium)}}}}}}
private fun guideText(s:String)=when(s){"Назначение"->"TS Моя работа запускает подтверждённый ярлык переписки по локальному расписанию. На каждом интервале хранится одно сообщение. Перед отправкой приложение проверяет WhatsApp, поле ввода, текст и единственную кнопку отправки. При неоднозначности задание прерывается.";"Общие настройки"->"Тема: системная, светлая или тёмная. Масштаб регулируется от −50% до +200%. Сброс удаляет только настройки TS Моя работа и её будильники. Разрешения Android не отзываются.";"WhatsApp"->"Выберите основной WhatsApp или клон Dual Messenger. Для каждого чата ярлык подтверждается отдельно. Профиль WhatsApp нельзя надёжно установить только по Accessibility-событиям: проверяйте визуально, что ярлык ведёт в нужный аккаунт.";"Чаты и ярлыки"->"Введите точное название ярлыка переписки на рабочем столе. Приложение ищет совпадение по тексту/описанию и требует единственный результат. Дубликаты названий нужно устранить. После открытия переписки вернитесь и подтвердите «Верно».";"Разрешения"->"Accessibility: Настройки → Специальные возможности → Установленные приложения → TS Моя работа → Включить. Батарея: Настройки → Приложения → TS Моя работа → Батарея → Без ограничений. Точные будильники: Настройки → Приложения → Специальный доступ → Будильники и напоминания. Уведомления: Настройки → Приложения → TS Моя работа → Уведомления.";"Samsung"->"Настройки → Приложения → TS Моя работа → Батарея → Без ограничений. Настройки → Обслуживание устройства → Батарея → Ограничения фонового использования: не добавлять приложение в спящие. Специальные возможности → Установленные приложения → TS Моя работа.";"Xiaomi / Redmi / POCO"->"Настройки → Приложения → Управление приложениями → TS Моя работа → Экономия энергии → Нет ограничений. Автозапуск: Настройки → Приложения → Разрешения → Автозапуск (путь зависит от MIUI/HyperOS). В информации приложения разрешить всплывающие окна/фоновые запуски, если доступны.";"Huawei / Honor"->"Настройки → Приложения → Запуск приложений → TS Моя работа → вручную; включить автозапуск, вторичный запуск и работу в фоне. Батарея → Оптимизация запуска/Оптимизация батареи: разрешить работу без ограничений, если пункт есть.";"OPPO / Realme"->"Настройки → Батарея → Управление расходом батареи приложениями → TS Моя работа → разрешить фоновую активность. В настройках приложений включить автозапуск и запуск из других приложений, если доступны.";"Vivo"->"Настройки → Батарея → Высокое фоновое энергопотребление → TS Моя работа разрешить. В iManager разрешить автозапуск и фоновую работу.";"OnePlus"->"Настройки → Батарея → Оптимизация батареи → TS Моя работа → Не оптимизировать. Проверьте управление автозапуском и фоновую активность.";"Motorola"->"Настройки → Приложения → TS Моя работа → Батарея → Без ограничений; Специальные возможности → TS Моя работа → Включить.";"Google Pixel"->"Настройки → Приложения → TS Моя работа → Батарея приложения → Без ограничений. Специальные возможности → TS Моя работа.";else->"Названия пунктов различаются в зависимости от версии Android и оболочки производителя. Откройте карточку приложения TS Моя работа в системных настройках и проверьте батарею, автозапуск, фоновые действия, уведомления, точные будильники и Accessibility. Производитель может ограничивать запуск экранов из фона."}
