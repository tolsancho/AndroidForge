package ru.tsautoreport.diagnostic

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log

/** Keeps the scheduled workflow visible to Android while a one-shot test is pending/running. */
class ScheduleKeepAliveService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private val stopRunnable = Runnable { stopForeground(STOP_FOREGROUND_REMOVE); stopSelf() }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
        DiagnosticStore.add(this, "${stamp()} | SCHEDULE_FOREGROUND_SERVICE_CREATED | foreground=true")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_RUN -> {
                DiagnosticStore.add(this, "${stamp()} | SCHEDULE_FOREGROUND_SERVICE_RUN | action=RUN | interval=${intent.getStringExtra(ScheduledTestStore.EXTRA_INTERVAL_ID).orEmpty()} chat=${intent.getStringExtra(ScheduledTestStore.EXTRA_CHAT_ID).orEmpty()}")
                handler.removeCallbacks(stopRunnable)
                val message = intent.getStringExtra(ScheduledTestStore.EXTRA_MESSAGE).orEmpty().ifBlank { "проверка" }
                val slot = intent.getStringExtra(ScheduledTestStore.EXTRA_INTERVAL_ID).orEmpty()
                val chatId = intent.getStringExtra(ScheduledTestStore.EXTRA_CHAT_ID).orEmpty()
                val dispatched = WhatsAppAccessibilityService.beginScheduledDraftTest(message, slot.hashCode(), chatId)
                DiagnosticStore.add(this, "${stamp()} | SCHEDULE_FOREGROUND_SERVICE_ACCESSIBILITY_DISPATCH | available=$dispatched")
                if (!dispatched) DiagnosticStore.add(this, "${stamp()} | DRAFT_TEST_ABORTED | reason=ACCESSIBILITY_SERVICE_NOT_RUNNING")
                if (ScheduledTestStore.pendingCount(this) == 0) handler.postDelayed(stopRunnable, 60_000L)
            }
            ACTION_MONITOR -> {
                DiagnosticStore.add(this, "${stamp()} | SCHEDULE_FOREGROUND_SERVICE_MONITOR | scheduledAt=${ScheduledTestStore.scheduledAt(this)}")
                handler.removeCallbacks(stopRunnable)
            }
            ACTION_STOP -> {
                handler.removeCallbacks(stopRunnable)
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
        return START_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        // START_STICKY is the recovery hint; Android/OEM policy still controls process restart.
        DiagnosticStore.add(this, "${stamp()} | SCHEDULE_FOREGROUND_TASK_REMOVED | sticky_restart_requested=true")
        super.onTaskRemoved(rootIntent)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(NotificationChannel(CHANNEL_ID, "TS AutoReport — расписание", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Показывает, что фоновое расписание TS AutoReport активно"
            })
        }
    }

    private fun buildNotification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
        return builder.setSmallIcon(android.R.drawable.ic_popup_sync)
            .setContentTitle("TS AutoReport работает")
            .setContentText("Ожидание запланированной проверки WhatsApp-клона")
            .setOngoing(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .build()
    }

    private fun stamp() = java.text.SimpleDateFormat("HH:mm:ss.SSS", java.util.Locale.getDefault()).format(java.util.Date())

    companion object {
        const val ACTION_MONITOR = "ru.tsautoreport.diagnostic.SCHEDULE_MONITOR"
        const val ACTION_RUN = "ru.tsautoreport.diagnostic.SCHEDULE_RUN"
        const val ACTION_STOP = "ru.tsautoreport.diagnostic.SCHEDULE_STOP"
        private const val CHANNEL_ID = "ts_autoreport_schedule"
        private const val NOTIFICATION_ID = 19020

        fun isRunning(context: Context): Boolean = try {
            val manager = context.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
            manager.getRunningServices(Int.MAX_VALUE).any { it.service.className == ScheduleKeepAliveService::class.java.name }
        } catch (_: Exception) { false }

        fun start(context: Context, action: String) {
            val intent = Intent(context, ScheduleKeepAliveService::class.java).setAction(action)
            try {
                if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(intent) else context.startService(intent)
                DiagnosticStore.add(context, "${java.text.SimpleDateFormat("HH:mm:ss.SSS", java.util.Locale.getDefault()).format(java.util.Date())} | SCHEDULE_FOREGROUND_START_REQUESTED | action=$action")
            } catch (e: Exception) {
                DiagnosticStore.add(context, "${java.text.SimpleDateFormat("HH:mm:ss.SSS", java.util.Locale.getDefault()).format(java.util.Date())} | SCHEDULE_FOREGROUND_START_FAILED | action=$action | error=${e.javaClass.simpleName}")
            }
        }
    }
}
