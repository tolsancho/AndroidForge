package ru.tsautoreport.diagnostic

import android.content.Context

/** Stores only the user-entered launcher icon label and a one-shot click request. */
object HomeShortcutStore {
    private const val PREFS = "home_shortcut_assist"
    data class State(val label: String, val pending: Boolean, val lastResult: String)

    fun state(context: Context): State {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return State(p.getString("label", "").orEmpty(), p.getBoolean("pending", false), p.getString("last_result", "Ещё не запускался").orEmpty())
    }

    fun setLabel(context: Context, label: String): Boolean {
        val clean = label.trim().replace('\n', ' ').replace('\t', ' ').take(80)
        val ok = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("label", clean).commit()
        DiagnosticStore.add(context, "${stamp()} | HOME_SHORTCUT_LABEL_SAVED | label=$clean | verified=$ok")
        return ok
    }

    fun request(context: Context): Boolean {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val label = p.getString("label", "").orEmpty()
        if (label.length < 3) return false
        val ok = p.edit().putBoolean("pending", true).putString("last_result", "Ожидается поиск и нажатие иконки на главном экране").commit()
        DiagnosticStore.add(context, "${stamp()} | HOME_SHORTCUT_LAUNCH_REQUESTED | label=$label | cloneOnly=true | pending=$ok")
        return ok
    }

    fun pendingLabel(context: Context): String? {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return if (p.getBoolean("pending", false)) p.getString("label", "")?.takeIf { it.length >= 3 } else null
    }

    fun finish(context: Context, result: String, matched: Int = 0, clicked: Boolean = false) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean("pending", false).putString("last_result", result).commit()
        DiagnosticStore.add(context, "${stamp()} | HOME_SHORTCUT_LAUNCH_RESULT | result=$result | matched=$matched | clicked=$clicked")
    }

    private fun stamp() = java.text.SimpleDateFormat("HH:mm:ss.SSS", java.util.Locale.getDefault()).format(java.util.Date())
}
