package ru.tsautoreport.diagnostic

import android.content.Context
import java.io.File

/** Append-only internal journal. The complete journal is copied into the full report. */
object DiagnosticStore {
    private const val PREFS = "accessibility_diagnostic"
    private const val KEY_LOG = "events"
    private const val KEY_MIGRATED = "events_file_migrated_v1"
    private const val FILE_NAME = "diagnostic_events.log"

    private fun journal(context: Context) = File(context.filesDir, FILE_NAME)

    @Synchronized private fun migrateIfNeeded(context: Context) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (prefs.getBoolean(KEY_MIGRATED, false)) return
        val old = prefs.getString(KEY_LOG, "").orEmpty()
        if (old.isNotBlank()) {
            journal(context).appendText(old.trimEnd() + "\n", Charsets.UTF_8)
        }
        prefs.edit().putBoolean(KEY_MIGRATED, true).remove(KEY_LOG).commit()
    }

    @Synchronized fun add(context: Context, line: String) {
        try {
            migrateIfNeeded(context)
            val safe = line.replace('\n', ' ').replace('\r', ' ')
            journal(context).appendText(safe + "\n", Charsets.UTF_8)
        } catch (_: Exception) {
            // Preserve a fallback copy if internal storage is temporarily unavailable.
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val old = prefs.getString(KEY_LOG, "").orEmpty()
            prefs.edit().putString(KEY_LOG, (old + "\n" + line).takeLast(500_000)).commit()
        }
    }

    @Synchronized fun read(context: Context): List<String> = try {
        migrateIfNeeded(context)
        journal(context).takeIf { it.exists() }?.readLines(Charsets.UTF_8)?.filter { it.isNotBlank() }?.asReversed() ?: emptyList()
    } catch (_: Exception) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_LOG, "").orEmpty().split("\n").filter { it.isNotBlank() }.asReversed()
    }

    /** Returns every retained event in chronological order; no event-count truncation. */
    fun readAllChronological(context: Context): List<String> = read(context).asReversed()

    @Synchronized fun clear(context: Context) {
        try { journal(context).delete() } catch (_: Exception) {}
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY_LOG).putBoolean(KEY_MIGRATED, true).commit()
    }
}
