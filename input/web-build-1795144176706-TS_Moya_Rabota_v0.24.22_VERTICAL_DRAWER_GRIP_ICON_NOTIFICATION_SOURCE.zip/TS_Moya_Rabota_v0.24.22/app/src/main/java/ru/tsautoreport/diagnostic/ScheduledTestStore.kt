package ru.tsautoreport.diagnostic

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.net.Uri
import java.util.Calendar
import java.util.Date
import java.text.SimpleDateFormat
import java.util.Locale

object ScheduledTestStore {
    const val ACTION_RUN="ru.tsautoreport.diagnostic.RUN_CHAT_INTERVAL"
    const val EXTRA_CHAT_ID="chat_id"
    const val EXTRA_INTERVAL_ID="interval_id"
    const val EXTRA_MESSAGE="draft_message"
    const val EXTRA_BEHAVIOR="chat_behavior"
    private const val PREF="ts_alarm_state"
    private const val REGISTRY="registry"
    private fun key(chatId:String,intervalId:String)="$chatId|$intervalId"
    private fun requestCode(chatId:String,intervalId:String)=(key(chatId,intervalId).hashCode() and 0x7fffffff).coerceAtLeast(1)
    private fun intent(c:Context,chatId:String,intervalId:String,message:String)=Intent(c,ScheduledTestReceiver::class.java).setAction(ACTION_RUN).setData(Uri.parse("tswork://$chatId/$intervalId")).putExtra(EXTRA_CHAT_ID,chatId).putExtra(EXTRA_INTERVAL_ID,intervalId).putExtra(EXTRA_MESSAGE,message).putExtra(EXTRA_BEHAVIOR,ChatScheduleStore.chat(c,chatId)?.behavior ?: "SEND")
    fun scheduleAll(context:Context):Int {
        val gate=PermissionGate.status(context)
        require(gate.allReady){"Для запуска все пять индикаторов должны быть зелёными:\n${gate.problems().joinToString("\n")}"}
        val chats=ChatScheduleStore.all(context).filter{it.enabled}; require(chats.isNotEmpty()){"Включи хотя бы один чат галочкой"}
        require(chats.all{it.intervals.isNotEmpty()}){"Для каждого выбранного чата добавь хотя бы одно время"}
        val entries=chats.flatMap{ch->require(ch.confirmed && ch.launcherLabel.isNotBlank()){"Не подтверждён ярлык чата ${ch.launcherLabel}"}; ch.intervals.map{ch to it}}
        require(chats.all{it.behavior in setOf("READ","SEND","CHECK")}){"Выбери и сохрани режим работы для каждого чата"}
        require(entries.isNotEmpty()){"Добавь хотя бы одно время"}
        val alarm=context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        if(Build.VERSION.SDK_INT>=31 && !alarm.canScheduleExactAlarms())throw SecurityException("Нет разрешения на точные будильники")
        entries.forEach{(ch,slot)->require(slot.time.matches(Regex("([01]\\d|2[0-3]):[0-5]\\d"))){"Некорректное время ${slot.time}"};require(ch.behavior=="READ" || (slot.message.isNotBlank() && slot.message.length<=3000)){"Для режима отправки или проверки нужно сообщение до 3000 символов"};require(slot.mode=="ONCE"||slot.mode=="DAILY"){"Старый режим расписания требует повторного выбора: ${slot.time}"}}
        val planned=entries.map{(ch,slot)->nextTrigger(slot,slot.time.substringBefore(":").toInt(),slot.time.substringAfter(":").toInt()) to ch.id+":"+slot.id}
        require(planned.map{it.first}.distinct().size==planned.size){"Два интервала не могут запускаться в одну и ту же минуту: WhatsApp выполняет только один чат за раз. Разнеси время."}
        cancelAll(context)
        entries.forEach{(ch,slot)->scheduleOne(context,ch,slot)}
        context.getSharedPreferences(PREF,0).edit().putBoolean("active",entries.isNotEmpty()).commit()
        ScheduleKeepAliveService.start(context,ScheduleKeepAliveService.ACTION_MONITOR)
        return entries.size
    }
    private fun scheduleOne(c:Context,ch:WorkChat,slot:WorkInterval){
        val alarm=c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val parts=slot.time.split(":");require(parts.size==2);val hour=parts[0].toInt();val minute=parts[1].toInt();require(hour in 0..23&&minute in 0..59)
        require(ch.behavior=="READ" || (slot.message.isNotBlank()&&slot.message.length<=3000)){"Для режима отправки или проверки нужно сообщение до 3000 символов"}
        val target=nextTrigger(slot,hour,minute)
        val pi=PendingIntent.getBroadcast(c,requestCode(ch.id,slot.id),intent(c,ch.id,slot.id,slot.message),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,target,pi)
        val p=c.getSharedPreferences(PREF,0);val set=p.getStringSet(REGISTRY,emptySet()).orEmpty().toMutableSet();set.add(key(ch.id,slot.id));p.edit().putStringSet(REGISTRY,set).putLong(key(ch.id,slot.id),target).putBoolean("active",true).commit()
        DiagnosticStore.add(c,"${stamp()} | CHAT_INTERVAL_SCHEDULED | chatId=${ch.id} | intervalId=${slot.id} | at=${Date(target)} | mode=${slot.mode}")
    }
    private fun nextTrigger(slot:WorkInterval,hour:Int,minute:Int):Long {
        val now=Calendar.getInstance()
        fun at(day:Calendar):Long=day.apply{set(Calendar.HOUR_OF_DAY,hour);set(Calendar.MINUTE,minute);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0)}.timeInMillis
        return when(slot.mode){
            "DAILY"->{val c=Calendar.getInstance();var t=at(c);if(t<=now.timeInMillis){c.add(Calendar.DAY_OF_YEAR,1);t=at(c)};t}
            "WEEKDAYS"->{val c=Calendar.getInstance();var t=at(c);while(t<=now.timeInMillis || c.get(Calendar.DAY_OF_WEEK)==Calendar.SATURDAY || c.get(Calendar.DAY_OF_WEEK)==Calendar.SUNDAY){c.add(Calendar.DAY_OF_YEAR,1);t=at(c)};t}
            "DATES"->{val dates=slot.dates.split(',').mapNotNull{raw->runCatching{val d=SimpleDateFormat("yyyy-MM-dd",Locale.ROOT).apply{isLenient=false}.parse(raw.trim())?:return@runCatching null;Calendar.getInstance().apply{time=d;set(Calendar.HOUR_OF_DAY,hour);set(Calendar.MINUTE,minute);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0)}.timeInMillis}.getOrNull()}.filter{it>now.timeInMillis}.sorted();require(dates.isNotEmpty()){"Для интервала ${slot.time} нет будущих дат в формате ГГГГ-ММ-ДД"};dates.first()}
            else->{val c=Calendar.getInstance();var t=at(c);if(t<=now.timeInMillis){c.add(Calendar.DAY_OF_YEAR,1);t=at(c)};t}
        }
    }
    fun cancelAll(c:Context){val p=c.getSharedPreferences(PREF,0);val a=c.getSystemService(Context.ALARM_SERVICE) as AlarmManager;p.getStringSet(REGISTRY,emptySet()).orEmpty().forEach{entry->val parts=entry.split('|');if(parts.size==2){val i=intent(c,parts[0],parts[1],"");val pi=PendingIntent.getBroadcast(c,requestCode(parts[0],parts[1]),i,PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE);if(pi!=null){a.cancel(pi);pi.cancel()}}};repeat(3){index->val legacy=Intent(c,ScheduledTestReceiver::class.java).setAction("ru.tsautoreport.diagnostic.RUN_DRAFT_TEST");val old=PendingIntent.getBroadcast(c,19019+index,legacy,PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE);if(old!=null){a.cancel(old);old.cancel()}};p.edit().clear().putBoolean("active",false).commit()}
    fun cancel(c:Context){cancelAll(c);ScheduleKeepAliveService.start(c,ScheduleKeepAliveService.ACTION_STOP);DiagnosticStore.add(c,"${stamp()} | ALL_CHAT_SCHEDULES_STOPPED")}
    fun active(c:Context):Boolean{val p=c.getSharedPreferences(PREF,0);if(!p.getBoolean("active",false) || !ScheduleKeepAliveService.isRunning(c))return false;val ids=p.getStringSet(REGISTRY,emptySet()).orEmpty();val any=ids.any{entry->val parts=entry.split('|');if(parts.size!=2)false else PendingIntent.getBroadcast(c,requestCode(parts[0],parts[1]),intent(c,parts[0],parts[1],""),PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE)!=null};if(!any)p.edit().putBoolean("active",false).apply();return any}
    fun hasPendingSchedules(c:Context):Boolean{val p=c.getSharedPreferences(PREF,0);return p.getBoolean("active",false)&&p.getStringSet(REGISTRY,emptySet()).orEmpty().isNotEmpty()}
    fun scheduledAt(c:Context)=c.getSharedPreferences(PREF,0).all.values.filterIsInstance<Long>().filter{it>0}.minOrNull()?:0L
    fun pendingCount(c:Context)=c.getSharedPreferences(PREF,0).getStringSet(REGISTRY,emptySet()).orEmpty().size
    fun markFired(c:Context,chatId:String,intervalId:String){val p=c.getSharedPreferences(PREF,0);val set=p.getStringSet(REGISTRY,emptySet()).orEmpty().toMutableSet();set.remove(key(chatId,intervalId));p.edit().putStringSet(REGISTRY,set).remove(key(chatId,intervalId)).putBoolean("active",set.isNotEmpty()).commit();if(set.isEmpty())ScheduleKeepAliveService.start(c,ScheduleKeepAliveService.ACTION_STOP)}
    fun rescheduleRecurring(c:Context,chatId:String,intervalId:String){val ch=ChatScheduleStore.chat(c,chatId)?:return;val slot=ch.intervals.firstOrNull{it.id==intervalId}?:return;if(slot.mode!="ONCE")runCatching{scheduleOne(c,ch,slot);ScheduleKeepAliveService.start(c,ScheduleKeepAliveService.ACTION_MONITOR)}.onFailure{DiagnosticStore.add(c,"${stamp()} | RECURRING_RESCHEDULE_FAILED | ${it.message}")}}
    private fun stamp()=SimpleDateFormat("HH:mm:ss.SSS",Locale.getDefault()).format(Date())
}

class ScheduledTestReceiver:BroadcastReceiver(){override fun onReceive(context:Context,intent:Intent?){if(intent?.action!=ScheduledTestStore.ACTION_RUN)return
val gate=PermissionGate.status(context)
if(!gate.allReady){ScheduledTestStore.cancel(context);PermissionGate.notifyBlocked(context,gate.problems());DiagnosticStore.add(context,"${Date()} | SCHEDULE_ABORT_PERMISSION_GATE | ${gate.problems().joinToString(";")}");return}
val chatId=intent.getStringExtra(ScheduledTestStore.EXTRA_CHAT_ID).orEmpty();val intervalId=intent.getStringExtra(ScheduledTestStore.EXTRA_INTERVAL_ID).orEmpty();val message=intent.getStringExtra(ScheduledTestStore.EXTRA_MESSAGE).orEmpty();val chat=ChatScheduleStore.chat(context,chatId);val interval=chat?.intervals?.firstOrNull{it.id==intervalId};if(chat==null||interval==null||!chat.confirmed||interval.message!=message||(chat.behavior!="READ" && message.isBlank())) {DiagnosticStore.add(context,"${Date()} | ALARM_ABORT_INVALID_CHAT_OR_INTERVAL | chatId=$chatId");return};ChatScheduleStore.setPending(context,chatId);if(interval.mode=="ONCE")ChatScheduleStore.save(context,ChatScheduleStore.all(context).map{ch->if(ch.id==chatId)ch.copy(intervals=ch.intervals.filterNot{it.id==intervalId})else ch});ScheduledTestStore.markFired(context,chatId,intervalId);ScheduledTestStore.rescheduleRecurring(context,chatId,intervalId);val run=Intent(context,ScheduleKeepAliveService::class.java).setAction(ScheduleKeepAliveService.ACTION_RUN).putExtra(ScheduledTestStore.EXTRA_CHAT_ID,chatId).putExtra(ScheduledTestStore.EXTRA_INTERVAL_ID,intervalId).putExtra(ScheduledTestStore.EXTRA_MESSAGE,message).putExtra(ScheduledTestStore.EXTRA_BEHAVIOR,chat.behavior);try{if(Build.VERSION.SDK_INT>=26)context.startForegroundService(run)else context.startService(run)}catch(e:Exception){DiagnosticStore.add(context,"${Date()} | ALARM_SERVICE_START_FAILED | ${e.javaClass.simpleName}")}}}
