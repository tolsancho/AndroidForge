package ru.tsautoreport.diagnostic

import android.content.Context
import android.content.Intent
import android.content.pm.LauncherApps
import android.content.pm.ShortcutManager
import android.os.Build
import android.os.UserHandle

/** Safe capability matrix. It never reads chat contents or opens the primary WhatsApp profile. */
object ShortcutMethodAudit {
    private const val PREFS = "shortcut_method_audit"
    data class Row(val id: String, val title: String, val status: String, val detail: String, val exactChatLaunch: Boolean)

    fun load(context: Context): List<Row> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("rows", "").orEmpty()
        return raw.lineSequence().filter { it.isNotBlank() }.mapNotNull { line ->
            val p = line.split('\t', limit = 5)
            if (p.size != 5) null else Row(p[0], p[1], p[2], p[3], p[4] == "true")
        }.toList()
    }

    fun run(context: Context, launcherApps: LauncherApps, cloneUser: UserHandle): List<Row> {
        val rows = mutableListOf<Row>()
        val host = try { launcherApps.hasShortcutHostPermission() } catch (e: Exception) { false }
        if (!host) {
            rows += Row("launcher_query", "1. LauncherApps — чтение ярлыков WhatsApp", "ЗАБЛОКИРОВАНО ANDROID", "hasShortcutHostPermission=false. getShortcuts/startShortcut недоступны обычному приложению. Никакого обхода не выполняется.", false)
            DiagnosticStore.add(context, "${stamp()} | METHOD_LAUNCHERAPPS | status=BLOCKED | hostPermission=false | clone=$cloneUser")
        } else {
            try {
                val q = LauncherApps.ShortcutQuery().setPackage("com.whatsapp")
                    .setQueryFlags(LauncherApps.ShortcutQuery.FLAG_MATCH_DYNAMIC or LauncherApps.ShortcutQuery.FLAG_MATCH_PINNED or LauncherApps.ShortcutQuery.FLAG_MATCH_MANIFEST)
                val found = launcherApps.getShortcuts(q, cloneUser).orEmpty()
                rows += Row("launcher_query", "1. LauncherApps — чтение ярлыков WhatsApp", if (found.isEmpty()) "ВЫПОЛНЕНО: 0" else "НАЙДЕНО: ${found.size}", if (found.isEmpty()) "Профиль клона доступен, но список пуст." else found.joinToString("; ") { "${it.shortLabel}:${it.id}" }, found.isNotEmpty())
                DiagnosticStore.add(context, "${stamp()} | METHOD_LAUNCHERAPPS | status=OK | count=${found.size} | clone=$cloneUser")
            } catch (e: Exception) {
                rows += Row("launcher_query", "1. LauncherApps — чтение ярлыков WhatsApp", "ОШИБКА ${e.javaClass.simpleName}", e.message ?: "без подробностей", false)
                DiagnosticStore.add(context, "${stamp()} | METHOD_LAUNCHERAPPS_ERROR | ${e.javaClass.simpleName}:${e.message}")
            }
        }

        // ShortcutManager belongs to TS AutoReport's own package/profile. This is a negative control,
        // not a way to enumerate another app's shortcuts.
        if (Build.VERSION.SDK_INT >= 25) {
            try {
                val sm = context.getSystemService(ShortcutManager::class.java)
                val own = sm.pinnedShortcuts.size + sm.dynamicShortcuts.size + sm.manifestShortcuts.size
                rows += Row("own_shortcut_manager", "2. ShortcutManager — контроль собственного приложения", "ДОСТУПЕН ТОЛЬКО СВОЙ СПИСОК", "Собственных ярлыков TS AutoReport: $own. Этот API не читает ярлыки WhatsApp.", false)
                DiagnosticStore.add(context, "${stamp()} | METHOD_OWN_SHORTCUT_MANAGER | ownCount=$own | scope=TS_AutoReport_only")
            } catch (e: Exception) {
                rows += Row("own_shortcut_manager", "2. ShortcutManager — контроль собственного приложения", "ОШИБКА ${e.javaClass.simpleName}", e.message ?: "без подробностей", false)
                DiagnosticStore.add(context, "${stamp()} | METHOD_OWN_SHORTCUT_MANAGER_ERROR | ${e.javaClass.simpleName}:${e.message}")
            }
        } else rows += Row("own_shortcut_manager", "2. ShortcutManager — контроль собственного приложения", "НЕ ПОДДЕРЖИВАЕТСЯ", "Требуется Android 7.1 или новее.", false)

        try {
            val intent = Intent(Intent.ACTION_CREATE_SHORTCUT).setPackage("com.whatsapp")
            val matches = context.packageManager.queryIntentActivities(intent, 0)
            rows += Row("create_shortcut_provider", "3. ACTION_CREATE_SHORTCUT — мастер WhatsApp", if (matches.isEmpty()) "ПРОВАЙДЕР НЕ НАЙДЕН" else "НАЙДЕНО: ${matches.size}", "Проверка видимости в текущем профиле приложения. Это не чтение уже созданных ярлыков клона. ${matches.joinToString { it.activityInfo.name }}", false)
            DiagnosticStore.add(context, "${stamp()} | METHOD_CREATE_SHORTCUT_PROVIDER | count=${matches.size} | scope=current_app_profile_not_clone_proof")
        } catch (e: Exception) {
            rows += Row("create_shortcut_provider", "3. ACTION_CREATE_SHORTCUT — мастер WhatsApp", "ОШИБКА ${e.javaClass.simpleName}", e.message ?: "без подробностей", false)
            DiagnosticStore.add(context, "${stamp()} | METHOD_CREATE_SHORTCUT_PROVIDER_ERROR | ${e.javaClass.simpleName}:${e.message}")
        }

        if (Build.VERSION.SDK_INT >= 26) {
            try {
                val sm = context.getSystemService(ShortcutManager::class.java)
                val supported = sm.isRequestPinShortcutSupported
                rows += Row("pin_support", "4. Поддержка закрепления ярлыков лаунчером", if (supported) "ПОДДЕРЖИВАЕТСЯ" else "НЕ ПОДДЕРЖИВАЕТСЯ", "Это позволяет TS AutoReport попросить закрепить только собственный ярлык. Это НЕ извлекает существующий ярлык WhatsApp и не открывает конкретный чат.", false)
                DiagnosticStore.add(context, "${stamp()} | METHOD_PIN_SUPPORT | supported=$supported | scope=own_shortcuts_only")
            } catch (e: Exception) {
                rows += Row("pin_support", "4. Поддержка закрепления ярлыков лаунчером", "ОШИБКА ${e.javaClass.simpleName}", e.message ?: "без подробностей", false)
            }
        } else rows += Row("pin_support", "4. Поддержка закрепления ярлыков лаунчером", "НЕ ПОДДЕРЖИВАЕТСЯ", "Требуется Android 8.0 или новее.", false)

        rows += Row("shortcut_intent", "5. LauncherApps.getShortcutIntent / startShortcut", "НУЖЕН SHORTCUT ID И ДОСТУП ХОСТА", "Без ID конкретного ярлыка и shortcut host permission Android не позволяет получить PendingIntent или запустить чужой shortcut. Подбор ID наугад не выполняется.", false)
        rows += Row("home_icon_accessibility", "6. Иконка чата на главном экране Samsung через Accessibility", "ГОТОВ К ПРОВЕРКЕ", "Пользователь вводит видимую подпись ярлыка клона. Приложение открывает главный экран и Accessibility ищет совпадающую подпись, затем нажимает только при единственном совпадении. Это UI-метод, не чтение URI/shortcutId; источник профиля Android независимо не подтверждается.", false)
        DiagnosticStore.add(context, "${stamp()} | METHOD_HOME_ICON_ACCESSIBILITY | status=READY | cloneOnlyByUserCreatedIcon=true | requiresUniqueLauncherLabel=true")
        DiagnosticStore.add(context, "${stamp()} | METHOD_SHORTCUT_INTENT | status=NOT_RUN | reason=missing_host_permission_and_shortcut_id")

        val encoded = rows.joinToString("\n") { listOf(it.id, it.title, it.status, it.detail.replace('\n', ' ').replace('\t', ' '), it.exactChatLaunch.toString()).joinToString("\t") }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("rows", encoded).putLong("updated_at", System.currentTimeMillis()).commit()
        return rows
    }

    fun stamp(): String = java.text.SimpleDateFormat("HH:mm:ss.SSS", java.util.Locale.getDefault()).format(java.util.Date())
}
