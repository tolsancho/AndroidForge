package ru.tsautoreport.diagnostic

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.net.Uri
import android.accessibilityservice.AccessibilityServiceInfo
import android.view.accessibility.AccessibilityManager

/** All five conditions must be green before schedules can be created or executed. */
object PermissionGate {
    data class Status(
        val accessibility: Boolean,
        val battery: Boolean,
        val exactAlarm: Boolean,
        val notifications: Boolean,
        val screenLockDisabled: Boolean
    ) {
        val allReady: Boolean get() = accessibility && battery && exactAlarm && notifications && screenLockDisabled
        fun problems(): List<String> = buildList {
            if (!accessibility) add("Специальные возможности (Accessibility)")
            if (!battery) add("Работа без ограничений батареи")
            if (!exactAlarm) add("Точные будильники")
            if (!notifications) add("Уведомления")
            if (!screenLockDisabled) add("Блокировка экрана включена — отключите PIN-код, пароль, графический ключ, отпечаток и распознавание лица")
        }
    }

    fun status(c: Context): Status {
        val accessibility = try {
            val manager = c.getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
            manager.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
                .any { it.resolveInfo.serviceInfo.packageName == c.packageName }
        } catch (_: Exception) { false }
        val battery = try { val power=c.getSystemService(Context.POWER_SERVICE) as PowerManager; power.isIgnoringBatteryOptimizations(c.packageName) && !power.isPowerSaveMode } catch (_: Exception) { false }
        val alarm = try { Build.VERSION.SDK_INT < 31 || (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).canScheduleExactAlarms() } catch (_: Exception) { false }
        val notifications = try { Build.VERSION.SDK_INT < 33 || c.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) == android.content.pm.PackageManager.PERMISSION_GRANTED } catch (_: Exception) { false }
        val lockDisabled = try { !(c.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager).isDeviceSecure } catch (_: Exception) { false }
        return Status(accessibility, battery, alarm, notifications, lockDisabled)
    }

    fun openBattery(c: Context) { try { c.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${c.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) { c.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }
    fun openAlarm(c: Context) { if (Build.VERSION.SDK_INT >= 31) c.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${c.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    fun openNotifications(c: Context) { c.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, c.packageName).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    fun openLockSettings(c: Context) { try { c.startActivity(Intent(Settings.ACTION_SECURITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) { c.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }

    fun notifyBlocked(c: Context, problems: List<String>) {
        if (problems.isEmpty()) return
        try {
            val manager = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(NotificationChannel(CHANNEL, "Требуются разрешения TS Моя работа", NotificationManager.IMPORTANCE_HIGH))
            val open = PendingIntent.getActivity(c, 7421, Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(c, CHANNEL) else Notification.Builder(c)
            manager.notify(ID, builder.setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle("TS Моя работа остановлена")
                .setContentText("Не выполнено условие: ${problems.first()}")
                .setStyle(Notification.BigTextStyle().bigText("Автоматическая работа остановлена. Исправьте настройки: ${problems.joinToString("; ")}. Откройте приложение и проверьте пять индикаторов разрешений."))
                .setContentIntent(open).setOngoing(true).build())
        } catch (_: Exception) { }
    }
    fun dismissBlockedNotification(c: Context) { try { (c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(ID) } catch (_: Exception) { } }
    private const val CHANNEL = "ts_permission_gate"
    private const val ID = 19031
}
