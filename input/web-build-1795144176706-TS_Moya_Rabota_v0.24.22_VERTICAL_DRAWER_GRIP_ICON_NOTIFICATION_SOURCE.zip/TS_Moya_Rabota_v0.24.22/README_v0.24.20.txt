TS Моя работа v0.24.20
BUILD ID: TS-UI-02420
versionCode: 51
versionName: 0.24.20-drawer-shape-compile-fix

Build fix для v0.24.19: правильный импорт Compose GenericShape и явное построение androidx.compose.ui.graphics.Path внутри builder. Исправлены первичные ошибки компиляции в MainActivity.kt, вызвавшие каскад ошибок вывода типов и координат. Внешний вид/геометрия и логика жестов меню сохранены. Автоматизация WhatsApp и расписания не менялись.

Сборка: AndroidForge → загрузить ZIP → Android APK → Debug → Build. Успех сборки и тест на телефоне пока не подтверждены.
