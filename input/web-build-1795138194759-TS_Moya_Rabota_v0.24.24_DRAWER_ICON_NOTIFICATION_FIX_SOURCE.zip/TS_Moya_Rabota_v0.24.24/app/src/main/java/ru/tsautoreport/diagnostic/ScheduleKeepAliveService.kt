package ru.tsautoreport.diagnostic

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log

/** Keeps the scheduled workflow visible to Android while a one-shot test is pending/running. */
class ScheduleKeepAliveService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private val stopRunnable = Runnable { stopWithStoppedStatus() }
    private val permissionMonitor = object : Runnable {
        override fun run() {
            val scheduleActive = ScheduledTestStore.active(this@ScheduleKeepAliveService)
            val taskExecuting = ChatScheduleStore.pending(this@ScheduleKeepAliveService) != null
            if (!scheduleActive && !taskExecuting) {
                updateForegroundNotification()
                return
            }
            val problems = PermissionGate.status(this@ScheduleKeepAliveService).problems()
            if (problems.isNotEmpty()) {
                DiagnosticStore.add(this@ScheduleKeepAliveService, "${stamp()} | PERMISSION_GATE_RUNTIME_STOP | ${problems.joinToString(";")}")
                ScheduledTestStore.cancel(this@ScheduleKeepAliveService)
                PermissionGate.notifyBlocked(this@ScheduleKeepAliveService, problems)
                stopWithStoppedStatus()
                return
            }
            updateForegroundNotification()
            handler.postDelayed(this, 15_000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(NOTIFICATION_ID, buildNotification(running = true))
        DiagnosticStore.add(this, "${stamp()} | SCHEDULE_FOREGROUND_SERVICE_CREATED | foreground=true")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_RUN -> {
                DiagnosticStore.add(this, "${stamp()} | SCHEDULE_FOREGROUND_SERVICE_RUN | action=RUN | interval=${intent.getStringExtra(ScheduledTestStore.EXTRA_INTERVAL_ID).orEmpty()} chat=${intent.getStringExtra(ScheduledTestStore.EXTRA_CHAT_ID).orEmpty()}")
                handler.removeCallbacks(stopRunnable)
                handler.removeCallbacks(permissionMonitor)
                handler.postDelayed(permissionMonitor, 15_000L)
                startForeground(NOTIFICATION_ID, buildNotification(running = true))
                val message = intent.getStringExtra(ScheduledTestStore.EXTRA_MESSAGE).orEmpty()
                val slot = intent.getStringExtra(ScheduledTestStore.EXTRA_INTERVAL_ID).orEmpty()
                val chatId = intent.getStringExtra(ScheduledTestStore.EXTRA_CHAT_ID).orEmpty()
                val behavior = intent.getStringExtra(ScheduledTestStore.EXTRA_BEHAVIOR).orEmpty().ifBlank { "SEND" }
                val dispatched = WhatsAppAccessibilityService.beginScheduledDraftTest(message, slot.hashCode(), chatId, behavior)
                DiagnosticStore.add(this, "${stamp()} | SCHEDULE_FOREGROUND_SERVICE_ACCESSIBILITY_DISPATCH | available=$dispatched")
                if (!dispatched) DiagnosticStore.add(this, "${stamp()} | DRAFT_TEST_ABORTED | reason=ACCESSIBILITY_SERVICE_NOT_RUNNING")
                updateForegroundNotification()
                if (ScheduledTestStore.pendingCount(this) == 0) handler.postDelayed(stopRunnable, 60_000L)
            }
            ACTION_MONITOR -> {
                DiagnosticStore.add(this, "${stamp()} | SCHEDULE_FOREGROUND_SERVICE_MONITOR | scheduledAt=${ScheduledTestStore.scheduledAt(this)}")
                handler.removeCallbacks(stopRunnable)
                handler.removeCallbacks(permissionMonitor)
                handler.post(permissionMonitor)
                startForeground(NOTIFICATION_ID, buildNotification(running = true))
            }
            ACTION_STOP -> {
                handler.removeCallbacks(stopRunnable)
                handler.removeCallbacks(permissionMonitor)
                stopWithStoppedStatus()
            }
        }
        return START_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        // START_STICKY is the recovery hint; Android/OEM policy still controls process restart.
        DiagnosticStore.add(this, "${stamp()} | SCHEDULE_FOREGROUND_TASK_REMOVED | sticky_restart_requested=true")
        super.onTaskRemoved(rootIntent)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(NotificationChannel(CHANNEL_ID, "TS Моя работа", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Статус работы приложения TS Моя работа"
            })
        }
    }

    private fun buildNotification(running: Boolean): Notification {
        // This is the same persisted schedule state used by the green/red control in MainActivity.
        // Match the green/red button: only an active persisted schedule locks dismissal.
        val appRunning = running && ScheduledTestStore.active(this)
        val taskExecuting = ChatScheduleStore.pending(this) != null
        val appStatus = if (appRunning) "Запущено" else "Остановлено"
        val taskStatus = if (appRunning || taskExecuting) "Выполняется задача" else "Задача остановлена"
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
        return builder
            .setSmallIcon(R.drawable.ic_notification_ts)
            .setLargeIcon(launcherIconBitmap())
            .setContentTitle("TS Моя работа")
            .setContentText(appStatus)
            .setSubText(taskStatus)
            .setStyle(Notification.BigTextStyle().bigText("$appStatus\n$taskStatus"))
            // Protect the notification only while the app's schedule is active (green button).
            // Once stopped (red button), the notification becomes swipe-dismissible.
            .setOngoing(appRunning)
            .setOnlyAlertOnce(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .build()
    }

    private fun launcherIconBitmap(): android.graphics.Bitmap? = try {
        val drawable = packageManager.getApplicationIcon(packageName)
        val size = (64f * resources.displayMetrics.density).toInt().coerceAtLeast(64)
        android.graphics.Bitmap.createBitmap(size, size, android.graphics.Bitmap.Config.ARGB_8888).also { bitmap ->
            val canvas = android.graphics.Canvas(bitmap)
            drawable.setBounds(0, 0, size, size)
            drawable.draw(canvas)
        }
    } catch (_: Exception) {
        null
    }

    private fun updateForegroundNotification() {
        try {
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.notify(NOTIFICATION_ID, buildNotification(running = true))
        } catch (e: Exception) {
            DiagnosticStore.add(this, "${stamp()} | STATUS_NOTIFICATION_UPDATE_FAILED | ${e.javaClass.simpleName}")
        }
    }

    private fun stopWithStoppedStatus() {
        handler.removeCallbacks(stopRunnable)
        handler.removeCallbacks(permissionMonitor)
        // Detach first, then retain a clear, non-technical status notification.
        stopForeground(STOP_FOREGROUND_DETACH)
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIFICATION_ID, buildNotification(running = false))
        stopSelf()
    }

    private fun stamp() = java.text.SimpleDateFormat("HH:mm:ss.SSS", java.util.Locale.getDefault()).format(java.util.Date())

    companion object {
        const val ACTION_MONITOR = "ru.tsautoreport.diagnostic.SCHEDULE_MONITOR"
        const val ACTION_RUN = "ru.tsautoreport.diagnostic.SCHEDULE_RUN"
        const val ACTION_STOP = "ru.tsautoreport.diagnostic.SCHEDULE_STOP"
        private const val CHANNEL_ID = "ts_autoreport_schedule"
        private const val NOTIFICATION_ID = 19020

        fun isRunning(context: Context): Boolean = try {
            val manager = context.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
            manager.getRunningServices(Int.MAX_VALUE).any { it.service.className == ScheduleKeepAliveService::class.java.name }
        } catch (_: Exception) { false }

        fun start(context: Context, action: String) {
            val intent = Intent(context, ScheduleKeepAliveService::class.java).setAction(action)
            try {
                if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(intent) else context.startService(intent)
                DiagnosticStore.add(context, "${java.text.SimpleDateFormat("HH:mm:ss.SSS", java.util.Locale.getDefault()).format(java.util.Date())} | SCHEDULE_FOREGROUND_START_REQUESTED | action=$action")
            } catch (e: Exception) {
                DiagnosticStore.add(context, "${java.text.SimpleDateFormat("HH:mm:ss.SSS", java.util.Locale.getDefault()).format(java.util.Date())} | SCHEDULE_FOREGROUND_START_FAILED | action=$action | error=${e.javaClass.simpleName}")
            }
        }
    }
}
