package ru.tsautoreport.diagnostic

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object ScheduledTestStore {
    private const val PREFS = "scheduled_draft_test"
    private const val REQUEST_CODE = 19019
    const val ACTION_RUN = "ru.tsautoreport.diagnostic.RUN_DRAFT_TEST"

    fun schedule(context: Context, hhmm: String): Long {
        val parts = hhmm.trim().split(":")
        require(parts.size == 2)
        val hour = parts[0].toInt(); val minute = parts[1].toInt()
        require(hour in 0..23 && minute in 0..59)
        val now = Calendar.getInstance()
        val target = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= now.timeInMillis) add(Calendar.DAY_OF_YEAR, 1)
        }
        val intent = Intent(context, ScheduledTestReceiver::class.java).setAction(ACTION_RUN)
        val pi = PendingIntent.getBroadcast(context, REQUEST_CODE, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        if (Build.VERSION.SDK_INT >= 31 && !alarm.canScheduleExactAlarms()) throw SecurityException("Нет разрешения на точные будильники")
        alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, target.timeInMillis, pi)
        val ok = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putLong("scheduled_at", target.timeInMillis).putBoolean("active", true).commit()
        DiagnosticStore.add(context, "${stamp()} | DRAFT_TEST_SCHEDULED | at=${SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(target.time)} | exact=true | saved=$ok | cloneOnly=true | text=проверка | send=false")
        ScheduleKeepAliveService.start(context, ScheduleKeepAliveService.ACTION_MONITOR)
        return target.timeInMillis
    }

    fun cancel(context: Context) {
        val intent = Intent(context, ScheduledTestReceiver::class.java).setAction(ACTION_RUN)
        val pi = PendingIntent.getBroadcast(context, REQUEST_CODE, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pi)
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("active", false).commit()
        DiagnosticStore.add(context, "${stamp()} | DRAFT_TEST_CANCELLED | user_action=true")
        ScheduleKeepAliveService.start(context, ScheduleKeepAliveService.ACTION_STOP)
    }

    fun active(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean("active", false)
    fun scheduledAt(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getLong("scheduled_at", 0L)
    fun markFired(context: Context) { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("active", false).commit() }
    private fun stamp() = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault()).format(java.util.Date())
}

class ScheduledTestReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != ScheduledTestStore.ACTION_RUN) return
        DiagnosticStore.add(context, "${SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault()).format(java.util.Date())} | DRAFT_TEST_ALARM_RECEIVED | cloneOnly=true")
        ScheduledTestStore.markFired(context)
        ScheduleKeepAliveService.start(context, ScheduleKeepAliveService.ACTION_RUN)
        DiagnosticStore.add(context, "${SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault()).format(Date())} | DRAFT_TEST_DISPATCHED_TO_FOREGROUND_SERVICE | cloneOnly=true")
    }
}
